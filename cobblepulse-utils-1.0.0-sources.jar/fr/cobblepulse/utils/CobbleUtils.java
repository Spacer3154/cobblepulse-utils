package fr.cobblepulse.utils;

import fr.cobblepulse.utils.alerts.SpawnAlerts;
import fr.cobblepulse.utils.boss.Bosses;
import fr.cobblepulse.utils.command.Cmd;
import fr.cobblepulse.utils.command.RootCommands;
import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.core.Loc;
import fr.cobblepulse.utils.core.Players;
import fr.cobblepulse.utils.core.Scheduler;
import fr.cobblepulse.utils.data.PlayerData;
import fr.cobblepulse.utils.data.PlayerStore;
import fr.cobblepulse.utils.dex.DexRewards;
import fr.cobblepulse.utils.enderchest.Enderchests;
import fr.cobblepulse.utils.essentials.ChatFeatures;
import fr.cobblepulse.utils.essentials.EssentialsCommands;
import fr.cobblepulse.utils.essentials.Vanish;
import fr.cobblepulse.utils.gui.ChatInput;
import fr.cobblepulse.utils.integration.Economy;
import fr.cobblepulse.utils.kits.Kits;
import fr.cobblepulse.utils.market.Gts;
import fr.cobblepulse.utils.market.GtsMenus;
import fr.cobblepulse.utils.market.Mailbox;
import fr.cobblepulse.utils.market.Sts;
import fr.cobblepulse.utils.market.WonderTrade;
import fr.cobblepulse.utils.net.Net;
import fr.cobblepulse.utils.shop.ShopMenus;
import fr.cobblepulse.utils.storage.Db;
import fr.cobblepulse.utils.teleport.TeleportCommands;
import fr.cobblepulse.utils.teleport.Teleports;
import fr.cobblepulse.utils.teleport.Tpa;
import fr.cobblepulse.utils.wiki.WikiService;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1269;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * CobblePulse Utils : mod central de l'ecosysteme CobblePulse (Fabric 1.21.1, Cobblemon 1.8.4).
 * Hub, Wiki, teleportation, Shop/GTS/STS/Echange Miracle, kits, enderchests, Dex Rewards, alertes de spawns, Boss PVE.
 */
public final class CobbleUtils implements ModInitializer {
    public static final String MOD_ID = "cobblepulse_utils";
    public static final Logger LOG = LoggerFactory.getLogger("CobblePulse-Utils");
    private static final class_2960 LATE = class_2960.method_60655(MOD_ID, "late");
    private static MinecraftServer server;

    public static MinecraftServer server() {
        return server;
    }

    @Override
    public void onInitialize() {
        Net.registerTypes();
        Net.registerServer();
        SpawnAlerts.init();
        Bosses.init();

        ServerLifecycleEvents.SERVER_STARTING.register(s -> {
            server = s;
            Cfg.loadAll();
            try {
                Db.init();
            } catch (Exception e) {
                LOG.error("[CobblePulse-Utils] Base de donnees indisponible : {}", e.toString(), e);
            }
            Economy.init();
            SpawnAlerts.load();
        });
        // mondes ajoutes par d'autres mods (y compris crees a chaud) : ajoutes a worlds.json
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents.LOAD.register((s, level) -> {
            if (Cfg.worlds != null && fr.cobblepulse.utils.teleport.Worlds.ensure(level) && s.method_3806()) Cfg.save("worlds.json", Cfg.worlds);
        });
        ServerLifecycleEvents.SERVER_STARTED.register(s -> {
            fr.cobblepulse.utils.teleport.Worlds.sync(s);
            fr.cobblepulse.utils.pokemon.SpeciesNames.language = Cfg.general.language;
            fr.cobblepulse.utils.pokemon.SpeciesNames.reload(s);
            Scheduler.repeat(20, 20, fr.cobblepulse.utils.playtime.PlaytimeRewards::tick);
            Scheduler.repeat(1200, 1200, () -> {
                PlayerStore.flushDirty();
                Enderchests.periodicSave();
                Gts.expireTick();
            });
            Scheduler.repeat(600, 600, () -> {
                for (class_3222 p : s.method_3760().method_14571()) if (!Players.isTest(p.method_5667())) Mailbox.autoClaimMoney(p, false);
            });
            Scheduler.repeat(400, 400, Bosses::tick);
            Scheduler.repeat(10, 10, fr.cobblepulse.utils.boss.BossLoot::tick);
            Bosses.highLevelsSupported();
            Scheduler.repeat(100, 6000, () -> {
                WonderTrade.refill();
                SpawnAlerts.save();
            });
            if (!Cmd.replaced().isEmpty()) LOG.info("[CobblePulse-Utils] Commandes d'autres mods remplacees : {}", Cmd.replaced());
            LOG.info("[CobblePulse-Utils] Pret ({} categories de shop, {} kits, {} warps)", Cfg.SHOP.size(), Cfg.kits.kits.size(), Cfg.warps.warps.size());
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> {
            fr.cobblepulse.utils.boss.BossLoot.flushAll();
            PlayerStore.saveAllSync();
            Enderchests.saveAllSync();
            SpawnAlerts.save();
            Scheduler.clear();
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> {
            Db.close();
            PlayerStore.clear();
            server = null;
        });
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            Scheduler.tick(s);
            Teleports.tick();
        });

        // Commandes : phase tardive pour voir (et remplacer / fusionner) les commandes vanilla, Cobblemon et des autres mods
        CommandRegistrationCallback.EVENT.addPhaseOrdering(Event.DEFAULT_PHASE, LATE);
        CommandRegistrationCallback.EVENT.register(LATE, (d, ctx, env) -> {
            if (Cfg.general == null || Cfg.commands.commands.isEmpty()) Cfg.loadAll();
            RootCommands.register(d);
            WikiService.register(d);
            TeleportCommands.register(d);
            EssentialsCommands.register(d);
            ChatFeatures.register(d);
            Kits.register(d);
            Enderchests.register(d);
            DexRewards.register(d);
            ShopMenus.register(d);
            GtsMenus.register(d);
            Sts.register(d);
            WonderTrade.register(d);
            SpawnAlerts.register(d);
            fr.cobblepulse.utils.teleport.Worlds.register(d);
            fr.cobblepulse.utils.playtime.PlaytimeRewards.register(d);
        });

        // Fakemons de datapacks : les especes et leurs noms changent avec /reload
        ServerLifecycleEvents.END_DATA_PACK_RELOAD.register((s, rm, ok) -> {
            if (!ok) return;
            fr.cobblepulse.utils.boss.MegaStones.invalidate();
            fr.cobblepulse.utils.pokemon.SpeciesNames.reload(s);
            for (class_3222 p : s.method_3760().method_14571()) sendSpeciesNames(p);
        });
        ServerPlayConnectionEvents.JOIN.register((handler, sender, s) -> {
            class_3222 p = handler.method_32311();
            sendSpeciesNames(p);
            boolean first = PlayerStore.get(p).firstJoin == 0;
            PlayerStore.onJoin(p);
            ChatFeatures.onJoin(p);
            Vanish.onJoin(p);
            Scheduler.later(40, () -> {
                if (!p.method_14239()) Mailbox.autoClaimMoney(p, true);
            });
            if (first && Cfg.warps.spawn != null) Scheduler.later(5, () -> {
                if (!p.method_14239()) Teleports.perform(p, Cfg.warps.spawn, null, null);
            });
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, s) -> {
            class_3222 p = handler.method_32311();
            fr.cobblepulse.utils.boss.BossLoot.flush(p);
            Teleports.cancel(p.method_5667());
            Tpa.clear(p.method_5667());
            ChatInput.clear(p.method_5667());
            fr.cobblepulse.utils.gui.Screens.forget(p.method_5667());
            fr.cobblepulse.utils.playtime.PlaytimeRewards.forget(p.method_5667());
            Vanish.onLeave(p);
            ChatFeatures.onLeave(p);
            PlayerStore.onLeave(p);
        });
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            fr.cobblepulse.utils.playtime.PlaytimeRewards.active(sender);
            return ChatFeatures.allowChat(sender, message.method_44862());
        });
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof class_3222 p && EssentialsCommands.isGod(p)) return false;
            return Bosses.allowDamage(entity, source);
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof class_3222 p) Teleports.setBack(p, Loc.of(p), true);
            else SpawnAlerts.onDeath(entity, source);
        });
        ServerEntityEvents.ENTITY_LOAD.register((entity, level) -> Bosses.onLoad(entity));
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, level) -> SpawnAlerts.onUnload(entity));
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (level.method_8608() || !(player instanceof class_3222 sp) || !Cfg.general.enderchest.replaceVanilla) return class_1269.field_5811;
            if (!level.method_8320(hit.method_17777()).method_27852(class_2246.field_10443) || sp.method_21823()) return class_1269.field_5811;
            if (!fr.cobblepulse.utils.core.Perms.command(sp, "enderchest")) return class_1269.field_5811;
            Enderchests.open(sp, sp.method_5667(), sp.method_7334().getName(), -1);
            return class_1269.field_5812;
        });
    }

    /** /cp reload : configurations et messages (le type de stockage necessite un redemarrage). */
    public static void reload() {
        Cfg.loadAll();
        Economy.init();
        for (class_3222 p : server.method_3760().method_14571()) {
            PlayerData d = PlayerStore.get(p);
            ChatFeatures.applyNick(p.method_5667(), d.nick, p.method_7334().getName());
            server.method_3734().method_9241(p);
        }
    }

    /** Noms des especes que le joueur n'a peut-etre pas traduites (Fakemons de datapacks), pour le Wiki et les ecrans. */
    private static void sendSpeciesNames(class_3222 p) {
        var names = fr.cobblepulse.utils.pokemon.SpeciesNames.forClients();
        if (!names.isEmpty()) fr.cobblepulse.utils.net.Net.send(p, "species_names", new java.util.LinkedHashMap<>(names));
    }
}
