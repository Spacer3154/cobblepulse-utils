package fr.cobblepulse.utils.alerts;

import com.cobblemon.mod.common.api.Priority;
import com.cobblemon.mod.common.api.events.CobblemonEvents;
import com.cobblemon.mod.common.api.pokemon.PokemonSpecies;
import com.cobblemon.mod.common.entity.pokemon.PokemonEntity;
import com.cobblemon.mod.common.item.PokemonItem;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.cobblemon.mod.common.pokemon.Species;
import com.google.gson.reflect.TypeToken;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import fr.cobblepulse.utils.CobbleUtils;
import fr.cobblepulse.utils.boss.Bosses;
import fr.cobblepulse.utils.command.Cmd;
import fr.cobblepulse.utils.config.AlertsConfig;
import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.core.ItemBuilder;
import fr.cobblepulse.utils.core.Json;
import fr.cobblepulse.utils.core.Loc;
import fr.cobblepulse.utils.core.Msg;
import fr.cobblepulse.utils.core.Perms;
import fr.cobblepulse.utils.core.Reg;
import fr.cobblepulse.utils.core.Scheduler;
import fr.cobblepulse.utils.core.TextUtil;
import fr.cobblepulse.utils.core.TimeFmt;
import fr.cobblepulse.utils.gui.Gui;
import fr.cobblepulse.utils.hub.Hub;
import fr.cobblepulse.utils.teleport.Teleports;
import kotlin.Unit;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static net.minecraft.class_2170.method_9244;

/**
 * Alertes et historique des spawns rares (Chromatiques, Paradoxes, Ultra-Chimeres, Legendaires, Fabuleux) :
 * annonce globale (Pokemon, biome traduit, joueur le plus proche), coordonnees au survol pour le staff,
 * historique des 10 derniers par categorie avec statut (Actif, Capture, Despawn). Les Boss sont exclus.
 */
public final class SpawnAlerts {
    public static final List<String> CATEGORIES = List.of("shiny", "paradox", "ultra_beast", "legendary", "mythical");
    /** Auto-test : texte de la derniere annonce. */
    public static volatile String lastBroadcast = "";
    /** Auto-test : derniere annonce telle qu'envoyee (nom d'espece compris). */
    public static volatile class_2561 lastBroadcastMessage = class_2561.method_43473();
    /** Auto-test : texte de la derniere annonce de capture / victoire / mort. */
    public static volatile String lastOutcome = "";

    /** Entree d'historique (serialisee dans data/spawn_history.json). */
    public static final class Entry {
        public String species;
        public List<String> aspects = new ArrayList<>();
        public String pokemonUuid;
        public String entityUuid;
        public long time;
        public String biome;
        public String nearest = "";
        public String status = "ACTIVE";
        public String captor = "";
        public long statusTime;
        public Loc loc;
        public boolean shiny;
        /** Alerte de test envoyee a un seul membre du staff (UUID) : la suite lui est annoncee a lui seul. */
        public String onlyTo = "";
    }

    private static final Map<String, Deque<Entry>> HISTORY = new LinkedHashMap<>();
    private static final Map<String, List<Entry>> BY_ENTITY = new LinkedHashMap<>();

    private SpawnAlerts() {}

    public static void init() {
        for (String c : CATEGORIES) HISTORY.put(c, new ArrayDeque<>());
        CobblemonEvents.POKEMON_ENTITY_SPAWN.subscribe(Priority.LOWEST, e -> {
            try {
                if (!e.isCanceled()) onSpawn(e.getEntity());
            } catch (Throwable t) {
                CobbleUtils.LOG.warn("[CobblePulse-Utils] Alerte de spawn : {}", t.toString());
            }
            return Unit.INSTANCE;
        });
        CobblemonEvents.POKEMON_CAPTURED.subscribe(Priority.LOWEST, e -> {
            try {
                onCapture(e.getPokemon(), e.getPlayer());
            } catch (Throwable t) {
                CobbleUtils.LOG.warn("[CobblePulse-Utils] Historique (capture) : {}", t.toString());
            }
            return Unit.INSTANCE;
        });
        CobblemonEvents.BATTLE_VICTORY.subscribe(Priority.LOWEST, e -> {
            try {
                onVictory(e.getWinners(), e.getLosers());
            } catch (Throwable t) {
                CobbleUtils.LOG.warn("[CobblePulse-Utils] Historique (victoire) : {}", t.toString());
            }
            return Unit.INSTANCE;
        });
    }

    public static void register(CommandDispatcher<class_2168> d) {
        Cmd.player(d, "spawns", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, p -> openHistory(p, null)))
                .then(method_9244("categorie", StringArgumentType.word()).suggests((c, b) -> class_2172.method_9265(CATEGORIES, b))
                        .executes(ctx -> Cmd.run(ctx, p -> openHistory(p, StringArgumentType.getString(ctx, "categorie"))))));
    }

    /** Categories surveillees auxquelles appartient ce Pokemon. */
    public static List<String> categories(Pokemon pk) {
        List<String> out = new ArrayList<>();
        Set<String> labels = pk.getSpecies().getLabels();
        if (pk.getShiny()) out.add("shiny");
        if (labels.contains("paradox")) out.add("paradox");
        if (labels.contains("ultra_beast")) out.add("ultra_beast");
        if (labels.contains("mythical")) out.add("mythical");
        else if (labels.contains("legendary")) out.add("legendary");
        out.removeIf(c -> {
            AlertsConfig.Category cat = Cfg.alerts.categories.get(c);
            return cat == null || !cat.enabled;
        });
        return out;
    }

    private static void onSpawn(PokemonEntity entity) {
        if (!Cfg.alerts.enabled || entity == null) return;
        if (entity.method_37908() instanceof class_3218 sl && !fr.cobblepulse.utils.teleport.Worlds.alerts(sl)) return;
        Pokemon pk = entity.getPokemon();
        if (pk == null || !pk.isWild()) return;
        List<String> cats = categories(pk);
        if (cats.isEmpty()) return;
        // laisser le Boss eventuel se declarer (promotion au meme tick), puis verifier
        Scheduler.next(() -> {
            if (entity.method_31481() || Bosses.isBoss(entity)) return;
            record(entity, cats);
        });
    }

    public static void record(PokemonEntity entity, List<String> cats) {
        record(entity, cats, null);
    }

    /**
     * Test staff : un vrai Pokemon sauvage de la categorie apparait devant le joueur et l'annonce part comme pour un
     * spawn naturel (historique, statut Capture / Disparu compris). onlyMe : annonce envoyee au staff seulement.
     */
    public static PokemonEntity test(class_3222 p, String cat, String speciesName, boolean onlyMe) {
        if (!CATEGORIES.contains(cat)) {
            Msg.send(p, "alerts.test_unknown", "category", cat, "categories", String.join(", ", CATEGORIES));
            return null;
        }
        com.cobblemon.mod.common.pokemon.Species sp = speciesName == null || speciesName.equals("*") ? null
                : fr.cobblepulse.utils.pokemon.SpeciesLookup.resolve(speciesName);
        if (sp == null) {
            List<com.cobblemon.mod.common.pokemon.Species> pool = new ArrayList<>(com.cobblemon.mod.common.api.pokemon.PokemonSpecies.getImplemented());
            pool.removeIf(x -> cat.equals("shiny") ? x.getLabels().contains("legendary") || x.getLabels().contains("mythical") : !x.getLabels().contains(cat));
            if (pool.isEmpty()) {
                Msg.send(p, "alerts.test_no_species", "category", cat);
                return null;
            }
            sp = pool.get(new java.util.Random().nextInt(pool.size()));
        }
        com.cobblemon.mod.common.api.pokemon.PokemonProperties pp = com.cobblemon.mod.common.api.pokemon.PokemonProperties.Companion
                .parse("level=30 shiny=" + (cat.equals("shiny") ? "yes" : "no"));
        pp.setSpecies(sp.getResourceIdentifier().toString());
        Pokemon pk = pp.create();
        net.minecraft.class_243 look = p.method_5720();
        net.minecraft.class_243 pos = p.method_19538().method_1019(new net.minecraft.class_243(look.field_1352, 0, look.field_1350).method_1029().method_1021(4));
        PokemonEntity e = new PokemonEntity(p.method_51469(), pk, com.cobblemon.mod.common.CobblemonEntities.POKEMON);
        e.method_5808(pos.field_1352, p.method_23318(), pos.field_1350, p.method_36454() + 180, 0);
        p.method_51469().method_8649(e);
        List<String> cats = categories(pk);
        if (cats.isEmpty()) {
            // categorie desactivee dans alerts.json : on l'annonce quand meme pour le test
            cats = new ArrayList<>(List.of(cat));
        }
        record(e, cats, onlyMe ? p : null);
        Msg.send(p, Msg.withComponent("alerts.test_done", "pokemon", fr.cobblepulse.utils.pokemon.SpeciesNames.of(sp), "category", label(cats),
                "target", onlyMe ? Msg.format("alerts.test_target_me") : Msg.format("alerts.test_target_all")));
        return e;
    }

    /** Choix de la categorie a tester (clic : annonce a tous, clic droit : au staff seul). */
    public static void testMenu(class_3222 p) {
        Gui g = new Gui(3, Msg.format("alerts.test_title"));
        g.fill(Gui.pane());
        int slot = 11;
        for (String c : CATEGORIES) {
            AlertsConfig.Category ac = Cfg.alerts.categories.get(c);
            if (ac == null) continue;
            g.button(slot++, ItemBuilder.of(Reg.stack(ac.icon)).name(ac.color + ac.label).lore(Msg.format("alerts.test_cat_lore")).build(), (pl, click) -> {
                Gui.close(pl);
                test(pl, c, null, click.right());
            });
        }
        g.button(22, ItemBuilder.of(class_1802.field_8691).name(Msg.format("general.back")).build(), pl -> openHistory(pl, null));
        g.open(p);
    }

    public static void record(PokemonEntity entity, List<String> cats, class_3222 onlyTo) {
        Pokemon pk = entity.getPokemon();
        class_3218 level = (class_3218) entity.method_37908();
        class_2960 biome = level.method_23753(entity.method_24515()).method_40230().map(k -> k.method_29177()).orElse(class_2960.method_60656("plains"));
        class_3222 nearest = null;
        double best = Cfg.alerts.nearestPlayerRadius * Cfg.alerts.nearestPlayerRadius;
        for (class_3222 p : level.method_18456()) {
            double dd = p.method_5858(entity);
            if (dd <= best && !p.method_7325()) {
                best = dd;
                nearest = p;
            }
        }
        Entry en = new Entry();
        en.species = pk.getSpecies().getResourceIdentifier().toString();
        en.aspects = new ArrayList<>(pk.getAspects());
        en.pokemonUuid = pk.getUuid().toString();
        en.entityUuid = entity.method_5667().toString();
        en.time = System.currentTimeMillis();
        en.biome = biome.toString();
        en.nearest = nearest == null ? "" : nearest.method_7334().getName();
        en.loc = new Loc(level.method_27983().method_29177().toString(), entity.method_23317(), entity.method_23318(), entity.method_23321(), 0, 0);
        en.shiny = pk.getShiny();
        en.onlyTo = onlyTo == null ? "" : onlyTo.method_5667().toString();
        for (String c : cats) {
            Deque<Entry> dq = HISTORY.computeIfAbsent(c, k -> new ArrayDeque<>());
            dq.addFirst(en);
            while (dq.size() > Cfg.alerts.historySize) dq.removeLast();
        }
        BY_ENTITY.computeIfAbsent(en.entityUuid, k -> new ArrayList<>()).add(en);
        broadcast(pk, cats, en, onlyTo);
    }

    private static class_2561 biomeName(String biome) {
        class_2960 rl = class_2960.method_12829(biome);
        if (rl == null) return class_2561.method_43470(biome);
        return class_2561.method_43471("biome." + rl.method_12836() + "." + rl.method_12832());
    }

    private static String label(List<String> cats) {
        List<String> parts = new ArrayList<>();
        for (String c : cats) {
            AlertsConfig.Category cat = Cfg.alerts.categories.get(c);
            parts.add(cat.color + cat.label);
        }
        return String.join("&7, ", parts);
    }

    private static void broadcast(Pokemon pk, List<String> cats, Entry en, class_3222 onlyTo) {
        AlertsConfig.Category first = Cfg.alerts.categories.get(cats.get(0));
        class_5250 name = fr.cobblepulse.utils.pokemon.SpeciesNames.of(pk.getSpecies()).method_27661();
        String world = fr.cobblepulse.utils.teleport.Worlds.isMain(en.loc.world) ? ""
                : Msg.format("alerts.world_suffix", "world", fr.cobblepulse.utils.teleport.Worlds.plainName(en.loc.world));
        String text = Msg.format(en.nearest.isEmpty() ? "alerts.broadcast_nobody" : "alerts.broadcast",
                "categories", label(cats), "player", en.nearest, "color", first.color, "world", world);
        class_5250 base = Msg.splice(text, "pokemon", name.method_27696(TextUtil.styleOf(first.color)));
        class_5250 normal = spliceBiome(base, en);
        class_5250 staff = normal.method_27661().method_27694(s -> s
                .method_10949(new class_2568(class_2568.class_5247.field_24342, TextUtil.legacy(Msg.format("alerts.hover_coords",
                        "world", en.loc.shortWorld(), "coords", en.loc.coords()).replace("|", "\n"))))
                .method_10958(new class_2558(class_2558.class_2559.field_11745, "/execute in " + en.loc.world + " run tp @s "
                        + (int) en.loc.x + " " + (int) en.loc.y + " " + (int) en.loc.z)));
        lastBroadcast = text;
        lastBroadcastMessage = normal;
        for (class_3222 p : onlyTo != null ? List.of(onlyTo) : CobbleUtils.server().method_3760().method_14571()) {
            if (!Msg.reachable(p) || onlyTo == null && !Perms.player(p, Perms.ALERTS_RECEIVE)) continue;
            p.method_43496(Perms.perkOrOp(p, Perms.ALERTS_COORDS) ? staff : normal);
            if (first.sound) p.method_17356(net.minecraft.class_3417.field_14725.comp_349(), net.minecraft.class_3419.field_15250, 0.7f, 1.6f);
        }
    }

    /** Remplace %biome% par le nom traduit (cote client) du biome. */
    private static class_5250 spliceBiome(class_5250 in, Entry en) {
        class_5250 out = class_2561.method_43473();
        boolean done = false;
        for (class_2561 part : in.method_44746()) {
            String s = part.getString();
            int i = s.indexOf("%biome%");
            if (i < 0 || done) {
                out.method_10852(part);
                continue;
            }
            out.method_10852(class_2561.method_43470(s.substring(0, i)).method_10862(part.method_10866()));
            out.method_10852(biomeName(en.biome).method_27661().method_10862(part.method_10866()));
            out.method_10852(class_2561.method_43470(s.substring(i + 7)).method_10862(part.method_10866()));
            done = true;
        }
        return out;
    }

    /** Auto-test : capture simulee. */
    public static void testCapture(Pokemon pk, class_3222 player) {
        onCapture(pk, player);
    }

    private static void onCapture(Pokemon pk, class_3222 player) {
        String name = player == null ? "" : player.method_7334().getName();
        for (Entry e : tracked(pk.getUuid().toString())) {
            if (!open(e)) continue;
            outcome(e, "CAPTURED", name, Cfg.alerts.announceCapture && !name.isEmpty() ? "alerts.captured" : null);
        }
    }

    /** Auto-test : victoire en combat simulee. */
    public static void testDefeat(Pokemon pk, class_3222 player) {
        defeated(pk.getUuid().toString(), player == null ? "" : player.method_7334().getName());
    }

    /** Fin de combat : un Pokemon sauvage suivi a ete mis K.O. par un ou plusieurs joueurs. */
    private static void onVictory(List<com.cobblemon.mod.common.api.battles.model.actor.BattleActor> winners,
                                  List<com.cobblemon.mod.common.api.battles.model.actor.BattleActor> losers) {
        List<String> names = new ArrayList<>();
        for (var a : winners) {
            if (!(a instanceof com.cobblemon.mod.common.battles.actor.PlayerBattleActor)) continue;
            for (UUID u : a.getPlayerUUIDs()) {
                class_3222 p = fr.cobblepulse.utils.core.Players.online(u);
                if (p != null && !names.contains(p.method_7334().getName())) names.add(p.method_7334().getName());
            }
        }
        if (names.isEmpty()) return;
        for (var a : losers) {
            // l'entite d'un Pokemon sauvage K.O. n'est plus liee au combat : on passe par l'identifiant du Pokemon
            if (!(a instanceof com.cobblemon.mod.common.battles.actor.PokemonBattleActor pa) || pa.getPokemon() == null) continue;
            Set<String> ids = new HashSet<>();
            if (pa.getPokemon().getOriginalPokemon() != null) ids.add(pa.getPokemon().getOriginalPokemon().getUuid().toString());
            if (pa.getPokemon().getEffectedPokemon() != null) ids.add(pa.getPokemon().getEffectedPokemon().getUuid().toString());
            for (String id : ids) defeated(id, String.join(", ", names));
        }
    }

    private static void defeated(String pokemonUuid, String players) {
        for (Entry e : tracked(pokemonUuid)) {
            if (!open(e)) continue;
            outcome(e, "DEFEATED", players, Cfg.alerts.announceDefeat && !players.isEmpty() ? "alerts.defeated" : null);
        }
    }

    /** Mort d'un Pokemon suivi hors combat (epee, arc, chute...). En combat, c'est la victoire qui est annoncee. */
    public static void onDeath(class_1297 entity, net.minecraft.class_1282 source) {
        if (!(entity instanceof PokemonEntity pe)) return;
        List<Entry> list = BY_ENTITY.get(entity.method_5667().toString());
        if (list == null || pe.isBattling()) return;
        class_3222 killer = source != null && source.method_5529() instanceof class_3222 sp ? sp : null;
        String name = killer == null ? "" : killer.method_7334().getName();
        for (Entry e : new ArrayList<>(list)) {
            if (!open(e)) continue;
            outcome(e, "KILLED", name, Cfg.alerts.announceKill && killer != null ? "alerts.killed" : null);
        }
    }

    /** Entrees d'historique de ce Pokemon (une entree peut figurer dans plusieurs categories). */
    private static List<Entry> tracked(String pokemonUuid) {
        List<Entry> out = new ArrayList<>();
        for (Deque<Entry> dq : HISTORY.values()) for (Entry e : dq) if (pokemonUuid.equals(e.pokemonUuid) && !out.contains(e)) out.add(e);
        return out;
    }

    /**
     * Le sort de ce Pokemon peut-il encore etre fixe ? Oui s'il est actif, ou s'il vient d'etre marque « disparu » /
     * « mort » sans joueur : l'entite est retiree du monde avant que la capture ou la victoire soit signalee.
     */
    private static boolean open(Entry e) {
        if ("ACTIVE".equals(e.status)) return true;
        boolean provisional = ("DESPAWN".equals(e.status) || "KILLED".equals(e.status)) && (e.captor == null || e.captor.isEmpty());
        return provisional && System.currentTimeMillis() - e.statusTime < 60_000L;
    }

    private static List<String> categoriesOf(Entry e) {
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, Deque<Entry>> h : HISTORY.entrySet()) {
            if (h.getValue().contains(e) && Cfg.alerts.categories.get(h.getKey()) != null) out.add(h.getKey());
        }
        return out;
    }

    /** Fixe le sort d'un Pokemon rare et l'annonce (key null : pas d'annonce). */
    private static void outcome(Entry e, String status, String player, String key) {
        e.status = status;
        e.captor = player == null ? "" : player;
        e.statusTime = System.currentTimeMillis();
        List<String> cats = categoriesOf(e);
        if (key == null || cats.isEmpty() || !Cfg.alerts.enabled) return;
        AlertsConfig.Category first = Cfg.alerts.categories.get(cats.get(0));
        Species sp = null;
        try {
            sp = PokemonSpecies.getByIdentifier(class_2960.method_60654(e.species));
        } catch (Throwable ignored) {
        }
        class_5250 name = (sp == null ? class_2561.method_43470(e.species) : fr.cobblepulse.utils.pokemon.SpeciesNames.of(sp).method_27661()).method_27696(TextUtil.styleOf(first.color));
        String text = Msg.format(key, "categories", label(cats), "player", e.captor, "color", first.color);
        class_5250 msg = Msg.splice(text, "pokemon", name);
        lastOutcome = text;
        class_3222 only = null;
        if (e.onlyTo != null && !e.onlyTo.isEmpty()) {
            try {
                only = fr.cobblepulse.utils.core.Players.online(UUID.fromString(e.onlyTo));
            } catch (IllegalArgumentException ignored) {
            }
            if (only == null) return;
        }
        for (class_3222 p : only != null ? List.of(only) : CobbleUtils.server().method_3760().method_14571()) {
            if (!Msg.reachable(p) || only == null && !Perms.player(p, Perms.ALERTS_RECEIVE)) continue;
            p.method_43496(msg);
        }
    }

    /** Disparition d'une entite suivie (appele par l'evenement de dechargement Fabric). */
    public static void onUnload(class_1297 entity) {
        List<Entry> list = BY_ENTITY.get(entity.method_5667().toString());
        if (list == null) return;
        class_1297.class_5529 r = entity.method_35049();
        if (r == null || r == class_1297.class_5529.field_27000 || r == class_1297.class_5529.field_27001
                || r == class_1297.class_5529.field_27002) return;
        boolean killed = r == class_1297.class_5529.field_26998;
        // la capture ou la victoire est signalee apres la disparition de l'entite : le statut pose ici reste provisoire
        // pendant une minute (voir open) ; on laisse 2 s avant de le poser
        Scheduler.later(40, () -> {
            for (Entry e : list) {
                if ("ACTIVE".equals(e.status)) {
                    e.status = killed ? "KILLED" : "DESPAWN";
                    e.captor = "";
                    e.statusTime = System.currentTimeMillis();
                }
            }
            BY_ENTITY.remove(entity.method_5667().toString());
        });
    }

    // ------------------------------------------------------------------ interface

    private static class_1799 icon(Entry e, boolean staff) {
        class_1799 base;
        try {
            Species s = PokemonSpecies.getByIdentifier(class_2960.method_60654(e.species));
            base = s == null ? new class_1799(class_1802.field_8803) : PokemonItem.Companion.from(s, new HashSet<>(e.aspects), 1, null);
        } catch (Throwable t) {
            base = new class_1799(class_1802.field_8803);
        }
        Species s = PokemonSpecies.getByIdentifier(class_2960.method_60654(e.species));
        ItemBuilder b = ItemBuilder.of(base).name(class_2561.method_43473().method_10852(s == null ? class_2561.method_43470(e.species) : fr.cobblepulse.utils.pokemon.SpeciesNames.of(s).method_27661())
                .method_10852(class_2561.method_43470(e.shiny ? " ★" : "")));
        b.lore(Msg.format("alerts.icon_time", "time", TimeFmt.duration(System.currentTimeMillis() - e.time), "date", TimeFmt.date(e.time)));
        b.loreComponent(TextUtil.legacy(Msg.format("alerts.icon_biome")).method_10852(biomeName(e.biome).method_27661().method_27692(net.minecraft.class_124.field_1068)));
        if (!e.nearest.isEmpty()) b.lore(Msg.format("alerts.icon_nearest", "player", e.nearest));
        b.lore(switch (e.status) {
            case "CAPTURED" -> Msg.format("alerts.status_captured", "player", e.captor);
            case "DEFEATED" -> Msg.format("alerts.status_defeated", "player", e.captor);
            case "KILLED" -> e.captor == null || e.captor.isEmpty() ? Msg.format("alerts.status_dead") : Msg.format("alerts.status_killed", "player", e.captor);
            case "DESPAWN" -> Msg.format("alerts.status_despawn");
            default -> Msg.format("alerts.status_active");
        });
        if (staff && e.loc != null) b.lore("", Msg.format("alerts.icon_coords", "world", e.loc.shortWorld(), "coords", e.loc.coords()), Msg.format("alerts.icon_tp"));
        return b.build();
    }

    public static void openHistory(class_3222 p, String category) {
        if (!Cfg.alerts.enabled) {
            Msg.send(p, "alerts.disabled");
            return;
        }
        boolean staff = Perms.perkOrOp(p, Perms.ALERTS_COORDS);
        String cat = category == null || !CATEGORIES.contains(category) ? null : category;
        Gui g = new Gui(6, Msg.format("alerts.title") + (cat == null ? "" : " &8» " + Cfg.alerts.categories.get(cat).color + Cfg.alerts.categories.get(cat).label));
        for (int i = 0; i < 9; i++) g.set(i, Gui.pane());
        int col = 2;
        for (String c : CATEGORIES) {
            AlertsConfig.Category ac = Cfg.alerts.categories.get(c);
            if (ac == null) continue;
            g.button(col++, ItemBuilder.of(Reg.stack(ac.icon)).name(ac.color + ac.label).lore(Msg.format("alerts.cat_lore", "count", HISTORY.get(c).size()))
                    .glow(c.equals(cat)).build(), pl -> openHistory(pl, c));
        }
        List<Entry> entries = new ArrayList<>();
        if (cat != null) entries.addAll(HISTORY.get(cat));
        else {
            Set<Entry> seen = new HashSet<>();
            for (Deque<Entry> dq : HISTORY.values()) for (Entry e : dq) if (seen.add(e)) entries.add(e);
            entries.sort((a, b) -> Long.compare(b.time, a.time));
        }
        int slot = 9;
        for (Entry e : entries) {
            if (slot >= 45) break;
            g.button(slot++, icon(e, staff), pl -> {
                if (staff && e.loc != null) {
                    fr.cobblepulse.utils.gui.Gui.close(pl);
                    Teleports.perform(pl, e.loc, null, null);
                }
            });
        }
        if (entries.isEmpty()) g.set(31, ItemBuilder.of(class_1802.field_8077).name(Msg.format("alerts.none")).build());
        for (int i = 45; i < 54; i++) g.set(i, Gui.pane());
        g.button(49, ItemBuilder.of(class_1802.field_8691).name(Msg.format("general.back")).build(), Hub::open);
        if (Perms.admin(p, "alerts")) g.button(51, ItemBuilder.of(class_1802.field_16315).name(Msg.format("alerts.test_button")).lore(Msg.format("alerts.test_button_lore")).build(),
                SpawnAlerts::testMenu);
        g.open(p);
    }

    // ------------------------------------------------------------------ persistance

    private static Path file() {
        return Cfg.utilsRoot().resolve("data").resolve("spawn_history.json");
    }

    public static void save() {
        try {
            Cfg.writeAtomic(file(), Json.COMPACT.toJson(HISTORY));
        } catch (Exception e) {
            CobbleUtils.LOG.warn("[CobblePulse-Utils] Sauvegarde de l'historique des spawns : {}", e.toString());
        }
    }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Map<String, List<Entry>> m = Json.COMPACT.fromJson(Files.readString(f, StandardCharsets.UTF_8), new TypeToken<Map<String, List<Entry>>>() {}.getType());
            if (m == null) return;
            for (Map.Entry<String, List<Entry>> e : m.entrySet()) {
                Deque<Entry> dq = HISTORY.computeIfAbsent(e.getKey(), k -> new ArrayDeque<>());
                dq.clear();
                for (Entry en : e.getValue()) {
                    if ("ACTIVE".equals(en.status)) BY_ENTITY.computeIfAbsent(en.entityUuid, k -> new ArrayList<>()).add(en);
                    dq.addLast(en);
                }
            }
        } catch (Exception e) {
            CobbleUtils.LOG.warn("[CobblePulse-Utils] Lecture de l'historique des spawns : {}", e.toString());
        }
    }

    /** Auto-test : historique d'une categorie. */
    public static List<Entry> history(String cat) {
        return new ArrayList<>(HISTORY.getOrDefault(cat, new ArrayDeque<>()));
    }

    public static UUID entity(Entry e) {
        return UUID.fromString(e.entityUuid);
    }
}
