package fr.cobblepulse.utils.boss;

import fr.cobblepulse.utils.config.BossConfig;
import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.config.Reward;
import fr.cobblepulse.utils.core.ItemBuilder;
import fr.cobblepulse.utils.core.ItemSerial;
import fr.cobblepulse.utils.core.Msg;
import fr.cobblepulse.utils.core.Perms;
import fr.cobblepulse.utils.core.Reg;
import fr.cobblepulse.utils.core.Rewards;
import fr.cobblepulse.utils.gui.ChatInput;
import fr.cobblepulse.utils.gui.Gui;
import fr.cobblepulse.utils.staff.StaffPanel;
import java.util.ArrayList;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3222;

/** Editeur en jeu des Boss (cobblepulse.admin.boss) : reglages generaux, paliers et tables de butin. */
public final class BossEditor {
    private BossEditor() {}

    private static void save() {
        Cfg.boss.normalize();
        Cfg.save("boss.json", Cfg.boss);
    }

    static String fmt(double d) {
        return d == Math.rint(d) ? String.valueOf((long) d) : String.format(java.util.Locale.FRANCE, "%.2f", d);
    }

    public static void open(class_3222 p) {
        if (!Perms.admin(p, "boss")) {
            Msg.send(p, "general.no_permission");
            return;
        }
        Gui g = new Gui(4, Msg.format("boss.editor_title"));
        g.fill(Gui.pane());
        // paliers ordinaires sur la 2e ligne, paliers de Mega-Boss sur la 3e
        int normal = 10;
        int mega = 19;
        for (Map.Entry<String, BossConfig.Tier> e : Cfg.boss.tiers.entrySet()) {
            BossConfig.Tier t = e.getValue();
            String id = e.getKey();
            int slot = t.mega ? mega++ : normal++;
            if (t.mega ? slot > 25 : slot > 16) continue;
            g.button(slot, ItemBuilder.of(Reg.stack(t.icon)).name(t.color + t.name)
                    .lore(Msg.format("boss.editor_tier_lore", "min", t.levelMin, "max", t.levelMax, "weight", fmt(t.weight), "loot", t.loot.size(),
                            "ai", t.aiSkill, "ivs", t.perfectIvs, "scale", fmt(t.scale)))
                    .lore(t.mega ? Msg.format("boss.editor_tier_mega") : null)
                    .lore("", Msg.format("boss.editor_tier_click")).hideExtra().build(), pl -> tier(pl, id));
        }
        g.button(28, ItemBuilder.of(Cfg.boss.naturalSpawn ? class_1802.field_8131 : class_1802.field_8298)
                .name(Msg.format(Cfg.boss.naturalSpawn ? "boss.editor_spawn_on" : "boss.editor_spawn_off")).build(), pl -> {
            Cfg.boss.naturalSpawn = !Cfg.boss.naturalSpawn;
            save();
            open(pl);
        });
        g.button(29, ItemBuilder.of(class_1802.field_8287).name(Msg.format("boss.editor_chance", "chance", fmt(Cfg.boss.promotionChance))).build(),
                pl -> askNumber(pl, "boss.ask_chance", v -> Cfg.boss.promotionChance = v, () -> open(pl)));
        g.button(30, ItemBuilder.of(class_1802.field_8849).name(Msg.format("boss.editor_max", "max", Cfg.boss.maxActive)).build(),
                pl -> askNumber(pl, "boss.ask_max", v -> Cfg.boss.maxActive = (int) v, () -> open(pl)));
        g.button(31, ItemBuilder.of(class_1802.field_8557).name(Msg.format("boss.editor_lifetime", "minutes", Cfg.boss.lifetimeMinutes)).build(),
                pl -> askNumber(pl, "boss.ask_lifetime", v -> Cfg.boss.lifetimeMinutes = (int) v, () -> open(pl)));
        g.button(32, ItemBuilder.of(class_1802.field_27063).name(Msg.format("boss.editor_special", "chance", fmt(Cfg.boss.specialFormChance),
                "first", fmt(Cfg.boss.formItemFirstChance), "repeat", fmt(Cfg.boss.formItemRepeatChance))).lore(Msg.format("boss.editor_special_lore")).build(),
                (pl, c) -> {
                    if (c.right()) askNumber(pl, "boss.ask_repeat", v -> Cfg.boss.formItemRepeatChance = v, () -> open(pl));
                    else askNumber(pl, "boss.ask_special", v -> Cfg.boss.specialFormChance = v, () -> open(pl));
                });
        g.button(33, ItemBuilder.of(Cfg.boss.promoteLegendaries ? class_1802.field_8137 : class_1802.field_8450)
                .name(Msg.format(Cfg.boss.promoteLegendaries ? "boss.editor_legend_on" : "boss.editor_legend_off")).build(), pl -> {
            Cfg.boss.promoteLegendaries = !Cfg.boss.promoteLegendaries;
            save();
            open(pl);
        });
        g.set(4, ItemBuilder.of(class_1802.field_8712).name(Msg.format("boss.editor_info", "count", Bosses.activeCount())).build());
        g.button(27, ItemBuilder.of(class_1802.field_8691).name(Msg.format("general.back")).build(), StaffPanel::open);
        if (Perms.admin(p, "boss.spawn")) {
            g.button(34, ItemBuilder.of(class_1802.field_8849).name(Msg.format("boss.editor_test_all")).lore(Msg.format("boss.editor_test_all_lore")).build(), pl -> {
                fr.cobblepulse.utils.gui.Gui.close(pl);
                fr.cobblepulse.utils.command.RootCommands.spawnAllTiers(pl.method_5671());
            });
        }
        if (Perms.admin(p, "boss.clear")) {
            g.button(35, ItemBuilder.of(class_1802.field_8077).name(Msg.format("boss.editor_clear")).build(), pl -> {
                Msg.send(pl, "boss.cleared", "count", Bosses.clearAll());
                open(pl);
            });
        }
        g.open(p);
    }

    private static void askNumber(class_3222 p, String key, java.util.function.DoubleConsumer set, Runnable back) {
        ChatInput.ask(p, key, txt -> {
            try {
                set.accept(Double.parseDouble(txt.trim().replace(',', '.').replace("%", "")));
                save();
            } catch (NumberFormatException ignored) {
                Msg.send(p, "general.bad_number");
            }
            back.run();
        }, back);
    }

    public static void tier(class_3222 p, String id) {
        BossConfig.Tier t = Cfg.boss.tiers.get(id);
        if (t == null) {
            open(p);
            return;
        }
        Gui g = new Gui(6, Msg.format("boss.editor_tier_title", "tier", t.color + t.name));
        for (int i = 45; i < 54; i++) g.set(i, Gui.pane());
        int slot = 0;
        for (Reward r : new ArrayList<>(t.loot)) {
            if (slot >= 36) break;
            g.button(slot++, ItemBuilder.of(Rewards.icon(r)).name(Rewards.describe(r)).lore(Msg.format("dex.edit_reward_lore", "chance", fmt(r.chance))).build(), (pl, c) -> {
                if (c.shift()) {
                    t.loot.remove(r);
                    save();
                    tier(pl, id);
                } else {
                    askNumber(pl, "dex.ask_chance", v -> r.chance = Math.max(0, Math.min(100, v)), () -> tier(pl, id));
                }
            });
        }
        for (int i = 36; i < 45; i++) g.set(i, Gui.pane());
        if (Perms.admin(p, "boss.spawn")) {
            // tests : apparition, combat immediat, version Mega / Primo / Originelle
            g.button(39, ItemBuilder.of(class_1802.field_8849).name(Msg.format("boss.editor_test_spawn")).lore(Msg.format("boss.editor_test_spawn_lore")).build(), pl -> {
                fr.cobblepulse.utils.gui.Gui.close(pl);
                fr.cobblepulse.utils.command.RootCommands.spawnBoss(pl.method_5671(), id, null, "auto", false);
            });
            g.button(40, ItemBuilder.of(class_1802.field_8371).name(Msg.format("boss.editor_test_fight")).lore(Msg.format("boss.editor_test_fight_lore")).hideExtra().build(), pl -> {
                fr.cobblepulse.utils.gui.Gui.close(pl);
                fr.cobblepulse.utils.command.RootCommands.spawnBoss(pl.method_5671(), id, null, "auto", true);
            });
            g.button(41, ItemBuilder.of(class_1802.field_27063).name(Msg.format("boss.editor_test_mega")).lore(Msg.format("boss.editor_test_mega_lore")).build(), pl -> {
                fr.cobblepulse.utils.gui.Gui.close(pl);
                fr.cobblepulse.utils.command.RootCommands.spawnBoss(pl.method_5671(), id, null, "mega", false);
            });
        }
        g.button(45, ItemBuilder.of(class_1802.field_8691).name(Msg.format("general.back")).build(), BossEditor::open);
        g.button(46, ItemBuilder.of(class_1802.field_8106).name(Msg.format("dex.edit_add_item")).build(), pl -> {
            class_1799 hand = pl.method_6047();
            if (hand.method_7960()) {
                Msg.send(pl, "warps.edit_icon_empty");
                return;
            }
            t.loot.add(Reward.item(ItemSerial.toSnbt(hand), 100));
            save();
            tier(pl, id);
        });
        g.button(47, ItemBuilder.of(class_1802.field_8695).name(Msg.format("dex.edit_add_money")).build(), pl -> askNumber(pl, "dex.ask_money", v -> {
            if (v > 0) t.loot.add(Reward.money((long) v, 100));
        }, () -> tier(pl, id)));
        g.button(48, ItemBuilder.of(class_1802.field_8137).name(Msg.format("boss.editor_add_bp")).build(), pl -> askNumber(pl, "boss.ask_bp", v -> {
            if (v > 0) t.loot.add(Reward.bp((long) v, 100));
        }, () -> tier(pl, id)));
        g.button(49, ItemBuilder.of(class_1802.field_8866).name(Msg.format("dex.edit_add_command")).build(), pl -> ChatInput.ask(pl, "kits.ask_command", txt -> {
            t.loot.add(Reward.command(txt.startsWith("/") ? txt.substring(1) : txt, "", 100));
            save();
            tier(pl, id);
        }, () -> tier(pl, id)));
        g.button(50, ItemBuilder.of(class_1802.field_8287).name(Msg.format("boss.editor_levels", "min", t.levelMin, "max", t.levelMax)).build(),
                pl -> ChatInput.ask(pl, "boss.ask_levels", txt -> {
                    String[] parts = txt.trim().split("[\\s\\-/]+");
                    try {
                        t.levelMin = Integer.parseInt(parts[0]);
                        t.levelMax = Integer.parseInt(parts.length > 1 ? parts[1] : parts[0]);
                        save();
                    } catch (NumberFormatException ignored) {
                        Msg.send(pl, "general.bad_number");
                    }
                    tier(pl, id);
                }, () -> tier(pl, id)));
        g.button(51, ItemBuilder.of(class_1802.field_8857).name(Msg.format("boss.editor_stats")).lore(Msg.format("boss.editor_stats_lore",
                "weight", fmt(t.weight), "scale", fmt(t.scale), "ivs", t.perfectIvs, "ai", t.aiSkill, "cooldown", t.engageCooldownSeconds,
                "announce", t.announce ? "oui" : "non", "mega", t.mega ? "oui" : "non")).build(), pl -> ChatInput.ask(pl, "boss.ask_stats", txt -> {
            for (String kv : txt.trim().split("\\s+")) {
                String[] a = kv.split("=");
                if (a.length != 2) continue;
                try {
                    switch (a[0].toLowerCase(java.util.Locale.ROOT)) {
                        case "poids", "weight" -> t.weight = Double.parseDouble(a[1]);
                        case "taille", "scale" -> t.scale = Float.parseFloat(a[1]);
                        case "iv", "ivs" -> t.perfectIvs = Integer.parseInt(a[1]);
                        case "ia", "ai" -> t.aiSkill = Integer.parseInt(a[1]);
                        case "delai", "cooldown" -> t.engageCooldownSeconds = Long.parseLong(a[1]);
                        case "annonce", "announce" -> t.announce = Boolean.parseBoolean(a[1]) || a[1].equals("oui");
                        case "mega", "méga" -> t.mega = Boolean.parseBoolean(a[1]) || a[1].equals("oui");
                        default -> {
                        }
                    }
                } catch (NumberFormatException ignored) {
                }
            }
            save();
            tier(pl, id);
        }, () -> tier(pl, id)));
        g.button(52, ItemBuilder.of(Reg.stack(t.icon)).name(Msg.format("boss.editor_icon")).build(), pl -> {
            if (!pl.method_6047().method_7960()) t.icon = Reg.id(pl.method_6047().method_7909());
            save();
            tier(pl, id);
        });
        g.button(53, ItemBuilder.of(class_1802.field_8448).name(Msg.format("boss.editor_name")).build(), pl -> ChatInput.ask(pl, "boss.ask_name", txt -> {
            String[] parts = txt.trim().split("\\s+", 2);
            if (parts.length == 2 && parts[0].startsWith("&")) {
                t.color = parts[0];
                t.name = parts[1];
            } else t.name = txt.trim();
            save();
            tier(pl, id);
        }, () -> tier(pl, id)));
        g.open(p);
    }

    static Consumer<class_3222> back() {
        return BossEditor::open;
    }
}
