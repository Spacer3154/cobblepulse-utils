package fr.cobblepulse.utils.boss;

import com.cobblemon.mod.common.battles.BattleRegistry;
import fr.cobblepulse.utils.CobbleUtils;
import fr.cobblepulse.utils.core.ItemBuilder;
import fr.cobblepulse.utils.core.Msg;
import fr.cobblepulse.utils.core.Players;
import fr.cobblepulse.utils.core.TextUtil;
import fr.cobblepulse.utils.gui.Gui;
import fr.cobblepulse.utils.gui.Screens;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * Fenetre de butin apres une victoire contre un Boss : chaque objet peut etre recupere, lache au sol ou jete
 * (detruit), un par un ou tous ensemble. Fermer la fenetre place le reste dans l'inventaire : rien n'est perdu
 * sans un choix explicite. L'argent, les BP et les commandes sont remis directement, hors fenetre.
 */
public final class BossLoot {
    private static final int MAX_SHOWN = 45;

    private static final class Pending {
        final List<class_1799> items = new ArrayList<>();
        class_2561 title;
        /** Instant (ms) a partir duquel la fenetre peut s'ouvrir. */
        long ready;
        Gui gui;
        long destroyAsked;
    }

    private static final Map<UUID, Pending> PENDING = new ConcurrentHashMap<>();

    private BossLoot() {}

    /** Propose ces objets au joueur ; la fenetre s'ouvre une fois le combat termine. */
    public static void offer(class_3222 p, class_2561 title, List<class_1799> items) {
        if (items.isEmpty()) return;
        Pending pd = PENDING.computeIfAbsent(p.method_5667(), k -> new Pending());
        if (pd.gui != null) {
            // une fenetre est deja ouverte (deux Boss vaincus coup sur coup) : on la reconstruit avec tout le butin
            Gui old = pd.gui;
            pd.gui = null;
            if (Screens.hasSession(p.method_5667()) || p.field_7512 != p.field_7498) Gui.close(p);
            CobbleUtils.LOG.debug("[CobblePulse-Utils] Butin de Boss fusionne pour {} ({})", p.method_7334().getName(), old.size());
        }
        for (class_1799 st : items) if (!st.method_7960()) pd.items.add(st.method_7972());
        pd.title = title;
        // ecran du mod : le client attend lui-meme la fin de l'animation du combat ; coffre : delai fixe
        pd.ready = System.currentTimeMillis() + (Screens.enabled(p) ? 1000 : 4000);
    }

    /** Toutes les 10 ticks : ouvre les fenetres en attente des joueurs sortis de combat. */
    public static void tick() {
        if (PENDING.isEmpty()) return;
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Pending> en : new ArrayList<>(PENDING.entrySet())) {
            Pending pd = en.getValue();
            if (pd.gui != null || now < pd.ready) continue;
            class_3222 p = Players.online(en.getKey());
            if (p == null || p.method_14239()) {
                // deconnexion sans passage par flush (ne devrait pas arriver) : conserve 10 min puis abandonne
                if (now - pd.ready > 600_000L) PENDING.remove(en.getKey());
                continue;
            }
            try {
                if (BattleRegistry.getBattleByParticipatingPlayer(p) != null) continue;
            } catch (Throwable ignored) {
            }
            open(p);
        }
    }

    public static boolean has(UUID uuid) {
        return PENDING.containsKey(uuid);
    }

    /** Auto-test : objets encore en attente. */
    public static List<class_1799> pending(UUID uuid) {
        Pending pd = PENDING.get(uuid);
        List<class_1799> out = new ArrayList<>();
        if (pd != null) for (class_1799 st : pd.items) if (st != null && !st.method_7960()) out.add(st);
        return out;
    }

    public static boolean isOpen(UUID uuid) {
        Pending pd = PENDING.get(uuid);
        return pd != null && pd.gui != null;
    }

    public static void open(class_3222 p) {
        Pending pd = PENDING.get(p.method_5667());
        if (pd == null) return;
        pd.items.removeIf(st -> st == null || st.method_7960());
        // au-dela de la place affichable, le surplus va directement dans l'inventaire
        while (pd.items.size() > MAX_SHOWN) fr.cobblepulse.utils.core.Rewards.giveItem(p, pd.items.remove(pd.items.size() - 1));
        if (pd.items.isEmpty()) {
            PENDING.remove(p.method_5667());
            return;
        }
        int n = pd.items.size();
        int rows = Math.max(2, (n + 8) / 9 + 1);
        Gui g = new Gui(rows, pd.title);
        g.afterBattle(true);
        for (int i = 0; i < n; i++) {
            int slot = i;
            g.button(slot, icon(pd.items.get(i)), (pl, click) -> itemClick(pl, pd, g, slot, click));
        }
        int bar = (rows - 1) * 9;
        for (int i = bar; i < bar + 9; i++) g.set(i, Gui.pane());
        g.button(bar + 2, ItemBuilder.of(class_1802.field_8106).name(Msg.format("boss.loot_take_all")).lore(Msg.format("boss.loot_take_all_lore")).build(),
                pl -> takeAll(pl, pd, g));
        g.button(bar + 4, ItemBuilder.of(class_1802.field_8878).name(Msg.format("boss.loot_drop_all")).lore(Msg.format("boss.loot_drop_all_lore")).build(),
                pl -> dropAll(pl, pd, g));
        destroyButton(pd, g, false);
        g.onClose(pl -> closed(pl, pd, g));
        pd.gui = g;
        pd.destroyAsked = 0;
        g.open(p);
    }

    private static void destroyButton(Pending pd, Gui g, boolean confirm) {
        int slot = (g.rows() - 1) * 9 + 6;
        g.button(slot, ItemBuilder.of(confirm ? class_1802.field_8626 : class_1802.field_8187).name(Msg.format(confirm ? "boss.loot_destroy_confirm" : "boss.loot_destroy_all"))
                .lore(Msg.format("boss.loot_destroy_all_lore")).build(), pl -> destroyAll(pl, pd, g));
    }

    /** L'objet lui-meme (avec son infobulle), suivi du rappel des trois actions. */
    private static class_1799 icon(class_1799 st) {
        class_1799 d = st.method_7972();
        List<class_2561> lines = new ArrayList<>(d.method_57825(class_9334.field_49632, class_9290.field_49340).comp_2400());
        for (String part : Msg.format("boss.loot_item_lore").split("\n|\\|")) lines.add(TextUtil.item(part));
        d.method_57379(class_9334.field_49632, new class_9290(lines));
        return d;
    }

    private static boolean current(class_3222 p, Pending pd, Gui g) {
        return PENDING.get(p.method_5667()) == pd && pd.gui == g;
    }

    private static void itemClick(class_3222 p, Pending pd, Gui g, int slot, Gui.Click click) {
        if (!current(p, pd, g) || slot >= pd.items.size()) return;
        class_1799 st = pd.items.get(slot);
        if (st == null || st.method_7960()) return;
        if (click.shift()) {
            pd.items.set(slot, class_1799.field_8037);
        } else if (click.right()) {
            drop(p, st);
            pd.items.set(slot, class_1799.field_8037);
        } else {
            class_1799 rest = take(p, st);
            pd.items.set(slot, rest);
            if (!rest.method_7960()) Msg.send(p, "boss.loot_full");
        }
        refresh(p, pd, g, slot);
    }

    private static void refresh(class_3222 p, Pending pd, Gui g, int slot) {
        class_1799 st = pd.items.get(slot);
        if (st.method_7960()) g.set(slot, class_1799.field_8037);
        else g.button(slot, icon(st), (pl, click) -> itemClick(pl, pd, g, slot, click));
        if (pd.items.stream().allMatch(class_1799::method_7960)) finish(p, pd);
    }

    private static void takeAll(class_3222 p, Pending pd, Gui g) {
        if (!current(p, pd, g)) return;
        boolean full = false;
        for (int i = 0; i < pd.items.size(); i++) {
            class_1799 st = pd.items.get(i);
            if (st.method_7960()) continue;
            class_1799 rest = take(p, st);
            pd.items.set(i, rest);
            if (!rest.method_7960()) full = true;
        }
        if (full) {
            Msg.send(p, "boss.loot_full");
            for (int i = 0; i < pd.items.size(); i++) {
                int slot = i;
                class_1799 st = pd.items.get(i);
                if (st.method_7960()) g.set(slot, class_1799.field_8037);
                else g.button(slot, icon(st), (pl, click) -> itemClick(pl, pd, g, slot, click));
            }
            return;
        }
        Msg.send(p, "boss.loot_taken");
        finish(p, pd);
    }

    private static void dropAll(class_3222 p, Pending pd, Gui g) {
        if (!current(p, pd, g)) return;
        for (class_1799 st : pd.items) if (!st.method_7960()) drop(p, st);
        pd.items.clear();
        Msg.send(p, "boss.loot_dropped");
        finish(p, pd);
    }

    /** Destruction definitive : un second clic dans les 5 secondes confirme. */
    private static void destroyAll(class_3222 p, Pending pd, Gui g) {
        if (!current(p, pd, g)) return;
        long now = System.currentTimeMillis();
        if (now - pd.destroyAsked > 5000) {
            pd.destroyAsked = now;
            destroyButton(pd, g, true);
            fr.cobblepulse.utils.core.Scheduler.later(100, () -> {
                if (current(p, pd, g) && System.currentTimeMillis() - pd.destroyAsked >= 5000) destroyButton(pd, g, false);
            });
            return;
        }
        pd.items.clear();
        Msg.send(p, "boss.loot_destroyed");
        finish(p, pd);
    }

    private static void finish(class_3222 p, Pending pd) {
        PENDING.remove(p.method_5667(), pd);
        pd.gui = null;
        Gui.close(p);
        Players.saveNow(p);
    }

    /** Fenetre fermee sans choix (Echap, autre menu) : le reste va dans l'inventaire, le surplus au sol. */
    private static void closed(class_3222 p, Pending pd, Gui g) {
        if (!current(p, pd, g)) return;
        PENDING.remove(p.method_5667(), pd);
        pd.gui = null;
        boolean any = false;
        for (class_1799 st : pd.items) if (!st.method_7960()) {
            fr.cobblepulse.utils.core.Rewards.giveItem(p, st.method_7972());
            any = true;
        }
        pd.items.clear();
        if (any && !p.method_14239()) Msg.send(p, "boss.loot_closed");
    }

    /** Deconnexion ou arret du serveur : le butin en attente est place dans l'inventaire avant l'enregistrement du joueur. */
    public static void flush(class_3222 p) {
        Pending pd = PENDING.remove(p.method_5667());
        if (pd == null) return;
        pd.gui = null;
        for (class_1799 st : pd.items) if (st != null && !st.method_7960()) fr.cobblepulse.utils.core.Rewards.giveItem(p, st.method_7972());
        pd.items.clear();
    }

    public static void flushAll() {
        for (UUID u : new ArrayList<>(PENDING.keySet())) {
            class_3222 p = Players.online(u);
            if (p != null) flush(p);
        }
        PENDING.clear();
    }

    /** Place dans l'inventaire ce qui rentre. @return le reste (vide si tout est entre) */
    private static class_1799 take(class_3222 p, class_1799 st) {
        class_1799 rest = st.method_7972();
        int max = Math.max(1, rest.method_7914());
        int left = rest.method_7947();
        while (left > 0) {
            class_1799 part = rest.method_46651(Math.min(max, left));
            int asked = part.method_7947();
            p.method_31548().method_7394(part);
            int added = asked - part.method_7947();
            left -= added;
            if (added < asked) break;
        }
        return left <= 0 ? class_1799.field_8037 : rest.method_46651(left);
    }

    private static void drop(class_3222 p, class_1799 st) {
        int max = Math.max(1, st.method_7914());
        int left = st.method_7947();
        while (left > 0) {
            class_1799 part = st.method_46651(Math.min(max, left));
            left -= part.method_7947();
            p.method_7328(part, false);
        }
    }
}
