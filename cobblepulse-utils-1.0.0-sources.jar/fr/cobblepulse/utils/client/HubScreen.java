package fr.cobblepulse.utils.client;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import fr.cobblepulse.utils.core.TextUtil;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5481;

/** Hub Central (touche H, /menu, /cp) : outils joueurs, passerelles CobblePulse et panneau Staff. */
public final class HubScreen extends class_437 {
    record Tile(String id, int section, class_2561 name, class_1799 icon, List<class_2561> lore) {}

    private static final String[] SECTIONS = {"", "Outils", "Écosystème CobblePulse", "Staff"};
    private final List<Tile> tiles = new ArrayList<>();
    private final class_2561 sub;
    private final List<int[]> boxes = new ArrayList<>();
    int hovered = -1;
    /** Auto-test : tuile survolee forcee. */
    int debugHover = -1;

    public HubScreen(JsonObject o) {
        super(TextUtil.legacy(Ui.str(o, "title", "CobblePulse")));
        this.sub = TextUtil.legacy("&7" + Ui.str(o, "player", "") + "  &8•  &7Solde : &e" + Ui.str(o, "balance", "-"));
        for (JsonElement e : Ui.arr(o, "tiles")) {
            JsonObject t = e.getAsJsonObject();
            List<class_2561> lore = new ArrayList<>();
            for (JsonElement l : Ui.arr(t, "lore")) lore.add(TextUtil.legacy(l.getAsString()));
            tiles.add(new Tile(Ui.str(t, "id", ""), Ui.num(t, "section", 1), TextUtil.legacy(Ui.str(t, "name", "?")), Ui.item(Ui.str(t, "icon", "")), lore));
        }
    }

    public List<String> tileIds() {
        List<String> out = new ArrayList<>();
        for (Tile t : tiles) out.add(t.id);
        return out;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private int panelW() {
        return Math.min(field_22789 - 24, 560);
    }

    private int tileW = 104;

    private int tileW() {
        return tileW;
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float pt) {
        method_52752(g);
        int pw = panelW();
        int cols = Math.max(2, (pw - 20) / (104 + 6));
        // les tuiles occupent toute la largeur du panneau
        tileW = (pw - 20 - (cols - 1) * 6) / cols;
        int rowsTotal = 0;
        for (int s = 1; s <= 3; s++) {
            int n = count(s);
            if (n > 0) rowsTotal += (n + cols - 1) / cols;
        }
        int sections = 0;
        for (int s = 1; s <= 3; s++) if (count(s) > 0) sections++;
        int ph = Math.min(field_22790 - 16, 46 + sections * 16 + rowsTotal * 52 + 10);
        int px = (field_22789 - pw) / 2;
        int py = Math.max(8, (field_22790 - ph) / 2);
        Ui.panel(g, px, py, pw, ph, Ui.PANEL, Ui.BORDER);
        g.method_25294(px + 1, py + 1, px + pw - 1, py + 34, Ui.PANEL2);
        g.method_51439(field_22793, field_22785, px + 12, py + 8, Ui.TEXT, false);
        g.method_51439(field_22793, sub, px + 12, py + 20, Ui.MUTED, false);
        String hint = "Échap pour fermer";
        g.method_51433(field_22793, hint, px + pw - 12 - field_22793.method_1727(hint), py + 8, Ui.MUTED, false);
        boxes.clear();
        hovered = -1;
        int y = py + 42;
        for (int s = 1; s <= 3; s++) {
            if (count(s) == 0) continue;
            g.method_51433(field_22793, SECTIONS[s], px + 12, y, s == 3 ? Ui.ERROR : Ui.ACCENT, false);
            g.method_25294(px + 12 + field_22793.method_1727(SECTIONS[s]) + 6, y + 4, px + pw - 12, y + 5, Ui.BORDER);
            y += 14;
            int i = 0;
            for (int k = 0; k < tiles.size(); k++) {
                Tile t = tiles.get(k);
                if (t.section != s) continue;
                int c = i % cols;
                int r = i / cols;
                int tx = px + 10 + c * (tileW() + 6);
                int ty = y + r * 52;
                boolean hov = Ui.in(mx, my, tx, ty, tileW(), 46) || debugHover == k;
                if (hov) hovered = k;
                Ui.panel(g, tx, ty, tileW(), 46, hov ? Ui.CARD_ON : Ui.CARD, hov ? Ui.ACCENT : Ui.BORDER);
                List<class_5481> lines = field_22793.method_1728(t.name, tileW() - 8);
                boolean two = lines.size() > 1;
                float sc = two ? 1.25f : 1.5f;
                g.method_51448().method_22903();
                g.method_51448().method_46416(tx + tileW() / 2f - 8 * sc, ty + (two ? 3 : 4), 0);
                g.method_51448().method_22905(sc, sc, 1f);
                g.method_51427(t.icon, 0, 0);
                g.method_51448().method_22909();
                int ly = two ? ty + 25 : ty + 30;
                for (int li = 0; li < Math.min(2, lines.size()); li++) {
                    g.method_51430(field_22793, lines.get(li), tx + (tileW() - field_22793.method_30880(lines.get(li))) / 2, ly + li * 10, Ui.TEXT, true);
                }
                boxes.add(new int[]{k, tx, ty, tileW(), 46});
                i++;
            }
            y += ((count(s) + cols - 1) / cols) * 52 + 2;
        }
        super.method_25394(g, mx, my, pt);
        if (hovered >= 0) {
            Tile t = tiles.get(hovered);
            List<class_2561> tip = new ArrayList<>();
            tip.add(t.name);
            tip.addAll(t.lore);
            g.method_51434(field_22793, tip, mx, my);
        }
    }

    private int count(int s) {
        int n = 0;
        for (Tile t : tiles) if (t.section == s) n++;
        return n;
    }

    @Override
    public boolean method_25402(double mx, double my, int button) {
        for (int[] b : boxes) {
            if (Ui.in(mx, my, b[1], b[2], b[3], b[4])) {
                click(tiles.get(b[0]).id);
                return true;
            }
        }
        return super.method_25402(mx, my, button);
    }

    public void click(String id) {
        JsonObject o = new JsonObject();
        o.addProperty("id", id);
        Ui.send("hub_tile", o);
        if (field_22787 != null && field_22787.field_1755 == this) method_25419();
    }

    @Override
    public void method_25420(class_332 g, int mx, int my, float pt) {
    }
}
