package fr.cobblepulse.utils.client;

import com.google.gson.JsonObject;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7923;

/**
 * Selecteur d'objet des editeurs (boutique, recompenses, icones) : tous les objets du jeu et des mods, recherche par nom
 * ou identifiant, filtre par mod. Clic = selection, double-clic ou Valider = choix.
 */
public final class ItemPickerScreen extends class_437 implements Overlay {
    private record Entry(class_2960 id, class_1799 stack, String key) {}

    class_437 parent;
    private final class_2561 prompt;
    private final List<Entry> all = new ArrayList<>();
    private final List<Entry> visible = new ArrayList<>();
    private final List<String> mods = new ArrayList<>();
    private int modIndex;
    private class_342 search;
    private class_4185 ok;
    private Entry selected;
    private double scroll;
    private int px, py, pw, ph, ax, ay, aw, ah, cols;
    private long lastClick;
    private Entry lastClicked;

    ItemPickerScreen(class_437 parent, class_2561 prompt, String initial) {
        super(class_2561.method_43470("Choisir un objet"));
        this.parent = parent;
        this.prompt = prompt;
        TreeSet<String> ns = new TreeSet<>();
        for (class_1792 item : class_7923.field_41178) {
            if (item == class_1802.field_8162) continue;
            class_2960 id = class_7923.field_41178.method_10221(item);
            class_1799 st = new class_1799(item);
            all.add(new Entry(id, st, MenuScreen.norm(st.method_7964().getString() + " " + id)));
            ns.add(id.method_12836());
        }
        // Cobblemon puis Minecraft en premier, puis les autres mods
        all.sort((a, b) -> {
            int ra = rank(a.id.method_12836()), rb = rank(b.id.method_12836());
            if (ra != rb) return Integer.compare(ra, rb);
            int c = a.id.method_12836().compareTo(b.id.method_12836());
            return c != 0 ? c : Integer.compare(class_7923.field_41178.method_10206(a.stack.method_7909()), class_7923.field_41178.method_10206(b.stack.method_7909()));
        });
        mods.add("");
        if (ns.remove("cobblemon")) mods.add("cobblemon");
        if (ns.remove("minecraft")) mods.add("minecraft");
        mods.addAll(ns);
        class_2960 init = class_2960.method_12829(initial == null ? "" : initial.trim().split("\\s+")[0]);
        if (init != null) for (Entry e : all) if (e.id.equals(init)) selected = e;
    }

    private static int rank(String ns) {
        return ns.equals("cobblemon") ? 0 : ns.equals("minecraft") ? 1 : 2;
    }

    private void refilter() {
        visible.clear();
        String q = MenuScreen.norm(search == null ? "" : search.method_1882().trim());
        String mod = mods.get(modIndex);
        for (Entry e : all) {
            if (!mod.isEmpty() && !e.id.method_12836().equals(mod)) continue;
            if (!q.isEmpty() && !e.key.contains(q)) continue;
            visible.add(e);
        }
        scroll = 0;
    }

    @Override
    protected void method_25426() {
        if (parent != null) parent.method_25423(field_22787, field_22789, field_22790);
        pw = Math.min(field_22789 - 24, 640);
        ph = field_22790 - 16;
        px = (field_22789 - pw) / 2;
        py = 8;
        String prev = search == null ? "" : search.method_1882();
        search = new class_342(field_22793, px + pw - 12 - 160, py + 6, 160, 16, class_2561.method_43470("Recherche"));
        search.method_47404(class_2561.method_43470("Nom ou identifiant…").method_54663(Ui.MUTED & 0xFFFFFF));
        search.method_1852(prev);
        search.method_1863(v -> refilter());
        method_37063(search);
        method_48265(search);
        method_37063(class_4185.method_46430(class_2561.method_43470(modLabel()), b -> {
            modIndex = (modIndex + 1) % mods.size();
            b.method_25355(class_2561.method_43470(modLabel()));
            refilter();
        }).method_46434(px + pw - 12 - 160 - 6 - 110, py + 5, 110, 18).method_46431());
        int by = py + ph - 26;
        ok = method_37063(class_4185.method_46430(class_2561.method_43470("Valider"), b -> submit()).method_46434(px + pw - 12 - 200, by, 96, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Annuler"), b -> method_25419()).method_46434(px + pw - 12 - 98, by, 96, 20).method_46431());
        ax = px + 10;
        ay = py + 32;
        aw = pw - 20;
        ah = ph - 32 - 34;
        cols = Math.max(1, (aw - 6) / 20);
        refilter();
        if (selected != null) {
            int idx = visible.indexOf(selected);
            if (idx >= 0) scroll = Math.max(0, (idx / cols) * 20 - ah / 2);
        }
    }

    private String modLabel() {
        String m = mods.get(modIndex);
        return m.isEmpty() ? "Tous les mods" : Ui.pretty(m);
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float pt) {
        if (parent != null) parent.method_25394(g, -1, -1, pt);
        else method_52752(g);
        g.method_51448().method_22903();
        g.method_51448().method_46416(0, 0, 400);
        g.method_25294(0, 0, field_22789, field_22790, 0x88000000);
        Ui.panel(g, px, py, pw, ph, Ui.PANEL, Ui.ACCENT);
        g.method_51433(field_22793, field_22793.method_27523(prompt.getString(), pw - 320), px + 12, py + 10, Ui.TEXT, false);
        g.method_51448().method_22909();
        // grille (rendu des objets a leur profondeur habituelle, au-dessus du voile)
        int maxScroll = Math.max(0, ((visible.size() + cols - 1) / cols) * 20 - ah);
        scroll = class_3532.method_15350(scroll, 0, maxScroll);
        g.method_51448().method_22903();
        g.method_51448().method_46416(0, 0, 410);
        g.method_44379(ax, ay, ax + aw, ay + ah);
        Entry hov = null;
        int first = (int) (scroll / 20) * cols;
        for (int i = first; i < visible.size(); i++) {
            int r = i / cols, c = i % cols;
            int x = ax + c * 20;
            int y = ay + r * 20 - (int) scroll;
            if (y > ay + ah) break;
            Entry e = visible.get(i);
            boolean h = Ui.in(mx, my, x, y, 20, 20) && Ui.in(mx, my, ax, ay, aw, ah);
            if (h) hov = e;
            g.method_25294(x + 1, y + 1, x + 19, y + 19, e == selected ? 0xFF3B5F7A : h ? 0xFF2C3A4E : 0xFF1A202A);
            g.method_51427(e.stack, x + 2, y + 2);
        }
        g.method_44380();
        if (maxScroll > 0) {
            int knob = Math.max(16, ah * ah / (ah + maxScroll));
            int ky = ay + (int) ((ah - knob) * (scroll / maxScroll));
            g.method_25294(ax + aw - 3, ay, ax + aw, ay + ah, 0x40FFFFFF);
            g.method_25294(ax + aw - 3, ky, ax + aw, ky + knob, Ui.ACCENT);
        }
        // selection
        int fy = py + ph - 26;
        if (selected != null) {
            g.method_51427(selected.stack, px + 12, fy + 2);
            g.method_51439(field_22793, selected.stack.method_7964(), px + 32, fy + 2, Ui.TEXT, false);
            g.method_51433(field_22793, selected.id.toString(), px + 32, fy + 12, Ui.MUTED, false);
        } else {
            g.method_51433(field_22793, visible.size() + " objet(s) — cliquez pour choisir", px + 12, fy + 6, Ui.MUTED, false);
        }
        g.method_51448().method_22909();
        if (ok != null) ok.field_22763 = selected != null;
        g.method_51448().method_22903();
        g.method_51448().method_46416(0, 0, 420);
        super.method_25394(g, mx, my, pt);
        g.method_51448().method_22909();
        if (hov != null) {
            g.method_51448().method_22903();
            g.method_51448().method_46416(0, 0, 500);
            g.method_51434(field_22793, List.of(hov.stack.method_7964(), class_2561.method_43470(hov.id.toString()).method_54663(Ui.MUTED & 0xFFFFFF)), mx, my);
            g.method_51448().method_22909();
        }
    }

    @Override
    public void method_25420(class_332 g, int mx, int my, float pt) {
    }

    @Override
    public boolean method_25402(double mx, double my, int button) {
        if (super.method_25402(mx, my, button)) return true;
        if (!Ui.in(mx, my, ax, ay, aw, ah)) return false;
        int c = (int) ((mx - ax) / 20);
        int r = (int) ((my - ay + scroll) / 20);
        int i = r * cols + c;
        if (c < 0 || c >= cols || i < 0 || i >= visible.size()) return false;
        Entry e = visible.get(i);
        long now = System.currentTimeMillis();
        boolean dbl = e == lastClicked && now - lastClick < 350;
        selected = e;
        lastClicked = e;
        lastClick = now;
        if (dbl) submit();
        return true;
    }

    @Override
    public boolean method_25401(double mx, double my, double sx, double sy) {
        scroll -= sy * 24;
        return true;
    }

    @Override
    public boolean method_25404(int key, int scan, int mods) {
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && selected != null) {
            submit();
            return true;
        }
        return super.method_25404(key, scan, mods);
    }

    void submit() {
        if (selected == null) return;
        JsonObject o = new JsonObject();
        o.addProperty("text", selected.id.toString());
        Ui.send("prompt_answer", o);
        if (field_22787 != null) field_22787.method_1507(null);
    }

    @Override
    public void method_25419() {
        JsonObject o = new JsonObject();
        o.addProperty("cancel", true);
        Ui.send("prompt_answer", o);
        if (field_22787 != null) field_22787.method_1507(parent instanceof MenuScreen ? parent : null);
    }

    @Override
    public class_437 parentScreen() {
        return parent;
    }

    @Override
    public void setParentScreen(class_437 s) {
        parent = s;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // auto-test
    int visibleCount() {
        return visible.size();
    }

    void setQuery(String q) {
        if (search != null) search.method_1852(q);
    }

    boolean choose(String id) {
        for (Entry e : all) if (e.id.toString().equals(id)) {
            selected = e;
            return true;
        }
        return false;
    }
}
