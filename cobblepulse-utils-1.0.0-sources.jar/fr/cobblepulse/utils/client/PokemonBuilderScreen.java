package fr.cobblepulse.utils.client;

import com.cobblemon.mod.common.api.Priority;
import com.cobblemon.mod.common.api.abilities.PotentialAbility;
import com.cobblemon.mod.common.api.pokeball.PokeBalls;
import com.cobblemon.mod.common.api.pokemon.Natures;
import com.cobblemon.mod.common.api.pokemon.PokemonSpecies;
import com.cobblemon.mod.common.api.types.ElementalType;
import com.cobblemon.mod.common.api.types.ElementalTypes;
import com.cobblemon.mod.common.client.gui.summary.widgets.ModelWidget;
import com.cobblemon.mod.common.item.PokemonItem;
import com.cobblemon.mod.common.pokeball.PokeBall;
import com.cobblemon.mod.common.pokemon.FormData;
import com.cobblemon.mod.common.pokemon.Nature;
import com.cobblemon.mod.common.pokemon.RenderablePokemon;
import com.cobblemon.mod.common.pokemon.Species;
import com.google.gson.JsonObject;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7923;

/**
 * Createur de Pokemon des editeurs (boutique) : espece choisie dans la liste complete (fakemons compris), forme
 * (Mega comprises), niveau, chromatique, IV, nature, talent (cache compris), genre, Ball, objet tenu, Tera, surnom,
 * capacites. Produit la fiche texte de la boutique ; aucun Pokemon n'est necessaire dans l'equipe.
 */
public final class PokemonBuilderScreen extends class_437 implements Overlay {
    /** Champ a choix : valeur ecrite dans la fiche + libelle affiche. */
    private static final class Choice {
        final String label;
        final List<String> values = new ArrayList<>();
        final List<class_2561> names = new ArrayList<>();
        int index;
        class_4185 button;

        Choice(String label) {
            this.label = label;
        }

        void add(String value, class_2561 name) {
            values.add(value);
            names.add(name);
        }

        String value() {
            return values.isEmpty() ? "" : values.get(Math.min(index, values.size() - 1));
        }

        class_2561 name() {
            return names.isEmpty() ? class_2561.method_43470("—") : names.get(Math.min(index, names.size() - 1));
        }

        void select(String v) {
            int i = values.indexOf(v);
            index = Math.max(0, i);
        }
    }

    class_437 parent;
    private final class_2561 prompt;
    private final List<Species> all = new ArrayList<>();
    private final List<Species> filtered = new ArrayList<>();
    private Species species;
    private class_342 search, level, held, nick, moves;
    private class_4185 shinyBtn, ok;
    private boolean shiny;
    private final Choice form = new Choice("Forme");
    private final Choice ivs = new Choice("IV");
    private final Choice nature = new Choice("Nature");
    private final Choice ability = new Choice("Talent");
    private final Choice gender = new Choice("Genre");
    private final Choice ball = new Choice("Ball");
    private final Choice tera = new Choice("Tera");
    private final Map<String, String> initial = new LinkedHashMap<>();
    private double listScroll;
    private ModelWidget model;
    private int px, py, pw, ph, lx, ly, lw, lh, fx, fw;

    PokemonBuilderScreen(class_437 parent, class_2561 prompt, String initialSpec) {
        super(class_2561.method_43470("Créer un Pokémon"));
        this.parent = parent;
        this.prompt = prompt;
        for (Species s : PokemonSpecies.getSpecies()) {
            if (!s.getImplemented() && "cobblemon".equals(s.getResourceIdentifier().method_12836())) continue;
            all.add(s);
        }
        all.sort(Comparator.comparingInt(Species::getNationalPokedexNumber).thenComparing(s -> s.getResourceIdentifier().toString()));
        ivs.add("", class_2561.method_43470("Aléatoires"));
        ivs.add("31,31,31,31,31,31", class_2561.method_43470("Tous parfaits (6×31)"));
        ivs.add("31,0,31,31,31,31", class_2561.method_43470("Parfaits sauf Attaque (0)"));
        ivs.add("31,31,31,31,31,0", class_2561.method_43470("Parfaits sauf Vitesse (0)"));
        nature.add("", class_2561.method_43470("Aléatoire"));
        List<Nature> natures = new ArrayList<>(Natures.all());
        natures.sort(Comparator.comparing(n -> class_2561.method_43471(n.getDisplayName()).getString()));
        for (Nature n : natures) nature.add(n.getName().method_12832(), class_2561.method_43471(n.getDisplayName()));
        ball.add("", class_2561.method_43470("Poké Ball"));
        for (PokeBall b : PokeBalls.all()) {
            if (b.getName().method_12832().equals("poke_ball")) continue;
            ball.add(b.getName().method_12836().equals("cobblemon") ? b.getName().method_12832() : b.getName().toString(), b.item().method_7848());
        }
        tera.add("", class_2561.method_43470("Par défaut"));
        for (ElementalType t : ElementalTypes.all()) tera.add(t.getName(), t.getDisplayName());
        tera.add("stellar", class_2561.method_43470("Stellaire"));
        parse(initialSpec);
        Species init = initial.containsKey("") ? find(initial.get("")) : null;
        selectSpecies(init != null ? init : all.isEmpty() ? null : all.get(0), init != null);
    }

    private void parse(String spec) {
        if (spec == null || spec.isBlank()) return;
        String[] t = spec.trim().split("\\s+");
        initial.put("", t[0]);
        for (int i = 1; i < t.length; i++) {
            String k = t[i].contains("=") ? t[i].substring(0, t[i].indexOf('=')).toLowerCase(Locale.ROOT) : t[i].toLowerCase(Locale.ROOT);
            String v = t[i].contains("=") ? t[i].substring(t[i].indexOf('=') + 1) : "true";
            initial.put(switch (k) {
                case "lvl", "level", "nv" -> "niveau";
                case "chromatique" -> "shiny";
                case "ability" -> "talent";
                case "held", "item" -> "objet";
                case "form" -> "forme";
                case "gender" -> "genre";
                case "nick" -> "surnom";
                case "moves", "capacités" -> "capacites";
                case "iv" -> "ivs";
                default -> k;
            }, v);
        }
    }

    private Species find(String id) {
        String raw = id.toLowerCase(Locale.ROOT);
        class_2960 rl = class_2960.method_12829(raw.contains(":") ? raw : "cobblemon:" + raw);
        Species s = rl == null ? null : PokemonSpecies.getByIdentifier(rl);
        if (s != null) return s;
        for (Species sp : all) if (sp.getName().equalsIgnoreCase(raw) || fr.cobblepulse.utils.pokemon.SpeciesNames.text(sp).equalsIgnoreCase(raw)) return sp;
        return null;
    }

    private FormData currentForm() {
        if (species == null) return null;
        String f = form.value();
        if (f.isEmpty()) return species.getStandardForm();
        for (FormData d : species.getForms()) if (d.formOnlyShowdownId().equals(f)) return d;
        return species.getStandardForm();
    }

    private void selectSpecies(Species s, boolean applyInitial) {
        species = s;
        form.values.clear();
        form.names.clear();
        form.index = 0;
        form.add("", class_2561.method_43470("Forme de base"));
        if (s != null) {
            for (FormData d : s.getForms()) {
                String n = d.getName();
                String label = n;
                if (n != null && n.toLowerCase(Locale.ROOT).startsWith("mega")) label = "Méga " + n.substring(4).replace("-", " ").trim() + " (combat)";
                form.add(d.formOnlyShowdownId(), class_2561.method_43470(label.trim()));
            }
        }
        gender.values.clear();
        gender.names.clear();
        gender.index = 0;
        gender.add("", class_2561.method_43470(s != null && s.getMaleRatio() < 0 ? "Asexué" : "Aléatoire"));
        if (s != null && s.getMaleRatio() > 0) gender.add("male", class_2561.method_43470("Mâle"));
        if (s != null && s.getMaleRatio() >= 0 && s.getMaleRatio() < 1) gender.add("female", class_2561.method_43470("Femelle"));
        if (applyInitial) {
            form.select(initial.getOrDefault("forme", ""));
            gender.select(initial.getOrDefault("genre", ""));
            shiny = initial.containsKey("shiny") && !initial.get("shiny").equalsIgnoreCase("false");
            ivs.select(initial.getOrDefault("ivs", ""));
            nature.select(initial.getOrDefault("nature", ""));
            ball.select(initial.getOrDefault("ball", ""));
            tera.select(initial.getOrDefault("tera", ""));
        }
        refreshAbilities(applyInitial);
        rebuildModel();
        refreshButtons();
    }

    private void refreshAbilities(boolean applyInitial) {
        String prev = ability.value();
        ability.values.clear();
        ability.names.clear();
        ability.index = 0;
        ability.add("", class_2561.method_43470("Aléatoire (normal)"));
        FormData f = currentForm();
        if (f != null) {
            Set<String> seen = new HashSet<>();
            for (PotentialAbility a : f.getAbilities()) {
                String n = a.getTemplate().getName();
                if (!seen.add(n)) continue;
                boolean hidden = a.getPriority() == Priority.LOW;
                ability.add(n, class_2561.method_43471(a.getTemplate().getDisplayName()).method_27693(hidden ? " (caché)" : ""));
            }
        }
        ability.select(applyInitial ? initial.getOrDefault("talent", "") : prev);
    }

    private void rebuildModel() {
        model = null;
        if (species == null || field_22787 == null) return;
        Set<String> aspects = new HashSet<>();
        if (shiny) aspects.add("shiny");
        FormData f = currentForm();
        if (f != null) aspects.addAll(f.getAspects());
        try {
            model = new ModelWidget(lx + lw + 14, py + 34, 110, 110, new RenderablePokemon(species, aspects, class_1799.field_8037), 1.6f, 325f, -10.0, false, false, 15);
        } catch (Throwable t) {
            model = null;
        }
    }

    private void refilter() {
        filtered.clear();
        String q = MenuScreen.norm(search == null ? "" : search.method_1882().trim());
        for (Species s : all) {
            if (q.isEmpty() || MenuScreen.norm(fr.cobblepulse.utils.pokemon.SpeciesNames.text(s)).contains(q) || s.getResourceIdentifier().toString().contains(q)
                    || (q.chars().allMatch(Character::isDigit) && String.valueOf(s.getNationalPokedexNumber()).equals(q.replaceFirst("^0+(?=.)", "")))) {
                filtered.add(s);
            }
        }
        listScroll = 0;
    }

    @Override
    protected void method_25426() {
        if (parent != null) parent.method_25423(field_22787, field_22789, field_22790);
        pw = Math.min(field_22789 - 24, 640);
        ph = field_22790 - 16;
        px = (field_22789 - pw) / 2;
        py = 8;
        lx = px + 10;
        lw = 150;
        ly = py + 50;
        lh = ph - 50 - 36;
        fx = lx + lw + 140;
        fw = px + pw - 10 - fx;
        String prevSearch = search == null ? "" : search.method_1882();
        search = method_37063(new class_342(field_22793, lx, py + 30, lw, 16, class_2561.method_43470("Espèce")));
        search.method_47404(class_2561.method_43470("Espèce ou n°…").method_54663(Ui.MUTED & 0xFFFFFF));
        search.method_1852(prevSearch);
        search.method_1863(v -> refilter());
        refilter();
        int y = py + 30;
        int cw = fw - 70;
        int cx = fx + 70;
        cycle(form, cx, y, cw, () -> {
            refreshAbilities(false);
            rebuildModel();
        });
        y += 20;
        level = field(cx, y, cw, initialOr(level, "niveau", "5"), "1 à 100");
        y += 20;
        shinyBtn = method_37063(class_4185.method_46430(class_2561.method_43473(), b -> {
            shiny = !shiny;
            rebuildModel();
            refreshButtons();
        }).method_46434(cx, y, cw, 18).method_46431());
        y += 20;
        cycle(ivs, cx, y, cw, null);
        y += 20;
        cycle(nature, cx, y, cw, null);
        y += 20;
        cycle(ability, cx, y, cw, null);
        y += 20;
        cycle(gender, cx, y, cw, null);
        y += 20;
        cycle(ball, cx, y, cw, null);
        y += 20;
        held = field(cx, y, cw, initialOr(held, "objet", ""), "ex. cobblemon:leftovers");
        y += 20;
        cycle(tera, cx, y, cw, null);
        y += 20;
        nick = field(cx, y, cw, initialOr(nick, "surnom", "").replace('_', ' '), "facultatif");
        y += 20;
        moves = field(cx, y, cw, initialOr(moves, "capacites", ""), "ex. thunderbolt,quick_attack");
        int by = py + ph - 26;
        ok = method_37063(class_4185.method_46430(class_2561.method_43470("Valider"), b -> submit()).method_46434(px + pw - 12 - 200, by, 96, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Annuler"), b -> method_25419()).method_46434(px + pw - 12 - 98, by, 96, 20).method_46431());
        rebuildModel();
        refreshButtons();
    }

    private String initialOr(class_342 old, String key, String def) {
        return old != null ? old.method_1882() : initial.getOrDefault(key, def);
    }

    private class_342 field(int x, int y, int w, String value, String hint) {
        class_342 b = method_37063(new class_342(field_22793, x, y + 1, w, 16, class_2561.method_43473()));
        b.method_1880(200);
        b.method_1852(value);
        b.method_47404(class_2561.method_43470(hint).method_54663(Ui.MUTED & 0xFFFFFF));
        return b;
    }

    private void cycle(Choice c, int x, int y, int w, Runnable after) {
        c.button = method_37063(class_4185.method_46430(class_2561.method_43473(), b -> {
            if (!c.values.isEmpty()) c.index = (c.index + (method_25442() ? c.values.size() - 1 : 1)) % c.values.size();
            if (after != null) after.run();
            refreshButtons();
        }).method_46434(x, y, w, 18).method_46431());
    }

    private void refreshButtons() {
        for (Choice c : new Choice[]{form, ivs, nature, ability, gender, ball, tera}) {
            if (c.button != null) c.button.method_25355(c.name());
        }
        if (shinyBtn != null) shinyBtn.method_25355(class_2561.method_43470(shiny ? "§e★ Chromatique" : "☆ Normal"));
    }

    /** Fiche au format de la boutique. */
    String spec() {
        if (species == null) return "";
        class_2960 id = species.getResourceIdentifier();
        StringBuilder b = new StringBuilder(id.method_12836().equals("cobblemon") ? id.method_12832() : id.toString());
        int lv = 5;
        try {
            lv = class_3532.method_15340(Integer.parseInt(level == null ? "5" : level.method_1882().trim()), 1, 250);
        } catch (Exception ignored) {
        }
        b.append(" niveau=").append(lv);
        if (shiny) b.append(" shiny");
        add(b, "forme", form.value());
        add(b, "ivs", ivs.value());
        add(b, "nature", nature.value());
        add(b, "talent", ability.value());
        add(b, "genre", gender.value());
        add(b, "ball", ball.value());
        add(b, "objet", held == null ? "" : held.method_1882().trim().replace(' ', '_'));
        add(b, "tera", tera.value());
        add(b, "surnom", nick == null ? "" : nick.method_1882().trim().replace(' ', '_'));
        add(b, "capacites", moves == null ? "" : moves.method_1882().trim().replace(" ", ""));
        return b.toString();
    }

    private static void add(StringBuilder b, String k, String v) {
        if (v != null && !v.isBlank()) b.append(' ').append(k).append('=').append(v);
    }

    private boolean heldValid() {
        String v = held == null ? "" : held.method_1882().trim();
        if (v.isEmpty()) return true;
        class_2960 rl = class_2960.method_12829(v.contains(":") ? v : "cobblemon:" + v);
        return rl != null && class_7923.field_41178.method_10250(rl);
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float pt) {
        if (parent != null) parent.method_25394(g, -1, -1, pt);
        else method_52752(g);
        g.method_51448().method_22903();
        g.method_51448().method_46416(0, 0, 300);
        g.method_25294(0, 0, field_22789, field_22790, 0x88000000);
        Ui.panel(g, px, py, pw, ph, Ui.PANEL, Ui.ACCENT);
        g.method_51433(field_22793, field_22793.method_27523(prompt.getString(), pw - 24), px + 12, py + 12, Ui.TEXT, false);
        String[] labels = {"Forme", "Niveau", "Chromatique", "IV", "Nature", "Talent", "Genre", "Ball", "Objet tenu", "Tera", "Surnom", "Capacités"};
        for (int i = 0; i < labels.length; i++) g.method_51433(field_22793, labels[i], fx, py + 35 + i * 20, Ui.MUTED, false);
        if (!heldValid()) g.method_51433(field_22793, "objet inconnu", fx, py + 35 + 8 * 20 + 9, Ui.ERROR, false);
        Ui.panel(g, lx, ly, lw, lh, Ui.CARD, Ui.BORDER);
        Ui.panel(g, lx + lw + 10, py + 30, 118, 118, Ui.CARD, Ui.BORDER);
        if (species != null) {
            g.method_27534(field_22793, fr.cobblepulse.utils.pokemon.SpeciesNames.of(species), lx + lw + 69, py + 154, Ui.GOLD);
            g.method_25300(field_22793, field_22793.method_27523(form.name().getString(), 124), lx + lw + 69, py + 166, Ui.MUTED);
        }
        String sp = spec();
        g.method_51433(field_22793, field_22793.method_27523(sp, pw - 230), px + 12, py + ph - 20, Ui.MUTED, false);
        g.method_51448().method_22909();
        // modele et liste (objets/Pokemon au-dessus du voile)
        g.method_51448().method_22903();
        g.method_51448().method_46416(0, 0, 310);
        if (model != null) {
            try {
                model.method_25394(g, mx, my, pt);
            } catch (Throwable t) {
                model = null;
            }
        }
        int rows = lh / 18;
        int maxScroll = Math.max(0, filtered.size() - rows);
        int start = (int) class_3532.method_15350(listScroll, 0, maxScroll);
        g.method_44379(lx + 1, ly + 1, lx + lw - 1, ly + lh - 1);
        for (int i = 0; i < rows && start + i < filtered.size(); i++) {
            Species s = filtered.get(start + i);
            int ry = ly + 1 + i * 18;
            boolean hov = Ui.in(mx, my, lx, ry, lw, 18);
            if (s == species || hov) g.method_25294(lx + 1, ry, lx + lw - 1, ry + 18, s == species ? Ui.CARD_ON : 0x40FFFFFF);
            try {
                g.method_51427(PokemonItem.Companion.from(s, new String[0]), lx + 3, ry + 1);
            } catch (Throwable ignored) {
            }
            g.method_51433(field_22793, field_22793.method_27523(fr.cobblepulse.utils.pokemon.SpeciesNames.text(s), lw - 26), lx + 22, ry + 5, s == species ? Ui.GOLD : Ui.TEXT, false);
        }
        g.method_44380();
        g.method_51448().method_22909();
        if (ok != null) ok.field_22763 = species != null && heldValid();
        g.method_51448().method_22903();
        g.method_51448().method_46416(0, 0, 320);
        super.method_25394(g, mx, my, pt);
        g.method_51448().method_22909();
    }

    @Override
    public void method_25420(class_332 g, int mx, int my, float pt) {
    }

    @Override
    public boolean method_25402(double mx, double my, int button) {
        if (super.method_25402(mx, my, button)) return true;
        if (Ui.in(mx, my, lx, ly, lw, lh)) {
            int i = (int) class_3532.method_15350(listScroll, 0, Math.max(0, filtered.size() - lh / 18)) + (int) ((my - ly - 1) / 18);
            if (i >= 0 && i < filtered.size()) {
                selectSpecies(filtered.get(i), false);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean method_25401(double mx, double my, double sx, double sy) {
        if (Ui.in(mx, my, lx, ly, lw, lh)) {
            listScroll = Math.max(0, listScroll - sy * 3);
            return true;
        }
        return super.method_25401(mx, my, sx, sy);
    }

    @Override
    public boolean method_25404(int key, int scan, int mods) {
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && ok != null && ok.field_22763) {
            submit();
            return true;
        }
        return super.method_25404(key, scan, mods);
    }

    void submit() {
        if (species == null) return;
        JsonObject o = new JsonObject();
        o.addProperty("text", spec());
        Ui.send("prompt_answer", o);
        if (field_22787 != null) field_22787.method_1507(null);
    }

    @Override
    public void method_25419() {
        JsonObject o = new JsonObject();
        o.addProperty("cancel", true);
        Ui.send("prompt_answer", o);
        if (field_22787 != null) field_22787.method_1507(parent instanceof MenuScreen ? parent : null);
    }

    @Override
    public class_437 parentScreen() {
        return parent;
    }

    @Override
    public void setParentScreen(class_437 s) {
        parent = s;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // auto-test
    void chooseSpecies(String id) {
        Species s = find(id);
        if (s != null) selectSpecies(s, false);
    }

    void setShinyFlag(boolean v) {
        shiny = v;
        rebuildModel();
        refreshButtons();
    }

    void setLevel(int v) {
        if (level != null) level.method_1852(String.valueOf(v));
    }

    void setIvsPerfect() {
        ivs.index = 1;
        refreshButtons();
    }

    boolean setFormNamed(String part) {
        for (int i = 0; i < form.names.size(); i++) {
            if (form.names.get(i).getString().toLowerCase(Locale.ROOT).contains(part.toLowerCase(Locale.ROOT))) {
                form.index = i;
                refreshAbilities(false);
                rebuildModel();
                refreshButtons();
                return true;
            }
        }
        return false;
    }

    int formCount() {
        return form.values.size();
    }
}
