package fr.cobblepulse.utils.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import fr.cobblepulse.utils.core.Json;
import fr.cobblepulse.utils.net.Payloads;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1074;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_7923;

/** Couleurs et petites aides de dessin partagees par le Hub et le Wiki. */
public final class Ui {
    public static final int BG = 0xD80B0E13;
    public static final int PANEL = 0xF0141922;
    public static final int PANEL2 = 0xF01B2230;
    public static final int CARD = 0xFF1A202A;
    public static final int CARD_ON = 0xFF263347;
    public static final int BORDER = 0xFF2E3A4C;
    public static final int ACCENT = 0xFF5FD3F3;
    public static final int GOLD = 0xFFFFD24A;
    public static final int TEXT = 0xFFE8ECF2;
    public static final int MUTED = 0xFF8E9AAB;
    public static final int OK = 0xFF6BE07A;
    public static final int ERROR = 0xFFFF6B6B;
    public static final int PURPLE = 0xFFC48CFF;

    private Ui() {}

    public static class_327 font() {
        return class_310.method_1551().field_1772;
    }

    public static void send(String action, JsonObject args) {
        if (!ClientPlayNetworking.canSend(Payloads.Action.TYPE)) return;
        ClientPlayNetworking.send(new Payloads.Action(action, args == null ? "{}" : Json.COMPACT.toJson(args)));
    }

    public static void panel(class_332 g, int x, int y, int w, int h, int fill, int border) {
        g.method_25294(x, y, x + w, y + h, fill);
        g.method_25294(x, y, x + w, y + 1, border);
        g.method_25294(x, y + h - 1, x + w, y + h, border);
        g.method_25294(x, y, x + 1, y + h, border);
        g.method_25294(x + w - 1, y, x + w, y + h, border);
    }

    public static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && my >= y && mx < x + w && my < y + h;
    }

    public static class_1799 item(String id) {
        if (id == null || id.isBlank()) return class_1799.field_8037;
        class_2960 rl = class_2960.method_12829(id.contains(":") ? id : "minecraft:" + id);
        if (rl == null || !class_7923.field_41178.method_10250(rl)) return new class_1799(class_1802.field_8407);
        return new class_1799(class_7923.field_41178.method_10223(rl));
    }

    /** Traduction avec repli lisible quand la cle n'existe pas (biomes de mods, fakemons). */
    public static class_2561 tr(String key, String fallback) {
        if (key == null || key.isBlank()) return class_2561.method_43470(fallback == null ? "" : fallback);
        if (class_1074.method_4663(key)) return class_2561.method_43471(key);
        return class_2561.method_43470(fallback != null && !fallback.isBlank() ? fallback : key);
    }

    public static String pretty(String path) {
        String p = path.contains(":") ? path.substring(path.indexOf(':') + 1) : path;
        p = p.contains("/") ? p.substring(p.lastIndexOf('/') + 1) : p;
        StringBuilder b = new StringBuilder();
        for (String part : p.split("[_\\-]")) {
            if (part.isEmpty()) continue;
            if (b.length() > 0) b.append(' ');
            b.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return b.toString();
    }

    public static class_2561 biome(String id) {
        class_2960 rl = class_2960.method_12829(id);
        if (rl == null) return class_2561.method_43470(id);
        return tr("biome." + rl.method_12836() + "." + rl.method_12832().replace('/', '.'), pretty(rl.method_12832()));
    }

    public static class_2561 block(String id) {
        if (id.startsWith("#")) return class_2561.method_43470(pretty(id.substring(1)) + " (tag)");
        class_2960 rl = class_2960.method_12829(id);
        if (rl == null) return class_2561.method_43470(id);
        if (class_7923.field_41175.method_10250(rl)) return class_7923.field_41175.method_10223(rl).method_9518();
        return class_2561.method_43470(pretty(rl.method_12832()));
    }

    public static class_2561 itemName(String id) {
        class_2960 rl = class_2960.method_12829(id == null ? "" : id);
        if (rl != null && class_7923.field_41178.method_10250(rl)) return class_7923.field_41178.method_10223(rl).method_7848();
        return class_2561.method_43470(id == null ? "?" : pretty(id));
    }

    public static String str(JsonObject o, String k, String def) {
        JsonElement e = o == null ? null : o.get(k);
        return e == null || e.isJsonNull() ? def : e.getAsString();
    }

    public static int num(JsonObject o, String k, int def) {
        JsonElement e = o == null ? null : o.get(k);
        return e == null || e.isJsonNull() ? def : e.getAsInt();
    }

    public static double dbl(JsonObject o, String k, double def) {
        JsonElement e = o == null ? null : o.get(k);
        return e == null || e.isJsonNull() ? def : e.getAsDouble();
    }

    public static boolean bool(JsonObject o, String k, boolean def) {
        JsonElement e = o == null ? null : o.get(k);
        return e == null || e.isJsonNull() ? def : e.getAsBoolean();
    }

    public static JsonArray arr(JsonObject o, String k) {
        JsonElement e = o == null ? null : o.get(k);
        return e != null && e.isJsonArray() ? e.getAsJsonArray() : new JsonArray();
    }

    public static JsonObject obj(JsonObject o, String k) {
        JsonElement e = o == null ? null : o.get(k);
        return e != null && e.isJsonObject() ? e.getAsJsonObject() : new JsonObject();
    }
}
