package fr.cobblepulse.utils.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import fr.cobblepulse.utils.CobbleUtils;
import fr.cobblepulse.utils.net.Payloads;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/** Cote client : touche du Hub (H par defaut, configurable), ecrans Hub et Wiki. */
public final class UtilsClient implements ClientModInitializer {
    /** Menu recu pendant un combat et a n'afficher qu'apres (fenetre de butin d'un Boss). */
    private static JsonObject deferredMenu;
    private static int deferredTicks;
    private static int calmTicks;

    private static boolean inBattle() {
        try {
            return com.cobblemon.mod.common.client.CobblemonClient.INSTANCE.getBattle() != null;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void showMenu(class_310 mc, JsonObject o) {
        if (mc.field_1755 instanceof MenuScreen m) m.update(o);
        else if (mc.field_1755 instanceof Overlay ov) {
            if (ov.parentScreen() instanceof MenuScreen m) m.update(o);
            else ov.setParentScreen(new MenuScreen(o));
        } else mc.method_1507(new MenuScreen(o));
    }

    /** Auto-test : une fenetre attend-elle la fin du combat ? */
    public static boolean hasDeferredMenu() {
        return deferredMenu != null;
    }
    private static class_304 hubKey;
    private static class_304 wikiKey;

    @Override
    public void onInitializeClient() {
        hubKey = KeyBindingHelper.registerKeyBinding(new class_304("key.cobblepulse_utils.hub", class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_H, "key.categories.cobblepulse_utils"));
        wikiKey = KeyBindingHelper.registerKeyBinding(new class_304("key.cobblepulse_utils.wiki", class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_UNKNOWN, "key.categories.cobblepulse_utils"));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (deferredMenu != null) {
                deferredTicks++;
                calmTicks = inBattle() ? 0 : calmTicks + 1;
                if (mc.field_1724 == null) deferredMenu = null;
                else if (calmTicks >= 10 || deferredTicks > 600) {
                    JsonObject o = deferredMenu;
                    deferredMenu = null;
                    showMenu(mc, o);
                }
            }
            while (hubKey.method_1436()) {
                if (mc.field_1724 != null && mc.field_1755 == null) Ui.send("hub_open", null);
            }
            while (wikiKey.method_1436()) {
                if (mc.field_1724 != null && mc.field_1755 == null) mc.method_1507(new WikiScreen(null));
            }
        });
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Data.TYPE, (payload, ctx) -> ctx.client().execute(() -> receive(payload.kind(), payload.json())));
        // les menus couvrent le chat : les messages du serveur s'affichent dans l'ecran ouvert
        net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            class_310 mc = class_310.method_1551();
            if (mc.field_1755 instanceof MenuScreen m) m.notice(message);
            else if (mc.field_1755 instanceof Overlay ov && ov.parentScreen() instanceof MenuScreen m) m.notice(message);
        });
        if ("true".equals(System.getProperty("cobblepulse_utils.livetest"))) ClientSelfTest.install();
        CobbleUtils.LOG.info("[CobblePulse-Utils] Client initialise");
    }

    static void receive(String kind, String json) {
        class_310 mc = class_310.method_1551();
        JsonObject o;
        try {
            o = JsonParser.parseString(json).getAsJsonObject();
        } catch (Exception e) {
            CobbleUtils.LOG.warn("[CobblePulse-Utils] Donnees illisibles ({}) : {}", kind, e.toString());
            return;
        }
        switch (kind) {
            case "hub" -> mc.method_1507(new HubScreen(o));
            case "species_names" -> {
                java.util.Map<String, String> names = new java.util.HashMap<>();
                for (var e : o.entrySet()) if (e.getValue().isJsonPrimitive()) names.put(e.getKey(), e.getValue().getAsString());
                fr.cobblepulse.utils.pokemon.SpeciesNames.accept(names);
            }
            case "menu" -> {
                // fenetre de butin : on laisse le combat Cobblemon finir son animation avant de l'afficher
                if (Ui.bool(o, "after_battle", false) && !(mc.field_1755 instanceof MenuScreen) && inBattle()) {
                    deferredMenu = o;
                    deferredTicks = 0;
                    calmTicks = 0;
                } else {
                    deferredMenu = null;
                    showMenu(mc, o);
                }
            }
            case "menu_close" -> {
                deferredMenu = null;
                if (mc.field_1755 instanceof MenuScreen || mc.field_1755 instanceof Overlay) mc.method_1507(null);
            }
            case "pick" -> {
                class_2561 title = class_2561.method_43470("");
                try {
                    var conn = mc.method_1562();
                    var c = conn == null ? null : class_2561.class_2562.method_10877(Ui.str(o, "title", ""), conn.method_29091());
                    if (c != null) title = c;
                } catch (Exception ignored) {
                }
                class_437 parent = mc.field_1755 instanceof MenuScreen ? mc.field_1755 : null;
                String value = Ui.str(o, "value", "");
                if ("pokemon".equals(Ui.str(o, "kind", ""))) mc.method_1507(new PokemonBuilderScreen(parent, title, value));
                else mc.method_1507(new ItemPickerScreen(parent, title, value));
            }
            case "prompt" -> {
                class_2561 text = class_2561.method_43470(Ui.str(o, "text", ""));
                try {
                    var conn = mc.method_1562();
                    var c = conn == null ? null : class_2561.class_2562.method_10877(Ui.str(o, "text", ""), conn.method_29091());
                    if (c != null) text = c;
                } catch (Exception ignored) {
                }
                class_437 parent = mc.field_1755 instanceof MenuScreen ? mc.field_1755 : null;
                mc.method_1507(new PromptScreen(parent, text));
            }
            case "wiki_open" -> {
                String sp = o.has("species") ? o.get("species").getAsString() : null;
                if (mc.field_1755 instanceof WikiScreen w && sp != null) {
                    var s = com.cobblemon.mod.common.api.pokemon.PokemonSpecies.getByIdentifier(net.minecraft.class_2960.method_60654(sp));
                    if (s != null) w.select(s);
                } else mc.method_1507(new WikiScreen(sp));
            }
            case "wiki_species" -> {
                if (mc.field_1755 instanceof WikiScreen w) w.onSpecies(o);
            }
            case "wiki_bosses" -> {
                if (mc.field_1755 instanceof WikiScreen w) w.onBosses(o);
            }
            default -> {
            }
        }
    }
}
