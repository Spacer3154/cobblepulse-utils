package fr.cobblepulse.utils.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.LiteralCommandNode;
import fr.cobblepulse.utils.CobbleUtils;
import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.config.CommandsConfig;
import fr.cobblepulse.utils.core.Msg;
import fr.cobblepulse.utils.core.Perms;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_3222;

/**
 * Enregistrement des commandes depuis commands.json (activation + alias).
 * Chaque alias recoit son propre arbre complet (les redirections Brigadier ne gerent pas les commandes sans argument).
 * Un noeud existant du meme nom (vanilla, Cobblemon, autre mod) est remplace et journalise.
 */
public final class Cmd {
    /** Noeuds remplaces entierement (vanilla / Cobblemon, remplacement voulu : /reply, /ignore, /list par grade, /pc permissionne). */
    private static final Set<String> EXPECTED = Set.of("msg", "tell", "w", "list", "pc");
    /** Commandes vanilla conservees telles quelles (seuls nos alias sont ajoutes, ex. /gm). */
    private static final Set<String> KEEP_VANILLA = Set.of("gamemode", "tp", "teleport", "kick", "ban", "pardon");
    private static final List<String> REPLACED = new ArrayList<>();

    private Cmd() {}

    public static LiteralArgumentBuilder<class_2168> lit(String n) {
        return class_2170.method_9247(n);
    }

    public static List<String> replaced() {
        return REPLACED;
    }

    /** Commande joueur (noeud cobblepulse.command.<name>). */
    public static void player(CommandDispatcher<class_2168> d, String name, Function<String, LiteralArgumentBuilder<class_2168>> tree) {
        register(d, name, Perms.cmdReq(name), tree);
    }

    /** Commande staff (noeud cobblepulse.admin.<node>). */
    public static void admin(CommandDispatcher<class_2168> d, String name, String node, Function<String, LiteralArgumentBuilder<class_2168>> tree) {
        register(d, name, Perms.adminReq(node), tree);
    }

    private static void register(CommandDispatcher<class_2168> d, String name, Predicate<class_2168> req,
                                 Function<String, LiteralArgumentBuilder<class_2168>> tree) {
        CommandsConfig.Entry e = Cfg.commands.get(name);
        if (!e.enabled) return;
        List<String> labels = new ArrayList<>();
        labels.add(name);
        for (String a : e.aliases) {
            String al = a == null ? "" : a.trim().toLowerCase(java.util.Locale.ROOT);
            if (!al.isEmpty() && !labels.contains(al)) labels.add(al);
        }
        for (String label : labels) {
            CommandNode<class_2168> existing = d.getRoot().getChild(label);
            if (existing == null) {
                d.register(tree.apply(label).requires(req));
            } else if (KEEP_VANILLA.contains(label)) {
                CobbleUtils.LOG.debug("[CobblePulse-Utils] /{} vanilla conservee", label);
            } else if (EXPECTED.contains(label)) {
                removeChild(d.getRoot(), label);
                d.register(tree.apply(label).requires(req));
            } else {
                // commande d'un autre mod (ex. /pokedex, /pokeheal, /pokebox de Cobblemon) : fusion,
                // notre commande gere la forme sans argument, ses sous-commandes restent disponibles
                REPLACED.add(label);
                mergeInto(d, label, tree.apply(label).requires(req));
                CobbleUtils.LOG.info("[CobblePulse-Utils] /{} existait deja : fusion (ses sous-commandes restent disponibles)", label);
            }
        }
    }

    public static void removeExisting(CommandDispatcher<class_2168> d, String label) {
        CommandNode<class_2168> old = d.getRoot().getChild(label);
        if (old == null) return;
        removeChild(d.getRoot(), label);
        if (!EXPECTED.contains(label)) {
            REPLACED.add(label);
            CobbleUtils.LOG.info("[CobblePulse-Utils] Commande /{} existante remplacee (desactivable dans commands.json)", label);
        }
    }

    @SuppressWarnings("unchecked")
    public static void removeChild(CommandNode<class_2168> parent, String name) {
        for (String f : new String[]{"children", "literals", "arguments"}) {
            try {
                Field field = CommandNode.class.getDeclaredField(f);
                field.setAccessible(true);
                ((Map<String, ?>) field.get(parent)).remove(name);
            } catch (ReflectiveOperationException ex) {
                CobbleUtils.LOG.warn("[CobblePulse-Utils] Retrait de /{} impossible : {}", name, ex.toString());
            }
        }
    }

    /** Ajoute une condition alternative (OU) a un noeud existant : ex. /tp accessible avec cobblepulse.admin.tp. */
    @SuppressWarnings("unchecked")
    public static void allowAlso(CommandDispatcher<class_2168> d, String label, Predicate<class_2168> extra) {
        CommandNode<class_2168> node = d.getRoot().getChild(label);
        if (node == null) return;
        try {
            Field f = CommandNode.class.getDeclaredField("requirement");
            f.setAccessible(true);
            Predicate<class_2168> old = (Predicate<class_2168>) f.get(node);
            f.set(node, (Predicate<class_2168>) src -> old.test(src) || extra.test(src));
        } catch (ReflectiveOperationException ex) {
            CobbleUtils.LOG.warn("[CobblePulse-Utils] Permission supplementaire sur /{} impossible : {}", label, ex.toString());
        }
    }

    /**
     * Fusionne notre racine avec un noeud existant d'un autre mod (ex. /cp du mod Clans) :
     * nos sous-commandes priment, les siennes absentes chez nous sont conservees.
     * @return les sous-commandes d'origine (pour chainer, ex. reload)
     */
    public static Map<String, CommandNode<class_2168>> mergeInto(CommandDispatcher<class_2168> d, String label,
                                                                        LiteralArgumentBuilder<class_2168> ours) {
        CommandNode<class_2168> old = d.getRoot().getChild(label);
        Map<String, CommandNode<class_2168>> previous = new java.util.LinkedHashMap<>();
        if (old != null) {
            for (CommandNode<class_2168> c : old.getChildren()) previous.put(c.getName(), c);
            removeChild(d.getRoot(), label);
        }
        LiteralCommandNode<class_2168> node = d.register(ours);
        for (Map.Entry<String, CommandNode<class_2168>> e : previous.entrySet()) {
            if (node.getChild(e.getKey()) == null) node.addChild(e.getValue());
        }
        return previous;
    }

    public interface PlayerAction {
        int run(class_3222 p) throws CommandSyntaxException;
    }

    /** Execute une action reservee aux joueurs. */
    public static int asPlayer(CommandContext<class_2168> ctx, PlayerAction action) throws CommandSyntaxException {
        if (!ctx.getSource().method_43737()) {
            Msg.send(ctx.getSource(), "general.players_only");
            return 0;
        }
        return action.run(ctx.getSource().method_9207());
    }

    public static int run(CommandContext<class_2168> ctx, Consumer<class_3222> action) throws CommandSyntaxException {
        return asPlayer(ctx, p -> {
            action.accept(p);
            return 1;
        });
    }
}
