package fr.cobblepulse.utils.core;

import fr.cobblepulse.utils.CobbleUtils;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import net.minecraft.class_1262;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2520;
import net.minecraft.class_2522;
import net.minecraft.class_7225;

/**
 * Serialisation d'objets :
 * <ul>
 *   <li>listes / inventaires : NBT compresse en Base64 (base de donnees) ;</li>
 *   <li>objet seul : SNBT lisible ({@code {id:"minecraft:diamond",count:3,components:{...}}}) pour les fichiers JSON,
 *   NBT complet conserve (enchantements, noms, donnees de mods).</li>
 * </ul>
 * A appeler sur le thread principal (acces aux registres).
 */
public final class ItemSerial {
    private ItemSerial() {}

    private static class_7225.class_7874 registries() {
        return CobbleUtils.server().method_30611();
    }

    public static String encode(List<class_1799> items) {
        try {
            class_2371<class_1799> list = class_2371.method_10213(items.size(), class_1799.field_8037);
            for (int i = 0; i < items.size(); i++) list.set(i, items.get(i) == null ? class_1799.field_8037 : items.get(i));
            class_2487 tag = new class_2487();
            tag.method_10569("Size", items.size());
            class_1262.method_5426(tag, list, registries());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            class_2507.method_10634(tag, out);
            return Base64.getEncoder().encodeToString(out.toByteArray());
        } catch (Exception e) {
            CobbleUtils.LOG.error("[CobblePulse-Utils] Serialisation d'objets impossible", e);
            return "";
        }
    }

    public static List<class_1799> decode(String data) {
        List<class_1799> out = new ArrayList<>();
        if (data == null || data.isEmpty()) return out;
        try {
            class_2487 tag = class_2507.method_10629(new ByteArrayInputStream(Base64.getDecoder().decode(data)), class_2505.method_53898());
            int size = tag.method_10550("Size");
            class_2371<class_1799> list = class_2371.method_10213(size, class_1799.field_8037);
            class_1262.method_5429(tag, list, registries());
            out.addAll(list);
        } catch (Exception e) {
            CobbleUtils.LOG.error("[CobblePulse-Utils] Deserialisation d'objets impossible", e);
        }
        return out;
    }

    public static String encode(class_1277 c) {
        List<class_1799> l = new ArrayList<>();
        for (int i = 0; i < c.method_5439(); i++) l.add(c.method_5438(i));
        return encode(l);
    }

    public static void decodeInto(String data, class_1277 c) {
        List<class_1799> l = decode(data);
        for (int i = 0; i < c.method_5439(); i++) {
            c.method_5447(i, i < l.size() ? l.get(i) : class_1799.field_8037);
        }
    }

    /** Objet seul en Base64 (gros stacks acceptes). */
    public static String encodeOne(class_1799 stack) {
        List<class_1799> l = new ArrayList<>();
        l.add(stack);
        return encode(l);
    }

    public static class_1799 decodeOne(String data) {
        List<class_1799> l = decode(data);
        return l.isEmpty() ? class_1799.field_8037 : l.get(0);
    }

    /** SNBT lisible et editable a la main. */
    public static String toSnbt(class_1799 stack) {
        if (stack == null || stack.method_7960()) return "";
        try {
            int count = stack.method_7947();
            class_2520 t = stack.method_46651(Math.max(1, Math.min(99, count))).method_57358(registries());
            if (t instanceof class_2487 ct && count > 99) ct.method_10569("count", count);
            return t.toString();
        } catch (Exception e) {
            CobbleUtils.LOG.error("[CobblePulse-Utils] SNBT impossible", e);
            return "";
        }
    }

    /**
     * Objet depuis du SNBT, ou depuis un simple identifiant ("minecraft:diamond", "cobblemon:rare_candy 5").
     */
    public static class_1799 fromSnbt(String s) {
        if (s == null || s.isBlank()) return class_1799.field_8037;
        String v = s.trim();
        try {
            if (v.startsWith("{")) {
                class_2487 tag = class_2522.method_10718(v);
                int count = tag.method_10545("count") ? tag.method_10550("count") : 1;
                if (count > 99) tag.method_10569("count", 99);
                class_1799 st = class_1799.method_57359(registries(), tag);
                if (!st.method_7960() && count > 99) st.method_7939(count);
                return st;
            }
            String[] parts = v.split("\\s+");
            class_1799 st = new class_1799(Reg.item(parts[0], net.minecraft.class_1802.field_8162));
            if (parts.length > 1 && !st.method_7960()) {
                try {
                    st.method_7939(Math.max(1, Integer.parseInt(parts[1])));
                } catch (NumberFormatException ignored) {
                }
            }
            return st;
        } catch (Exception e) {
            CobbleUtils.LOG.warn("[CobblePulse-Utils] Objet invalide dans la configuration : {} ({})", v, e.toString());
            return class_1799.field_8037;
        }
    }

    public static List<class_1799> nonEmpty(List<class_1799> in) {
        List<class_1799> out = new ArrayList<>();
        for (class_1799 s : in) if (s != null && !s.method_7960()) out.add(s);
        return out;
    }
}
