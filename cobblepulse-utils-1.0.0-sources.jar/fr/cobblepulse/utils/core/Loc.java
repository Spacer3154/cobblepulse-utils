package fr.cobblepulse.utils.core;

import fr.cobblepulse.utils.CobbleUtils;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;

/** Position serialisable (monde + coordonnees + orientation). */
public final class Loc {
    public String world = "minecraft:overworld";
    public double x;
    public double y;
    public double z;
    public float yaw;
    public float pitch;

    public Loc() {}

    public Loc(String world, double x, double y, double z, float yaw, float pitch) {
        this.world = world;
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public static Loc of(class_3222 p) {
        return new Loc(p.method_37908().method_27983().method_29177().toString(), p.method_23317(), p.method_23318(), p.method_23321(), p.method_36454(), p.method_36455());
    }

    public class_3218 level() {
        MinecraftServer s = CobbleUtils.server();
        if (s == null) return null;
        class_2960 rl = class_2960.method_12829(world);
        if (rl == null) return null;
        return s.method_3847(class_5321.method_29179(class_7924.field_41223, rl));
    }

    public boolean isOverworld() {
        return class_1937.field_25179.method_29177().toString().equals(world);
    }

    /** Nom du monde (worlds.json), sans couleurs. */
    public String shortWorld() {
        return fr.cobblepulse.utils.teleport.Worlds.plainName(world);
    }

    public String coords() {
        return (int) Math.floor(x) + " " + (int) Math.floor(y) + " " + (int) Math.floor(z);
    }

    public Loc copy() {
        return new Loc(world, x, y, z, yaw, pitch);
    }
}
