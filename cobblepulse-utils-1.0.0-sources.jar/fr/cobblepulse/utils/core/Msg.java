package fr.cobblepulse.utils.core;

import fr.cobblepulse.utils.CobbleUtils;
import fr.cobblepulse.utils.config.Cfg;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/** Messages configurables (messages.toml) avec variables %cle%. */
public final class Msg {
    private Msg() {}

    public static String raw(String key) {
        if (Cfg.messages == null) return key;
        String v = Cfg.messages.str(key, null);
        if (v == null) {
            CobbleUtils.LOG.warn("[CobblePulse-Utils] Message manquant dans messages.toml : {}", key);
            return key;
        }
        return v;
    }

    public static String format(String key, Object... kv) {
        String s = raw(key);
        if (s.contains("%prefix%")) s = s.replace("%prefix%", raw("general.prefix"));
        if (s.contains("%prefix_")) {
            int i;
            while ((i = s.indexOf("%prefix_")) >= 0) {
                int j = s.indexOf('%', i + 1);
                if (j < 0) break;
                String mod = s.substring(i + 8, j);
                s = s.substring(0, i) + raw("prefixes." + mod) + s.substring(j + 1);
            }
        }
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("%" + kv[i] + "%", String.valueOf(kv[i + 1]));
        }
        return s;
    }

    /** Comme {@link #format} mais sans prefixe (titres, fenetres de saisie). */
    public static String formatBare(String key, Object... kv) {
        String s = raw(key).replaceAll("%prefix(_[a-z0-9_]+)?%", "");
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("%" + kv[i] + "%", String.valueOf(kv[i + 1]));
        }
        return s.trim();
    }

    public static class_5250 get(String key, Object... kv) {
        return TextUtil.legacy(format(key, kv));
    }

    /** Message dont une variable est un composant (nom d'objet traduit, Pokemon...). */
    public static class_5250 withComponent(String key, String var, class_2561 value, Object... kv) {
        return splice(format(key, kv), var, value);
    }

    public static class_5250 splice(String text, String var, class_2561 value) {
        String token = "%" + var + "%";
        int i = text.indexOf(token);
        if (i < 0) return TextUtil.legacy(text);
        class_5250 out = class_2561.method_43473();
        out.method_10852(TextUtil.legacy(text.substring(0, i)));
        out.method_10852(value);
        out.method_10852(TextUtil.legacy(text.substring(i + token.length())));
        return out;
    }

    public static boolean reachable(class_3222 p) {
        return p != null && p.field_13987 != null && !Players.isTest(p.method_5667());
    }

    public static void send(class_3222 p, String key, Object... kv) {
        if (reachable(p)) p.method_43496(get(key, kv));
    }

    public static void send(class_3222 p, class_2561 c) {
        if (reachable(p)) p.method_43496(c);
    }

    public static void send(UUID uuid, String key, Object... kv) {
        MinecraftServer s = CobbleUtils.server();
        if (s == null || uuid == null) return;
        send(s.method_3760().method_14602(uuid), key, kv);
    }

    public static void send(class_2168 src, String key, Object... kv) {
        src.method_45068(get(key, kv));
    }

    public static void broadcast(String key, Object... kv) {
        broadcast(get(key, kv));
    }

    public static void broadcast(class_2561 c) {
        MinecraftServer s = CobbleUtils.server();
        if (s != null) s.method_3760().method_43514(c, false);
    }

    public static void actionBar(class_3222 p, String key, Object... kv) {
        if (reachable(p)) p.method_7353(get(key, kv), true);
    }
}
