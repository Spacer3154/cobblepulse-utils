package fr.cobblepulse.utils.core;

import com.mojang.authlib.GameProfile;
import fr.cobblepulse.utils.CobbleUtils;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Recherche de joueurs (en ligne / hors ligne) et joueurs factices de l'auto-test. */
public final class Players {
    private static final Set<UUID> TEST = ConcurrentHashMap.newKeySet();

    private Players() {}

    public static void registerTest(class_3222 p) {
        TEST.add(p.method_5667());
    }

    public static boolean isTest(UUID uuid) {
        return uuid != null && TEST.contains(uuid);
    }

    public static class_3222 online(UUID uuid) {
        MinecraftServer s = CobbleUtils.server();
        return s == null || uuid == null ? null : s.method_3760().method_14602(uuid);
    }

    public static class_3222 online(String name) {
        MinecraftServer s = CobbleUtils.server();
        if (s == null || name == null) return null;
        class_3222 p = s.method_3760().method_14566(name);
        if (p != null) return p;
        // joueurs factices de l'auto-test (absents de la liste par nom)
        for (UUID u : TEST) {
            class_3222 t = s.method_3760().method_14602(u);
            if (t != null && t.method_7334().getName().equalsIgnoreCase(name)) return t;
        }
        return null;
    }

    /** Nom d'un joueur (en ligne, sinon cache des profils), ou debut de l'UUID. */
    public static String name(UUID uuid) {
        if (uuid == null) return "?";
        class_3222 p = online(uuid);
        if (p != null) return p.method_7334().getName();
        MinecraftServer s = CobbleUtils.server();
        if (s != null && s.method_3793() != null) {
            Optional<GameProfile> gp = s.method_3793().method_14512(uuid);
            if (gp.isPresent()) return gp.get().getName();
        }
        return uuid.toString().substring(0, 8);
    }

    /** Profil d'un joueur connu du serveur (en ligne ou deja venu). */
    public static GameProfile profile(String name) {
        class_3222 p = online(name);
        if (p != null) return p.method_7334();
        MinecraftServer s = CobbleUtils.server();
        if (s != null && s.method_3793() != null) {
            return s.method_3793().method_14515(name).orElse(null);
        }
        return null;
    }

    /** Sauvegarde immediate des donnees du joueur (inventaire, argent) apres une operation critique. */
    public static void saveNow(class_3222 p) {
        MinecraftServer s = CobbleUtils.server();
        if (s == null || p == null || isTest(p.method_5667())) return;
        try {
            ((fr.cobblepulse.utils.mixin.PlayerListAccessor) s.method_3760()).cpu$save(p);
        } catch (Throwable t) {
            CobbleUtils.LOG.warn("[CobblePulse-Utils] Sauvegarde du joueur {} impossible : {}", p.method_7334().getName(), t.toString());
        }
    }
}
