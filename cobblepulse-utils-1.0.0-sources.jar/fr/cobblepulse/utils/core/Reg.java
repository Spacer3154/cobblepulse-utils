package fr.cobblepulse.utils.core;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Acces simples aux registres (objets) par identifiant texte. */
public final class Reg {
    private Reg() {}

    public static class_2960 rl(String id, String defaultNs) {
        if (id == null || id.isBlank()) return null;
        String v = id.trim().toLowerCase(java.util.Locale.ROOT);
        return class_2960.method_12829(v.contains(":") ? v : defaultNs + ":" + v);
    }

    /** Objet depuis "modid:item" (ou "item" : minecraft puis cobblemon) ; {@code fallback} si introuvable. */
    public static class_1792 item(String id, class_1792 fallback) {
        if (id == null || id.isBlank()) return fallback;
        class_2960 rl = rl(id, "minecraft");
        if (rl != null && class_7923.field_41178.method_10250(rl)) return class_7923.field_41178.method_10223(rl);
        if (!id.contains(":")) {
            rl = rl(id, "cobblemon");
            if (rl != null && class_7923.field_41178.method_10250(rl)) return class_7923.field_41178.method_10223(rl);
        }
        return fallback;
    }

    public static boolean itemExists(String id) {
        return item(id, null) != null;
    }

    public static class_1799 stack(String id) {
        return new class_1799(item(id, class_1802.field_8077));
    }

    public static String id(class_1792 item) {
        return class_7923.field_41178.method_10221(item).toString();
    }
}
