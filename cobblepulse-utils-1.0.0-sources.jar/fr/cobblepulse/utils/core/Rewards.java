package fr.cobblepulse.utils.core;

import com.cobblemon.mod.common.pokemon.Pokemon;
import fr.cobblepulse.utils.CobbleUtils;
import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.config.Reward;
import fr.cobblepulse.utils.integration.Economy;
import fr.cobblepulse.utils.pokemon.PokemonFactory;
import fr.cobblepulse.utils.pokemon.PokemonText;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

/** Remise des recompenses generiques (Dex Rewards, butin des Boss). */
public final class Rewards {
    private Rewards() {}

    /** Libelle d'apercu (lore). */
    public static String describe(Reward r) {
        if (r.display != null && !r.display.isBlank()) return r.display;
        return switch (r.type) {
            case "money" -> "&a" + Economy.format(r.amount);
            case "bp" -> "&6" + r.amount + " BP &7(Tour de Combat)";
            case "command" -> "&7Commande : &f/" + (r.commands.isEmpty() ? "?" : r.commands.get(0));
            case "pokemon" -> r.pokemon == null ? "&cPokémon ?" : "&ePokémon : &f" + r.pokemon.species + " &7Nv." + r.pokemon.level + (r.pokemon.shiny ? " &e★" : "");
            default -> {
                class_1799 st = ItemSerial.fromSnbt(r.item);
                yield st.method_7960() ? "&c" + r.item : "&f" + st.method_7947() + " × " + st.method_7964().getString();
            }
        };
    }

    public static class_1799 icon(Reward r) {
        return switch (r.type) {
            case "money" -> new class_1799(net.minecraft.class_1802.field_8397);
            case "bp" -> new class_1799(net.minecraft.class_1802.field_8137);
            case "command" -> new class_1799(net.minecraft.class_1802.field_8866);
            case "pokemon" -> new class_1799(net.minecraft.class_1802.field_8803);
            default -> {
                class_1799 st = ItemSerial.fromSnbt(r.item);
                yield st.method_7960() ? new class_1799(net.minecraft.class_1802.field_8077) : st;
            }
        };
    }

    /** Recompense de type objet (tout ce qui n'est ni argent, ni BP, ni commande, ni Pokemon). */
    public static boolean isItem(Reward r) {
        return !"money".equals(r.type) && !"bp".equals(r.type) && !"command".equals(r.type) && !"pokemon".equals(r.type);
    }

    /** Tire la chance puis remet la recompense. @return libelle si obtenue, null sinon. */
    public static String roll(class_3222 p, Reward r) {
        if (r.chance < 100 && Math.random() * 100 >= r.chance) return null;
        return give(p, r) ? describe(r) : null;
    }

    public static boolean give(class_3222 p, Reward r) {
        try {
            switch (r.type) {
                case "money" -> {
                    return Economy.deposit(p.method_5667(), r.amount);
                }
                case "bp" -> {
                    run(Cfg.boss.bpCommand.replace("%amount%", String.valueOf(r.amount)), p);
                    return true;
                }
                case "command" -> {
                    for (String c : r.commands) run(c, p);
                    return true;
                }
                case "pokemon" -> {
                    if (r.pokemon == null) return false;
                    List<String> errors = new ArrayList<>();
                    Pokemon pk = PokemonFactory.create(r.pokemon, errors);
                    if (pk == null) {
                        CobbleUtils.LOG.warn("[CobblePulse-Utils] Recompense Pokemon invalide : {}", errors);
                        return false;
                    }
                    PokemonText.party(p).add(pk);
                    return true;
                }
                default -> {
                    class_1799 st = ItemSerial.fromSnbt(r.item);
                    if (st.method_7960()) return false;
                    giveItem(p, st);
                    return true;
                }
            }
        } catch (Throwable t) {
            CobbleUtils.LOG.error("[CobblePulse-Utils] Recompense {} impossible pour {} : {}", r.type, p.method_7334().getName(), t.toString());
            return false;
        }
    }

    /** Ajoute a l'inventaire (gros stacks decoupes), le surplus tombe au sol. */
    public static void giveItem(class_3222 p, class_1799 st) {
        int left = st.method_7947();
        int max = Math.max(1, st.method_7914());
        while (left > 0) {
            class_1799 part = st.method_46651(Math.min(max, left));
            left -= part.method_7947();
            if (!p.method_31548().method_7394(part) || !part.method_7960()) p.method_7328(part, false);
        }
    }

    public static void run(String cmd, class_3222 p) {
        String c = cmd.replace("%player%", p.method_7334().getName()).replace("%uuid%", p.method_5667().toString());
        if (c.startsWith("/")) c = c.substring(1);
        CobbleUtils.server().method_3734().method_44252(CobbleUtils.server().method_3739(), c);
    }
}
