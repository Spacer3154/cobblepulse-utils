package fr.cobblepulse.utils.enderchest;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

/** Vue sur les N premieres cases d'un conteneur (Enderchest de 1 a 6 lignes sur une page de 54 cases). */
final class SlicedContainer implements class_1263 {
    private final class_1263 base;
    private final int size;

    SlicedContainer(class_1263 base, int size) {
        this.base = base;
        this.size = Math.min(size, base.method_5439());
    }

    @Override
    public int method_5439() {
        return size;
    }

    @Override
    public boolean method_5442() {
        for (int i = 0; i < size; i++) if (!base.method_5438(i).method_7960()) return false;
        return true;
    }

    @Override
    public class_1799 method_5438(int slot) {
        return slot < size ? base.method_5438(slot) : class_1799.field_8037;
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        return slot < size ? base.method_5434(slot, amount) : class_1799.field_8037;
    }

    @Override
    public class_1799 method_5441(int slot) {
        return slot < size ? base.method_5441(slot) : class_1799.field_8037;
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        if (slot < size) base.method_5447(slot, stack);
    }

    @Override
    public void method_5431() {
        base.method_5431();
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return true;
    }

    @Override
    public void method_5448() {
        for (int i = 0; i < size; i++) base.method_5447(i, class_1799.field_8037);
    }
}
