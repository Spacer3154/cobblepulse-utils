package fr.cobblepulse.utils.essentials;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import fr.cobblepulse.utils.command.Cmd;
import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.core.Msg;
import fr.cobblepulse.utils.core.Perms;
import fr.cobblepulse.utils.core.Players;
import fr.cobblepulse.utils.core.TextUtil;
import fr.cobblepulse.utils.core.TimeFmt;
import fr.cobblepulse.utils.data.PlayerData;
import fr.cobblepulse.utils.data.PlayerStore;
import fr.cobblepulse.utils.gui.ChatInput;
import fr.cobblepulse.utils.integration.LuckPermsBridge;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3222;
import net.minecraft.class_5250;

import static net.minecraft.class_2170.method_9244;

/** Messages prives (/msg, /reply), /ignore, /mute, /nick et filtrage du chat public. */
public final class ChatFeatures {
    private static final Map<UUID, UUID> LAST = new ConcurrentHashMap<>();
    /** Surnoms formates (lus par le mixin du nom affiche). */
    private static final Map<UUID, class_2561> NICKS = new ConcurrentHashMap<>();

    private ChatFeatures() {}

    public static void register(CommandDispatcher<class_2168> d) {
        Cmd.player(d, "msg", l -> Cmd.lit(l).then(method_9244("joueur", class_2186.method_9305())
                .then(method_9244("message", StringArgumentType.greedyString()).executes(ctx -> {
                    class_3222 to = class_2186.method_9315(ctx, "joueur");
                    return send(ctx.getSource(), to, StringArgumentType.getString(ctx, "message"));
                }))));
        Cmd.player(d, "reply", l -> Cmd.lit(l).then(method_9244("message", StringArgumentType.greedyString()).executes(ctx -> Cmd.asPlayer(ctx, p -> {
            UUID last = LAST.get(p.method_5667());
            class_3222 to = last == null ? null : Players.online(last);
            if (to == null || (Vanish.isVanished(to) && !Vanish.canSee(p))) {
                Msg.send(p, "chat.no_reply");
                return 0;
            }
            return send(ctx.getSource(), to, StringArgumentType.getString(ctx, "message"));
        }))));
        Cmd.player(d, "ignore", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> {
            PlayerData data = PlayerStore.get(p);
            List<String> names = new ArrayList<>();
            for (UUID u : data.ignored) names.add(Players.name(u));
            Msg.send(p, "chat.ignore_list", "list", names.isEmpty() ? "-" : String.join(", ", names));
            return 1;
        })).then(method_9244("joueur", StringArgumentType.word()).suggests((c, b) -> class_2172.method_9253(
                c.getSource().method_9211().method_3858(), b)).executes(ctx -> Cmd.asPlayer(ctx, p -> {
            String name = StringArgumentType.getString(ctx, "joueur");
            UUID target = resolve(name);
            if (target == null) {
                Msg.send(p, "general.player_not_found", "player", name);
                return 0;
            }
            if (target.equals(p.method_5667())) {
                Msg.send(p, "chat.ignore_self");
                return 0;
            }
            PlayerData data = PlayerStore.get(p);
            boolean now = !data.ignored.remove(target);
            if (now) data.ignored.add(target);
            PlayerStore.dirty(p.method_5667());
            Msg.send(p, now ? "chat.ignore_on" : "chat.ignore_off", "player", Players.name(target));
            return 1;
        }))));
        Cmd.player(d, "nick", l -> Cmd.lit(l).then(method_9244("pseudo", StringArgumentType.greedyString()).executes(ctx -> Cmd.asPlayer(ctx, p ->
                nick(p, p, StringArgumentType.getString(ctx, "pseudo"))))));
        Cmd.admin(d, "mute", "mute", l -> Cmd.lit(l).then(method_9244("joueur", StringArgumentType.word())
                .suggests((c, b) -> class_2172.method_9253(c.getSource().method_9211().method_3858(), b))
                .executes(ctx -> mute(ctx.getSource(), StringArgumentType.getString(ctx, "joueur"), null, ""))
                .then(method_9244("duree", StringArgumentType.word()).executes(ctx -> mute(ctx.getSource(), StringArgumentType.getString(ctx, "joueur"),
                                StringArgumentType.getString(ctx, "duree"), ""))
                        .then(method_9244("raison", StringArgumentType.greedyString()).executes(ctx -> mute(ctx.getSource(),
                                StringArgumentType.getString(ctx, "joueur"), StringArgumentType.getString(ctx, "duree"),
                                StringArgumentType.getString(ctx, "raison")))))));
        Cmd.admin(d, "unmute", "mute", l -> Cmd.lit(l).then(method_9244("joueur", StringArgumentType.word())
                .suggests((c, b) -> class_2172.method_9253(c.getSource().method_9211().method_3858(), b)).executes(ctx -> {
                    String name = StringArgumentType.getString(ctx, "joueur");
                    UUID u = resolve(name);
                    if (u == null) {
                        Msg.send(ctx.getSource(), "general.player_not_found", "player", name);
                        return 0;
                    }
                    PlayerData data = PlayerStore.get(u);
                    data.mutedUntil = 0;
                    data.muteReason = "";
                    PlayerStore.save(u);
                    Msg.send(ctx.getSource(), "chat.unmuted", "player", Players.name(u));
                    Msg.send(u, "chat.unmuted_target");
                    return 1;
                })));
    }

    public static UUID resolve(String name) {
        class_3222 p = Players.online(name);
        if (p != null) return p.method_5667();
        UUID u = PlayerStore.findByName(name);
        if (u != null) return u;
        com.mojang.authlib.GameProfile gp = Players.profile(name);
        return gp == null ? null : gp.getId();
    }

    private static int send(class_2168 src, class_3222 to, String text) {
        class_3222 from = src.method_44023();
        String fromName = from == null ? "Console" : from.method_7334().getName();
        if (from != null) {
            PlayerData fd = PlayerStore.get(from);
            if (fd.muted() && !Perms.perk(from, Perms.MUTE_BYPASS)) {
                Msg.send(from, "chat.muted_self", "time", muteLeft(fd));
                return 0;
            }
            if (Vanish.isVanished(to) && !Vanish.canSee(from)) {
                Msg.send(from, "general.player_not_found", "player", to.method_7334().getName());
                return 0;
            }
            if (from == to) {
                Msg.send(from, "chat.msg_self");
                return 0;
            }
        }
        boolean ignored = from != null && PlayerStore.get(to).ignored.contains(from.method_5667());
        String body = from != null && Perms.perk(from, Perms.CHAT_COLOR) ? text : TextUtil.strip(text);
        src.method_45068(Msg.get("chat.msg_sent", "player", to.method_7334().getName()).method_10852(TextUtil.legacy(body)));
        if (ignored) return 1;
        Msg.send(to, Msg.get("chat.msg_received", "player", fromName).method_10852(TextUtil.legacy(body)));
        if (from != null) {
            LAST.put(to.method_5667(), from.method_5667());
            LAST.put(from.method_5667(), to.method_5667());
        }
        return 1;
    }

    static int nick(class_2168 src, class_3222 target, String raw) {
        class_3222 actor = src.method_44023();
        return nick(actor, target, raw);
    }

    public static int nick(class_3222 actor, class_3222 target, String raw) {
        PlayerData d = PlayerStore.get(target);
        String v = raw == null ? "" : raw.trim();
        if (v.equalsIgnoreCase("off") || v.isEmpty()) {
            d.nick = "";
            NICKS.remove(target.method_5667());
            PlayerStore.dirty(target.method_5667());
            Msg.send(actor, "chat.nick_off");
            refreshName(target);
            return 1;
        }
        if (actor != null && !Perms.perk(actor, Perms.CHAT_COLOR)) v = TextUtil.strip(v);
        String plain = TextUtil.strip(v);
        if (plain.length() > Cfg.general.chat.nickMaxLength || plain.length() < 2 || !plain.matches("[\\p{L}0-9_ .\\-]+")) {
            Msg.send(actor, "chat.nick_invalid", "max", Cfg.general.chat.nickMaxLength);
            return 0;
        }
        d.nick = v;
        PlayerStore.dirty(target.method_5667());
        applyNick(target.method_5667(), v, target.method_7334().getName());
        refreshName(target);
        Msg.send(actor, "chat.nick_set", "nick", v);
        return 1;
    }

    public static void applyNick(UUID uuid, String nick, String realName) {
        if (nick == null || nick.isBlank()) {
            NICKS.remove(uuid);
            return;
        }
        class_5250 c = TextUtil.legacy(Cfg.general.chat.nickPrefix + nick);
        c.method_27694(s -> s.method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470(realName))));
        NICKS.put(uuid, c);
    }

    public static class_2561 nickOf(UUID uuid) {
        return NICKS.get(uuid);
    }

    public static void onJoin(class_3222 p) {
        PlayerData d = PlayerStore.get(p);
        applyNick(p.method_5667(), d.nick, p.method_7334().getName());
    }

    public static void onLeave(class_3222 p) {
        LAST.remove(p.method_5667());
        if (!Players.isTest(p.method_5667())) NICKS.remove(p.method_5667());
    }

    private static void refreshName(class_3222 p) {
        p.method_5682().method_3760().method_14581(new net.minecraft.class_2703(
                net.minecraft.class_2703.class_5893.field_29139, p));
    }

    private static int mute(class_2168 src, String name, String duration, String reason) {
        UUID u = resolve(name);
        if (u == null) {
            Msg.send(src, "general.player_not_found", "player", name);
            return 0;
        }
        Long secs = duration == null ? null : ChatInput.parseDurationSeconds(duration);
        if (duration != null && secs == null) {
            reason = (duration + " " + reason).trim();
        }
        PlayerData d = PlayerStore.get(u);
        d.mutedUntil = secs == null || secs <= 0 ? -1 : System.currentTimeMillis() + secs * 1000;
        d.muteReason = reason == null ? "" : reason;
        PlayerStore.save(u);
        String time = d.mutedUntil < 0 ? Msg.format("chat.permanent") : TimeFmt.duration(secs * 1000);
        Msg.send(src, "chat.muted", "player", Players.name(u), "time", time, "reason", d.muteReason.isBlank() ? "-" : d.muteReason);
        Msg.send(u, "chat.muted_target", "time", time, "reason", d.muteReason.isBlank() ? "-" : d.muteReason);
        return 1;
    }

    static String muteLeft(PlayerData d) {
        return d.mutedUntil < 0 ? Msg.format("chat.permanent") : TimeFmt.duration(d.mutedUntil - System.currentTimeMillis());
    }

    /** Chat public : saisie d'editeur, muet. @return false pour bloquer le message. */
    public static boolean allowChat(class_3222 p, String text) {
        if (ChatInput.intercept(p, text)) return false;
        PlayerData d = PlayerStore.get(p);
        if (d.muted() && !Perms.perk(p, Perms.MUTE_BYPASS)) {
            Msg.send(p, "chat.muted_self", "time", muteLeft(d));
            return false;
        }
        return true;
    }

    /** Destinataire ignorant l'expediteur (filtre du chat public, appele par le mixin). */
    public static boolean ignores(class_3222 receiver, UUID sender) {
        if (!Cfg.general.chat.ignoreBlocksPublicChat || sender == null || receiver.method_5667().equals(sender)) return false;
        PlayerData d = PlayerStore.get(receiver);
        return d.ignored.contains(sender) && !hasStaff(sender);
    }

    private static boolean hasStaff(UUID sender) {
        class_3222 p = Players.online(sender);
        if (p == null) return false;
        Boolean v = LuckPermsBridge.check(p, "cobblepulse.admin.mute");
        return v != null && v;
    }
}
