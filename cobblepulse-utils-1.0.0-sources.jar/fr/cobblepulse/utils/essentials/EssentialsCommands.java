package fr.cobblepulse.utils.essentials;

import com.cobblemon.mod.common.api.permission.CobblemonPermissions;
import com.cobblemon.mod.common.api.storage.pc.PCStore;
import com.cobblemon.mod.common.api.storage.pc.link.PCLink;
import com.cobblemon.mod.common.api.storage.pc.link.PCLinkManager;
import com.cobblemon.mod.common.net.messages.client.storage.pc.OpenPCPacket;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.cobblemon.mod.common.util.PlayerExtensionsKt;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import fr.cobblepulse.utils.command.Cmd;
import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.core.Msg;
import fr.cobblepulse.utils.core.Perms;
import fr.cobblepulse.utils.core.Players;
import fr.cobblepulse.utils.core.TextUtil;
import fr.cobblepulse.utils.core.TimeFmt;
import fr.cobblepulse.utils.data.PlayerData;
import fr.cobblepulse.utils.data.PlayerStore;
import fr.cobblepulse.utils.gui.ChatInput;
import fr.cobblepulse.utils.integration.Economy;
import fr.cobblepulse.utils.integration.LuckPermsBridge;
import fr.cobblepulse.utils.pokemon.PokemonText;
import fr.cobblepulse.utils.teleport.Teleports;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1293;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1706;
import net.minecraft.class_1707;
import net.minecraft.class_1714;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3336;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3914;
import net.minecraft.class_3917;
import net.minecraft.class_4081;
import net.minecraft.class_5134;
import net.minecraft.class_5250;
import net.minecraft.class_747;

import static net.minecraft.class_2170.method_9244;

/** Commandes de confort, sociales, economiques simples et de moderation (§4.3, §4.4, §4.5). */
public final class EssentialsCommands {
    private EssentialsCommands() {}

    private static boolean otherAllowed(class_2168 src, String name) {
        return !src.method_43737() || Perms.admin(src.method_44023(), name + ".others") || Perms.admin(src.method_44023(), name);
    }

    public static void register(CommandDispatcher<class_2168> d) {
        // ---- confort
        Cmd.player(d, "fly", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> fly(ctx.getSource(), p)))
                .then(method_9244("joueur", class_2186.method_9305()).requires(src -> otherAllowed(src, "fly"))
                        .executes(ctx -> fly(ctx.getSource(), class_2186.method_9315(ctx, "joueur")))));
        Cmd.player(d, "heal", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> heal(ctx.getSource(), p)))
                .then(method_9244("joueur", class_2186.method_9305()).requires(src -> otherAllowed(src, "heal"))
                        .executes(ctx -> heal(ctx.getSource(), class_2186.method_9315(ctx, "joueur")))));
        Cmd.player(d, "feed", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> feed(ctx.getSource(), p)))
                .then(method_9244("joueur", class_2186.method_9305()).requires(src -> otherAllowed(src, "feed"))
                        .executes(ctx -> feed(ctx.getSource(), class_2186.method_9315(ctx, "joueur")))));
        Cmd.player(d, "hat", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> {
            class_1799 hand = p.method_6047();
            if (hand.method_7960()) {
                Msg.send(p, "misc.hat_empty");
                return 0;
            }
            class_1799 head = p.method_6118(class_1304.field_6169);
            p.method_5673(class_1304.field_6169, hand.method_46651(1));
            hand.method_7934(1);
            if (!head.method_7960() && !p.method_31548().method_7394(head)) p.method_7328(head, false);
            Msg.send(p, "misc.hat_done");
            return 1;
        })));
        Cmd.player(d, "trash", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> {
            openTrash(p);
            return 1;
        })));
        Cmd.player(d, "repair", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> repair(p, false)))
                .then(Cmd.lit("all").executes(ctx -> Cmd.asPlayer(ctx, p -> repair(p, true)))));
        Cmd.player(d, "craft", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> {
            p.method_17355(new class_747((id, inv, pl) -> new class_1714(id, inv, class_3914.method_17392(p.method_37908(), p.method_24515())) {
                @Override
                public boolean method_7597(class_1657 player) {
                    return true;
                }
            }, class_2561.method_43471("container.crafting")));
            return 1;
        })));
        Cmd.player(d, "anvil", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> {
            p.method_17355(new class_747((id, inv, pl) -> new class_1706(id, inv, class_3914.method_17392(p.method_37908(), p.method_24515())) {
                @Override
                public boolean method_7597(class_1657 player) {
                    return true;
                }
            }, class_2561.method_43471("container.repair")));
            return 1;
        })));

        // ---- social
        Cmd.player(d, "list", l -> Cmd.lit(l).executes(ctx -> list(ctx.getSource())));
        Cmd.player(d, "playtime", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> playtime(ctx.getSource(), p.method_5667())))
                .then(method_9244("joueur", StringArgumentType.word()).suggests((c, b) -> class_2172.method_9253(c.getSource().method_9211().method_3858(), b))
                        .executes(ctx -> {
                            UUID u = ChatFeatures.resolve(StringArgumentType.getString(ctx, "joueur"));
                            if (u == null) {
                                Msg.send(ctx.getSource(), "general.player_not_found", "player", StringArgumentType.getString(ctx, "joueur"));
                                return 0;
                            }
                            return playtime(ctx.getSource(), u);
                        })));
        Cmd.player(d, "pokeshout", l -> Cmd.lit(l).then(method_9244("slot", IntegerArgumentType.integer(1, 6)).executes(ctx -> Cmd.asPlayer(ctx, p ->
                pokeshout(p, IntegerArgumentType.getInteger(ctx, "slot"))))));
        Cmd.player(d, "pokeshoutall", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> pokeshout(p, 0))));
        Cmd.player(d, "pokeheal", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, EssentialsCommands::pokeheal)));
        Cmd.player(d, "pc", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> openPc(p, null)))
                .then(method_9244("boite", IntegerArgumentType.integer(1, 100)).executes(ctx -> Cmd.asPlayer(ctx, p ->
                        openPc(p, IntegerArgumentType.getInteger(ctx, "boite"))))));

        // ---- economie simple
        Cmd.player(d, "balance", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> {
                    Msg.send(p, "economy.balance", "money", Economy.format(Economy.balance(p.method_5667())));
                    return 1;
                }))
                .then(method_9244("joueur", StringArgumentType.word()).suggests((c, b) -> class_2172.method_9253(c.getSource().method_9211().method_3858(), b))
                        .executes(ctx -> {
                            String n = StringArgumentType.getString(ctx, "joueur");
                            UUID u = ChatFeatures.resolve(n);
                            if (u == null) {
                                Msg.send(ctx.getSource(), "general.player_not_found", "player", n);
                                return 0;
                            }
                            Msg.send(ctx.getSource(), "economy.balance_other", "player", Players.name(u), "money", Economy.format(Economy.balance(u)));
                            return 1;
                        })));
        Cmd.player(d, "pay", l -> Cmd.lit(l).then(method_9244("joueur", class_2186.method_9305())
                .then(method_9244("montant", LongArgumentType.longArg(1)).executes(ctx -> Cmd.asPlayer(ctx, p -> {
                    class_3222 to = class_2186.method_9315(ctx, "joueur");
                    long amount = LongArgumentType.getLong(ctx, "montant");
                    if (to == p) {
                        Msg.send(p, "economy.pay_self");
                        return 0;
                    }
                    if (!Economy.withdraw(p.method_5667(), amount)) {
                        Msg.send(p, "economy.not_enough", "money", Economy.format(amount));
                        return 0;
                    }
                    if (!Economy.deposit(to.method_5667(), amount)) {
                        Economy.deposit(p.method_5667(), amount);
                        Msg.send(p, "economy.error");
                        return 0;
                    }
                    Players.saveNow(p);
                    Players.saveNow(to);
                    Msg.send(p, "economy.paid", "player", to.method_7334().getName(), "money", Economy.format(amount));
                    Msg.send(to, "economy.received", "player", p.method_7334().getName(), "money", Economy.format(amount));
                    return 1;
                })))));

        // ---- staff
        Cmd.admin(d, "invsee", "invsee", l -> Cmd.lit(l).then(method_9244("joueur", class_2186.method_9305()).executes(ctx -> Cmd.asPlayer(ctx, p -> {
            class_3222 t = class_2186.method_9315(ctx, "joueur");
            openInvsee(p, t);
            return 1;
        }))));
        Cmd.admin(d, "vanish", "vanish", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> {
            Vanish.toggle(p);
            return 1;
        })));
        Cmd.admin(d, "god", "god", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> god(ctx.getSource(), p)))
                .then(method_9244("joueur", class_2186.method_9305()).executes(ctx -> god(ctx.getSource(), class_2186.method_9315(ctx, "joueur")))));
        Cmd.admin(d, "gamemode", "gamemode", l -> Cmd.lit(l).then(method_9244("mode", StringArgumentType.word())
                .suggests((c, b) -> class_2172.method_9265(List.of("0", "1", "2", "3", "survie", "creatif", "aventure", "spectateur"), b))
                .executes(ctx -> Cmd.asPlayer(ctx, p -> gamemode(ctx.getSource(), p, StringArgumentType.getString(ctx, "mode"))))
                .then(method_9244("joueur", class_2186.method_9305()).executes(ctx ->
                        gamemode(ctx.getSource(), class_2186.method_9315(ctx, "joueur"), StringArgumentType.getString(ctx, "mode"))))));
        Cmd.admin(d, "speed", "speed", l -> Cmd.lit(l).then(method_9244("vitesse", IntegerArgumentType.integer(1, 10))
                .executes(ctx -> Cmd.asPlayer(ctx, p -> speed(p, IntegerArgumentType.getInteger(ctx, "vitesse"))))));
        Cmd.admin(d, "broadcast", "broadcast", l -> Cmd.lit(l).then(method_9244("message", StringArgumentType.greedyString()).executes(ctx -> {
            String m = StringArgumentType.getString(ctx, "message");
            Msg.broadcast(Msg.get("staff.broadcast", "message", m));
            for (class_3222 p : ctx.getSource().method_9211().method_3760().method_14571()) {
                if (Msg.reachable(p)) p.method_17356(class_3417.field_14622.comp_349(), class_3419.field_15250, 0.8f, 1.2f);
            }
            return 1;
        })));
        Cmd.admin(d, "sudo", "sudo", l -> Cmd.lit(l).then(method_9244("joueur", class_2186.method_9305())
                .then(method_9244("commande", StringArgumentType.greedyString()).executes(ctx -> {
                    class_3222 t = class_2186.method_9315(ctx, "joueur");
                    String c = StringArgumentType.getString(ctx, "commande");
                    if (c.startsWith("c:")) {
                        t.method_5682().method_3760().method_43514(class_2561.method_43473().method_27693("<").method_10852(t.method_5476()).method_27693("> ")
                                .method_10852(class_2561.method_43470(c.substring(2).trim())), false);
                    } else {
                        t.method_5682().method_3734().method_44252(t.method_5671(), c.startsWith("/") ? c.substring(1) : c);
                    }
                    Msg.send(ctx.getSource(), "staff.sudo_done", "player", t.method_7334().getName(), "command", c);
                    return 1;
                }))));
        Cmd.admin(d, "tempban", "sanctions", l -> Cmd.lit(l).then(method_9244("joueur", StringArgumentType.word())
                .suggests((c, b) -> class_2172.method_9253(c.getSource().method_9211().method_3858(), b))
                .then(method_9244("duree", StringArgumentType.word())
                        .executes(ctx -> tempban(ctx.getSource(), StringArgumentType.getString(ctx, "joueur"), StringArgumentType.getString(ctx, "duree"), ""))
                        .then(method_9244("raison", StringArgumentType.greedyString()).executes(ctx -> tempban(ctx.getSource(),
                                StringArgumentType.getString(ctx, "joueur"), StringArgumentType.getString(ctx, "duree"),
                                StringArgumentType.getString(ctx, "raison")))))));
        // Commandes vanilla de moderation accessibles avec les noeuds CobblePulse
        for (String v : new String[]{"kick", "ban", "pardon", "ban-ip", "pardon-ip"}) Cmd.allowAlso(d, v, Perms.adminReq("sanctions").and(class_2168::method_43737));
        Cmd.allowAlso(d, "gamemode", Perms.adminReq("gamemode").and(class_2168::method_43737));
    }

    // ------------------------------------------------------------------ confort

    private static int fly(class_2168 src, class_3222 t) {
        boolean on = !t.method_31549().field_7478;
        t.method_31549().field_7478 = on;
        if (!on) t.method_31549().field_7479 = false;
        t.method_7355();
        Msg.send(t, on ? "misc.fly_on" : "misc.fly_off");
        if (src.method_44023() != t) Msg.send(src, on ? "misc.fly_on_other" : "misc.fly_off_other", "player", t.method_7334().getName());
        return 1;
    }

    private static int heal(class_2168 src, class_3222 t) {
        t.method_6033(t.method_6063());
        t.method_7344().method_7580(20);
        t.method_7344().method_7581(20f);
        t.method_5646();
        List<net.minecraft.class_6880<net.minecraft.class_1291>> bad = new ArrayList<>();
        for (class_1293 e : t.method_6026()) if (e.method_5579().comp_349().method_18792() == class_4081.field_18272) bad.add(e.method_5579());
        for (var e : bad) t.method_6016(e);
        Msg.send(t, "misc.healed");
        if (src.method_44023() != t) Msg.send(src, "misc.healed_other", "player", t.method_7334().getName());
        return 1;
    }

    private static int feed(class_2168 src, class_3222 t) {
        t.method_7344().method_7580(20);
        t.method_7344().method_7581(20f);
        Msg.send(t, "misc.fed");
        if (src.method_44023() != t) Msg.send(src, "misc.fed_other", "player", t.method_7334().getName());
        return 1;
    }

    public static void openTrash(class_3222 p) {
        int rows = Cfg.general.misc.trashRows;
        class_1277 c = new class_1277(rows * 9);
        p.method_17355(new class_747((id, inv, pl) -> new class_1707(type(rows), id, inv, c, rows) {
            @Override
            public void method_7595(class_1657 player) {
                super.method_7595(player);
                int n = 0;
                for (int i = 0; i < c.method_5439(); i++) if (!c.method_5438(i).method_7960()) n += c.method_5438(i).method_7947();
                c.method_5448();
                if (n > 0 && player instanceof class_3222 sp) Msg.send(sp, "misc.trash_done", "count", n);
            }
        }, TextUtil.legacy(Msg.format("misc.trash_title"))));
    }

    public static class_3917<?> type(int rows) {
        return switch (rows) {
            case 1 -> class_3917.field_18664;
            case 2 -> class_3917.field_18665;
            case 3 -> class_3917.field_17326;
            case 4 -> class_3917.field_18666;
            case 5 -> class_3917.field_18667;
            default -> class_3917.field_17327;
        };
    }

    private static int repair(class_3222 p, boolean all) {
        int n = 0;
        if (!all) {
            class_1799 s = p.method_6047();
            if (s.method_7963() && s.method_7986()) {
                s.method_7974(0);
                n = 1;
            }
        } else {
            class_1661 inv = p.method_31548();
            for (int i = 0; i < inv.method_5439(); i++) {
                class_1799 s = inv.method_5438(i);
                if (s.method_7963() && s.method_7986()) {
                    s.method_7974(0);
                    n++;
                }
            }
        }
        Msg.send(p, n == 0 ? "misc.repair_nothing" : "misc.repaired", "count", n);
        return n;
    }

    // ------------------------------------------------------------------ social

    private static int list(class_2168 src) {
        class_3222 viewer = src.method_44023();
        Map<String, List<class_3222>> groups = new LinkedHashMap<>();
        List<class_3222> online = new ArrayList<>(src.method_9211().method_3760().method_14571());
        online.removeIf(pl -> Players.isTest(pl.method_5667()) || (Vanish.isVanished(pl) && !Vanish.canSee(viewer)));
        for (class_3222 pl : online) {
            String g = LuckPermsBridge.primaryGroup(pl.method_5667());
            groups.computeIfAbsent(g == null ? "joueurs" : g, k -> new ArrayList<>()).add(pl);
        }
        List<String> order = new ArrayList<>(groups.keySet());
        order.sort(Comparator.comparingInt(LuckPermsBridge::groupWeight).reversed().thenComparing(s -> s));
        src.method_45068(Msg.get("social.list_header", "count", online.size(), "max", src.method_9211().method_3802()));
        for (String g : order) {
            class_5250 line = TextUtil.legacy(Msg.format("social.list_group", "group", LuckPermsBridge.groupDisplay(g), "count", groups.get(g).size()));
            boolean first = true;
            for (class_3222 pl : groups.get(g)) {
                if (!first) line.method_10852(TextUtil.legacy("&7, "));
                first = false;
                line.method_10852(pl.method_5476().method_27661());
                if (Vanish.isVanished(pl)) line.method_10852(TextUtil.legacy(" &8[V]"));
            }
            src.method_45068(line);
        }
        return online.size();
    }

    private static int playtime(class_2168 src, UUID u) {
        class_3222 p = Players.online(u);
        long ticks = p != null ? PlayerStore.playtimeTicks(p) : PlayerStore.peek(u).playtimeTicks;
        PlayerData d = PlayerStore.peek(u);
        Msg.send(src, "social.playtime", "player", Players.name(u), "time", TimeFmt.duration(ticks * 50L),
                "first", d.firstJoin > 0 ? TimeFmt.date(d.firstJoin) : "-");
        if (p != null && Cfg.playtime.enabled) {
            Msg.send(src, "playtime.active_line", "time", TimeFmt.duration(fr.cobblepulse.utils.playtime.PlaytimeRewards.activeSeconds(p) * 1000L));
            String next = fr.cobblepulse.utils.playtime.PlaytimeRewards.nextTierText(p);
            if (!next.isEmpty()) src.method_45068(TextUtil.legacy(next));
        }
        return 1;
    }

    private static int pokeshout(class_3222 p, int slot) {
        PlayerData d = PlayerStore.get(p);
        if (d.muted()) {
            Msg.send(p, "chat.muted_self", "time", ChatFeatures.muteLeft(d));
            return 0;
        }
        long left = d.cooldownLeft("pokeshout");
        if (left > 0 && !Perms.perk(p, Perms.TP_BYPASS_COOLDOWN)) {
            Msg.send(p, "social.pokeshout_cooldown", "time", TimeFmt.duration(left));
            return 0;
        }
        var party = PokemonText.party(p);
        class_5250 msg = Msg.withComponent(slot == 0 ? "social.pokeshoutall" : "social.pokeshout", "player", p.method_5476());
        int n = 0;
        if (slot > 0) {
            Pokemon pk = party.get(slot - 1);
            if (pk == null) {
                Msg.send(p, "social.pokeshout_empty", "slot", slot);
                return 0;
            }
            msg.method_10852(PokemonText.chat(pk));
            n = 1;
        } else {
            for (int i = 0; i < 6; i++) {
                Pokemon pk = party.get(i);
                if (pk == null) continue;
                if (n > 0) msg.method_10852(class_2561.method_43470(" "));
                msg.method_10852(PokemonText.chat(pk));
                n++;
            }
            if (n == 0) {
                Msg.send(p, "social.pokeshout_none");
                return 0;
            }
        }
        d.setCooldown("pokeshout", 10_000);
        Msg.broadcast(msg);
        return n;
    }

    private static int pokeheal(class_3222 p) {
        if (Teleports.inBattle(p)) {
            Msg.send(p, "social.pokeheal_battle");
            return 0;
        }
        PlayerData d = PlayerStore.get(p);
        long left = d.cooldownLeft("pokeheal");
        if (left > 0 && !Perms.perk(p, Perms.TP_BYPASS_COOLDOWN)) {
            Msg.send(p, "social.pokeheal_cooldown", "time", TimeFmt.duration(left));
            return 0;
        }
        int n = 0;
        for (Pokemon pk : PokemonText.party(p)) {
            if (pk == null) continue;
            pk.heal();
            n++;
        }
        d.setCooldown("pokeheal", Cfg.general.misc.pokehealCooldownSeconds * 1000L);
        PlayerStore.dirty(p.method_5667());
        Msg.send(p, "social.pokeheal_done", "count", n);
        return n;
    }

    public static int openPc(class_3222 p, Integer box) {
        if (PlayerExtensionsKt.isInBattle(p)) {
            Msg.send(p, "social.pc_battle");
            return 0;
        }
        PCStore pc = PlayerExtensionsKt.pc(p);
        int b = box == null ? 0 : Math.max(0, Math.min(pc.getBoxes().size() - 1, box - 1));
        PCLinkManager.INSTANCE.addLink(new PCLink(pc, p.method_5667()));
        new OpenPCPacket(pc, b, false).sendToPlayer(p);
        return 1;
    }

    // ------------------------------------------------------------------ staff

    /** Inventaire d'un autre joueur, modifiable en direct (36 + armure + seconde main). */
    public static void openInvsee(class_3222 viewer, class_3222 target) {
        class_1661 inv = target.method_31548();
        class_1263 view = new InvseeContainer(inv);
        viewer.method_17355(new class_747((id, pinv, pl) -> new class_1707(class_3917.field_18667, id, pinv, view, 5) {
            @Override
            public boolean method_7597(class_1657 player) {
                return !target.method_14239();
            }
        }, TextUtil.legacy(Msg.format("staff.invsee_title", "player", target.method_7334().getName()))));
    }

    private static int god(class_2168 src, class_3222 t) {
        PlayerData d = PlayerStore.get(t);
        d.god = !d.god;
        PlayerStore.dirty(t.method_5667());
        Msg.send(t, d.god ? "staff.god_on" : "staff.god_off");
        if (src.method_44023() != t) Msg.send(src, d.god ? "staff.god_on_other" : "staff.god_off_other", "player", t.method_7334().getName());
        return 1;
    }

    public static boolean isGod(class_3222 p) {
        return PlayerStore.get(p).god;
    }

    private static int gamemode(class_2168 src, class_3222 t, String mode) {
        class_1934 gt = switch (mode.toLowerCase(java.util.Locale.ROOT)) {
            case "0", "s", "survival", "survie" -> class_1934.field_9215;
            case "1", "c", "creative", "creatif", "créatif" -> class_1934.field_9220;
            case "2", "a", "adventure", "aventure" -> class_1934.field_9216;
            case "3", "sp", "spectator", "spectateur" -> class_1934.field_9219;
            default -> null;
        };
        if (gt == null) {
            Msg.send(src, "staff.gamemode_unknown", "mode", mode);
            return 0;
        }
        t.method_7336(gt);
        Msg.send(src, "staff.gamemode_set", "player", t.method_7334().getName(), "mode", gt.method_8383().getString());
        return 1;
    }

    private static int speed(class_3222 p, int n) {
        float mult = 1f + (n - 1) * 0.5f;
        if (p.method_31549().field_7479) {
            p.method_31549().method_7248(0.05f * mult);
            p.method_7355();
            Msg.send(p, "staff.speed_fly", "speed", n);
        } else {
            var attr = p.method_5996(class_5134.field_23719);
            if (attr != null) attr.method_6192(0.1 * mult);
            Msg.send(p, "staff.speed_walk", "speed", n);
        }
        return 1;
    }

    private static int tempban(class_2168 src, String name, String duration, String reason) {
        Long secs = ChatInput.parseDurationSeconds(duration);
        if (secs == null || secs <= 0) {
            Msg.send(src, "staff.tempban_duration", "duration", duration);
            return 0;
        }
        GameProfile gp = Players.profile(name);
        if (gp == null) {
            Msg.send(src, "general.player_not_found", "player", name);
            return 0;
        }
        String r = reason == null || reason.isBlank() ? Msg.format("staff.tempban_default_reason") : reason;
        Date expires = new Date(System.currentTimeMillis() + secs * 1000);
        src.method_9211().method_3760().method_14563().method_14633(new class_3336(gp, new Date(), src.method_9214(), expires, r));
        class_3222 online = Players.online(gp.getId());
        if (online != null) {
            online.field_13987.method_52396(TextUtil.legacy(Msg.format("staff.tempban_kick", "time", TimeFmt.duration(secs * 1000), "reason", r)));
        }
        Msg.send(src, "staff.tempban_done", "player", gp.getName(), "time", TimeFmt.duration(secs * 1000), "reason", r);
        return 1;
    }
}
