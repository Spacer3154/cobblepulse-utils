package fr.cobblepulse.utils.essentials;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;

/**
 * Vue modifiable de l'inventaire d'un joueur pour /invsee (5 lignes) :
 * lignes 1-3 = inventaire principal, ligne 4 = barre rapide, ligne 5 = armure (casque..bottes) + seconde main.
 */
final class InvseeContainer implements class_1263 {
    private final class_1661 inv;

    InvseeContainer(class_1661 inv) {
        this.inv = inv;
    }

    /** Index dans l'inventaire du joueur, ou -1 (case inutilisee). */
    private int map(int slot) {
        if (slot < 27) return slot + 9;
        if (slot < 36) return slot - 27;
        int k = slot - 36;
        if (k < 4) return 39 - k;
        if (k == 4) return 40;
        return -1;
    }

    @Override
    public int method_5439() {
        return 45;
    }

    @Override
    public boolean method_5442() {
        return inv.method_5442();
    }

    @Override
    public class_1799 method_5438(int slot) {
        int i = map(slot);
        return i < 0 ? class_1799.field_8037 : inv.method_5438(i);
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        int i = map(slot);
        return i < 0 ? class_1799.field_8037 : inv.method_5434(i, amount);
    }

    @Override
    public class_1799 method_5441(int slot) {
        int i = map(slot);
        return i < 0 ? class_1799.field_8037 : inv.method_5441(i);
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        int i = map(slot);
        if (i >= 0) inv.method_5447(i, stack);
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return map(slot) >= 0;
    }

    @Override
    public void method_5431() {
        inv.method_5431();
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return true;
    }

    @Override
    public void method_5448() {
    }
}
