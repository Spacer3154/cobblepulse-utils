package fr.cobblepulse.utils.essentials;

import fr.cobblepulse.utils.core.Msg;
import fr.cobblepulse.utils.core.Perms;
import fr.cobblepulse.utils.core.Players;
import fr.cobblepulse.utils.data.PlayerData;
import fr.cobblepulse.utils.data.PlayerStore;
import fr.cobblepulse.utils.mixin.ChunkMapAccessor;
import fr.cobblepulse.utils.mixin.TrackedEntityInvoker;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2703;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7828;

/**
 * /vanish : le membre du staff n'est plus envoye aux autres clients (entite, liste des joueurs, /list, /msg),
 * sauf a ceux qui ont cobblepulse.admin.vanish.see.
 */
public final class Vanish {
    private static final Set<UUID> VANISHED = ConcurrentHashMap.newKeySet();

    private Vanish() {}

    public static boolean isVanished(class_3222 p) {
        return p != null && VANISHED.contains(p.method_5667());
    }

    public static boolean canSee(class_3222 viewer) {
        return viewer == null || Perms.admin(viewer, Perms.VANISH_SEE) || Perms.admin(viewer, "vanish");
    }

    /** Appele par le mixin de suivi d'entites. */
    public static boolean hiddenFrom(class_3222 target, class_3222 viewer) {
        return target != viewer && VANISHED.contains(target.method_5667()) && !canSee(viewer);
    }

    public static void toggle(class_3222 p) {
        set(p, !isVanished(p));
        Msg.send(p, isVanished(p) ? "staff.vanish_on" : "staff.vanish_off");
    }

    public static void set(class_3222 p, boolean on) {
        PlayerData d = PlayerStore.get(p);
        d.vanished = on;
        PlayerStore.dirty(p.method_5667());
        if (on) VANISHED.add(p.method_5667());
        else VANISHED.remove(p.method_5667());
        refresh(p);
    }

    /** Met a jour la liste des joueurs et le suivi de l'entite pour tous les autres joueurs. */
    public static void refresh(class_3222 p) {
        boolean on = isVanished(p);
        for (class_3222 other : p.method_5682().method_3760().method_14571()) {
            if (other == p || other.field_13987 == null) continue;
            if (on && !canSee(other)) other.field_13987.method_14364(new class_7828(List.of(p.method_5667())));
            else other.field_13987.method_14364(class_2703.method_43886(List.of(p)));
        }
        class_3218 level = p.method_51469();
        Object tracked = ((ChunkMapAccessor) level.method_14178().field_17254).cpu$entityMap().get(p.method_5628());
        if (tracked != null) ((TrackedEntityInvoker) tracked).cpu$updatePlayers(level.method_18456());
    }

    public static void onJoin(class_3222 p) {
        PlayerData d = PlayerStore.get(p);
        if (d.vanished && Perms.admin(p, "vanish")) {
            VANISHED.add(p.method_5667());
            refresh(p);
            Msg.send(p, "staff.vanish_still");
        } else if (d.vanished) {
            d.vanished = false;
            PlayerStore.dirty(p.method_5667());
        }
        // cacher les staffs invisibles au nouvel arrivant
        if (!canSee(p)) {
            for (UUID u : VANISHED) {
                class_3222 v = Players.online(u);
                if (v != null && v != p) p.field_13987.method_14364(new class_7828(List.of(u)));
            }
        }
    }

    public static void onLeave(class_3222 p) {
        VANISHED.remove(p.method_5667());
    }
}
