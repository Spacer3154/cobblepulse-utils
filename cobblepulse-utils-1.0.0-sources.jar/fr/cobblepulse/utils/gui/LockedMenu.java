package fr.cobblepulse.utils.gui;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_3917;

/** Conteneur verrouille : intercepte tous les clics, empeche tout deplacement d'item. */
public final class LockedMenu extends class_1707 {
    private final Gui gui;

    LockedMenu(int id, class_1661 inv, Gui gui) {
        super(type(gui.rows), id, inv, gui.container, gui.rows);
        this.gui = gui;
    }

    public static class_3917<?> type(int rows) {
        return switch (rows) {
            case 1 -> class_3917.field_18664;
            case 2 -> class_3917.field_18665;
            case 3 -> class_3917.field_17326;
            case 4 -> class_3917.field_18666;
            case 5 -> class_3917.field_18667;
            default -> class_3917.field_17327;
        };
    }

    @Override
    public void method_7593(int slotId, int button, class_1713 clickType, class_1657 player) {
        if (player instanceof class_3222 sp && slotId >= 0 && slotId < gui.size()
                && (clickType == class_1713.field_7790 || clickType == class_1713.field_7794)) {
            gui.handleClick(sp, slotId, new Gui.Click(clickType, button));
        }
        // Aucun deplacement autorise : resynchronisation complete du client
        method_34252();
    }

    Gui gui() {
        return gui;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }

    @Override
    public boolean method_7613(class_1799 stack, net.minecraft.class_1735 slot) {
        return false;
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        if (gui.onClose != null && player instanceof class_3222 sp) gui.onClose.accept(sp);
    }
}
