package fr.cobblepulse.utils.gui;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.core.Json;
import fr.cobblepulse.utils.core.Scheduler;
import fr.cobblepulse.utils.core.TextUtil;
import fr.cobblepulse.utils.net.Net;
import io.netty.buffer.Unpooled;
import java.util.Base64;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import net.minecraft.class_9129;

/**
 * Affichage des menus {@link Gui} dans un ecran client CobblePulse (le mod est present cote client).
 * <p>Le serveur reste maitre : il envoie le contenu (objets encodes comme dans un vrai coffre, titre, barre d'actions),
 * le client renvoie les clics (gauche, droit, maj, milieu) qui sont verifies contre la session courante puis traites
 * par les memes actions que le menu coffre. Une modification du menu ouvert est renvoyee automatiquement.</p>
 */
public final class Screens {
    private record Session(int id, Gui gui) {}

    private static final Map<UUID, Session> SESSIONS = new ConcurrentHashMap<>();
    private static final AtomicInteger IDS = new AtomicInteger(1);
    /** Auto-tests : joueurs factices traites comme des clients moddes ; le dernier paquet est conserve. */
    private static final Set<UUID> CAPTURE = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, JsonObject> LAST = new ConcurrentHashMap<>();
    private static final Map<UUID, String> LAST_KIND = new ConcurrentHashMap<>();

    private Screens() {}

    public static boolean enabled(class_3222 p) {
        if (p == null) return false;
        if (CAPTURE.contains(p.method_5667())) return true;
        return (Cfg.general == null || Cfg.general.clientScreens) && Net.hasClient(p);
    }

    public static void show(class_3222 p, Gui gui) {
        Session old = SESSIONS.get(p.method_5667());
        if (old != null && old.gui != gui) release(p, old);
        // un coffre ouvert (enderchest, poubelle...) est ferme avant d'afficher l'ecran
        if (p.field_7512 != p.field_7498) p.method_7346();
        Session s = old != null && old.gui == gui ? old : new Session(IDS.getAndIncrement(), gui);
        SESSIONS.put(p.method_5667(), s);
        gui.shownTo = p;
        send(p, "menu", encode(p, s));
    }

    /** Clic recu de l'ecran client ; ignore si l'ecran ne correspond plus au menu courant. */
    public static void click(class_3222 p, int id, int slot, String kind) {
        Session s = SESSIONS.get(p.method_5667());
        if (s == null || s.id != id || slot < 0 || slot >= s.gui.size()) return;
        Gui.Click c = switch (kind == null ? "" : kind) {
            case "right" -> new Gui.Click(class_1713.field_7790, 1);
            case "shift" -> new Gui.Click(class_1713.field_7794, 0);
            case "middle" -> new Gui.Click(class_1713.field_7796, 2);
            default -> new Gui.Click(class_1713.field_7790, 0);
        };
        s.gui.handleClick(p, slot, c);
    }

    /** Ecran ferme par le joueur (Echap). */
    public static void closedByClient(class_3222 p, int id) {
        Session s = SESSIONS.get(p.method_5667());
        if (s == null || s.id != id) return;
        SESSIONS.remove(p.method_5667());
        release(p, s);
    }

    /** Fermeture demandee par le serveur (teleportation, commande...). */
    public static void close(class_3222 p) {
        Session s = SESSIONS.remove(p.method_5667());
        if (s == null) return;
        release(p, s);
        send(p, "menu_close", new JsonObject());
    }

    /** Oublie la session sans rien envoyer (un autre ecran la remplace : Hub, saisie validee, deconnexion). */
    public static void forget(class_3222 p) {
        if (p == null) return;
        Session s = SESSIONS.remove(p.method_5667());
        if (s != null) release(p, s);
    }

    public static void forget(UUID uuid) {
        Session s = SESSIONS.remove(uuid);
        if (s != null) s.gui.shownTo = null;
    }

    private static void release(class_3222 p, Session s) {
        s.gui.shownTo = null;
        if (s.gui.onClose != null) s.gui.onClose.accept(p);
    }

    /** Fenetre de saisie (prix, nom...) par-dessus l'ecran ; la reponse revient par {@link ChatInput#answer}. */
    public static void prompt(class_3222 p, String legacyText) {
        JsonObject o = new JsonObject();
        o.addProperty("text", class_2561.class_2562.method_10867(TextUtil.legacy(legacyText), p.method_56673()));
        send(p, "prompt", o);
    }

    /** Selecteur client : objet (tous les objets) ou Pokemon (createur de fiche). */
    public static void pick(class_3222 p, String kind, String legacyTitle, String initial) {
        JsonObject o = new JsonObject();
        o.addProperty("kind", kind);
        o.addProperty("title", class_2561.class_2562.method_10867(TextUtil.legacy(legacyTitle), p.method_56673()));
        o.addProperty("value", initial == null ? "" : initial);
        send(p, "pick", o);
    }

    static void queueRefresh(Gui g) {
        if (g.resendQueued) return;
        g.resendQueued = true;
        Scheduler.next(() -> {
            g.resendQueued = false;
            class_3222 p = g.shownTo;
            if (p == null || p.method_14239()) return;
            Session s = SESSIONS.get(p.method_5667());
            if (s == null || s.gui != g || p.field_7512 != p.field_7498) return;
            send(p, "menu", encode(p, s));
        });
    }

    static JsonObject encode(class_3222 p, Session s) {
        Gui g = s.gui;
        JsonObject o = new JsonObject();
        o.addProperty("id", s.id);
        o.addProperty("title", class_2561.class_2562.method_10867(g.title, p.method_56673()));
        o.addProperty("rows", g.rows);
        o.addProperty("list", g.list);
        if (g.afterBattle) o.addProperty("after_battle", true);
        // la derniere ligne d'un menu de 2 lignes ou plus est la barre d'actions (retour, pages, solde...)
        int barStart = g.rows >= 2 ? (g.rows - 1) * 9 : Integer.MAX_VALUE;
        int barEnd = g.rows * 9;
        JsonArray items = new JsonArray();
        for (int i = 0; i < g.size(); i++) {
            class_1799 st = g.container.method_5438(i);
            if (st.method_7960()) continue;
            boolean click = g.handlers.containsKey(i);
            if (!click && filler(st)) continue;
            JsonObject it = new JsonObject();
            it.addProperty("s", i);
            it.addProperty("i", encodeStack(p, st));
            if (click) it.addProperty("c", true);
            if (i >= barStart && i < barEnd) it.addProperty("bar", true);
            items.add(it);
        }
        o.add("items", items);
        return o;
    }

    /** Vitres de decoration des menus coffre : inutiles a l'ecran. */
    static boolean filler(class_1799 st) {
        String path = class_7923.field_41178.method_10221(st.method_7909()).method_12832();
        return (path.endsWith("stained_glass_pane") || path.equals("glass_pane")) && st.method_7964().getString().isBlank();
    }

    /** Encodage reseau exact (comme les cases d'un coffre) : composants, Pokemon, enchantements... */
    static String encodeStack(class_3222 p, class_1799 st) {
        class_9129 buf = new class_9129(Unpooled.buffer(), p.method_56673());
        try {
            class_1799.field_49268.encode(buf, st);
            byte[] b = new byte[buf.readableBytes()];
            buf.method_52979(b);
            return Base64.getEncoder().encodeToString(b);
        } finally {
            buf.release();
        }
    }

    private static void send(class_3222 p, String kind, JsonObject o) {
        if (CAPTURE.contains(p.method_5667())) {
            LAST.put(p.method_5667(), o);
            LAST_KIND.put(p.method_5667(), kind);
            return;
        }
        Net.send(p, kind, Json.COMPACT.toJson(o));
    }

    // ------------------------------------------------------------------ auto-tests

    public static void capture(UUID uuid, boolean on) {
        if (on) CAPTURE.add(uuid);
        else {
            CAPTURE.remove(uuid);
            LAST.remove(uuid);
            LAST_KIND.remove(uuid);
        }
    }

    public static JsonObject last(UUID uuid) {
        return LAST.get(uuid);
    }

    public static String lastKind(UUID uuid) {
        return LAST_KIND.get(uuid);
    }

    public static int sessionId(UUID uuid) {
        Session s = SESSIONS.get(uuid);
        return s == null ? -1 : s.id;
    }

    public static boolean hasSession(UUID uuid) {
        return SESSIONS.containsKey(uuid);
    }

    /** Noms des entrees affichees (hors vitres de decoration). */
    public static java.util.List<String> names(UUID uuid) {
        java.util.List<String> out = new java.util.ArrayList<>();
        Session s = SESSIONS.get(uuid);
        if (s == null) return out;
        for (int i = 0; i < s.gui.size(); i++) {
            class_1799 st = s.gui.container.method_5438(i);
            if (st.method_7960() || (!s.gui.handlers.containsKey(i) && filler(st))) continue;
            out.add(st.method_7964().getString());
        }
        return out;
    }

    /** Case cliquable dont le nom contient le texte (-1 si absente). */
    public static int slotNamed(UUID uuid, String part) {
        Session s = SESSIONS.get(uuid);
        if (s == null) return -1;
        for (int i = 0; i < s.gui.size(); i++) {
            class_1799 st = s.gui.container.method_5438(i);
            if (!st.method_7960() && s.gui.handlers.containsKey(i) && st.method_7964().getString().toLowerCase(java.util.Locale.ROOT)
                    .contains(part.toLowerCase(java.util.Locale.ROOT))) return i;
        }
        return -1;
    }

    public static String encodeForTest(class_3222 p, class_1799 st) {
        return encodeStack(p, st);
    }

    /** Decodage cote serveur d'une case encodee (auto-test de l'aller-retour). */
    public static class_1799 decodeStack(class_3222 p, String b64) {
        class_9129 buf = new class_9129(Unpooled.wrappedBuffer(Base64.getDecoder().decode(b64)), p.method_56673());
        try {
            return class_1799.field_49268.decode(buf);
        } finally {
            buf.release();
        }
    }
}
