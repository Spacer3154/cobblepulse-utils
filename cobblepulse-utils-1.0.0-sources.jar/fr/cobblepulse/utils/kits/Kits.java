package fr.cobblepulse.utils.kits;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import fr.cobblepulse.utils.CobbleUtils;
import fr.cobblepulse.utils.command.Cmd;
import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.config.KitsConfig;
import fr.cobblepulse.utils.core.ItemBuilder;
import fr.cobblepulse.utils.core.ItemSerial;
import fr.cobblepulse.utils.core.Msg;
import fr.cobblepulse.utils.core.Perms;
import fr.cobblepulse.utils.core.Players;
import fr.cobblepulse.utils.core.Reg;
import fr.cobblepulse.utils.core.TextUtil;
import fr.cobblepulse.utils.core.TimeFmt;
import fr.cobblepulse.utils.data.PlayerData;
import fr.cobblepulse.utils.data.PlayerStore;
import fr.cobblepulse.utils.essentials.EssentialsCommands;
import fr.cobblepulse.utils.gui.ChatInput;
import fr.cobblepulse.utils.gui.Gui;
import fr.cobblepulse.utils.gui.Paged;
import fr.cobblepulse.utils.hub.Hub;
import fr.cobblepulse.utils.integration.LuckPermsBridge;
import fr.cobblepulse.utils.staff.StaffPanel;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_747;

import static net.minecraft.class_2170.method_9244;

/** Kits filtres par permission (cobblepulse.kit.<nom>), delais (cobblepulse.kit.bypasscooldown), editeur en jeu. */
public final class Kits {
    private Kits() {}

    public static void register(CommandDispatcher<class_2168> d) {
        Cmd.player(d, "kit", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, Kits::open))
                .then(method_9244("nom", StringArgumentType.word()).suggests((c, b) -> {
                    class_3222 p = c.getSource().method_44023();
                    List<String> names = new ArrayList<>();
                    for (KitsConfig.Kit k : Cfg.kits.kits) if (p == null || canUse(p, k)) names.add(k.name);
                    return class_2172.method_9265(names, b);
                }).executes(ctx -> Cmd.asPlayer(ctx, p -> {
                    KitsConfig.Kit k = Cfg.kits.find(StringArgumentType.getString(ctx, "nom"));
                    if (k == null || !canUse(p, k)) {
                        Msg.send(p, "kits.unknown", "kit", StringArgumentType.getString(ctx, "nom"));
                        return 0;
                    }
                    return claim(p, k) ? 1 : 0;
                }))));
    }

    public static boolean canUse(class_3222 p, KitsConfig.Kit k) {
        Boolean v = LuckPermsBridge.check(p, "cobblepulse.kit." + k.name);
        if (v != null) return v;
        return k.defaultAccess || p.method_5687(Cfg.general.opLevel);
    }

    private static String key(KitsConfig.Kit k) {
        return "kit:" + k.name;
    }

    public static List<class_1799> items(KitsConfig.Kit k) {
        List<class_1799> out = new ArrayList<>();
        for (String s : k.items) {
            class_1799 st = ItemSerial.fromSnbt(s);
            if (!st.method_7960()) out.add(st);
        }
        return out;
    }

    /** Etat d'un kit pour un joueur (texte de lore). */
    private static String status(class_3222 p, KitsConfig.Kit k) {
        PlayerData d = PlayerStore.get(p);
        if (k.oneTime && d.kitsClaimed.contains(k.name)) return Msg.format("kits.status_claimed");
        long left = d.cooldownLeft(key(k));
        if (left > 0 && !Perms.perk(p, Perms.KIT_BYPASS)) return Msg.format("kits.status_cooldown", "time", TimeFmt.duration(left));
        return Msg.format("kits.status_ready");
    }

    public static void open(class_3222 p) {
        List<Paged.Entry> entries = new ArrayList<>();
        for (KitsConfig.Kit k : Cfg.kits.kits) {
            if (!canUse(p, k)) continue;
            ItemBuilder b = ItemBuilder.of(Reg.stack(k.icon)).name(k.display).lore(k.lore);
            b.lore("", Msg.format("kits.icon_cooldown", "time", k.oneTime ? Msg.format("kits.one_time") : k.cooldownSeconds == 0
                    ? Msg.format("kits.no_cooldown") : TimeFmt.duration(k.cooldownSeconds * 1000)));
            b.lore(status(p, k), "", Msg.format("kits.icon_click"));
            entries.add(new Paged.Entry(b.hideExtra().build(), (pl, c) -> {
                if (c.right()) preview(pl, k);
                else if (claim(pl, k)) open(pl);
            }));
        }
        Paged.open(p, Msg.format("kits.title"), entries, 0, Hub::open, gui -> {
            if (entries.isEmpty()) gui.set(22, ItemBuilder.of(class_1802.field_8077).name(Msg.format("kits.none")).build());
            if (Perms.admin(p, "kits")) gui.button(51, ItemBuilder.of(class_1802.field_8674).name(Msg.format("kits.editor_button")).build(), Kits::editor);
        });
    }

    public static void preview(class_3222 p, KitsConfig.Kit k) {
        List<class_1799> items = items(k);
        Gui g = new Gui(Math.max(2, Math.min(6, (items.size() + 8) / 9 + 1)), Msg.format("kits.preview_title", "kit", TextUtil.strip(k.display)));
        for (int i = 0; i < items.size() && i < g.size() - 9; i++) g.set(i, items.get(i));
        if (!k.commands.isEmpty()) {
            g.set(g.size() - 9, ItemBuilder.of(class_1802.field_8866).name(Msg.format("kits.preview_commands")).lore(k.commands.stream().map(c -> "&7/" + c).toList()).build());
        }
        g.button(g.size() - 5, ItemBuilder.of(class_1802.field_8691).name(Msg.format("general.back")).build(), Kits::open);
        g.open(p);
    }

    public static boolean claim(class_3222 p, KitsConfig.Kit k) {
        if (!canUse(p, k)) {
            Msg.send(p, "general.no_permission");
            return false;
        }
        PlayerData d = PlayerStore.get(p);
        if (k.oneTime && d.kitsClaimed.contains(k.name)) {
            Msg.send(p, "kits.already", "kit", TextUtil.strip(k.display));
            return false;
        }
        long left = d.cooldownLeft(key(k));
        if (left > 0 && !Perms.perk(p, Perms.KIT_BYPASS)) {
            Msg.send(p, "kits.cooldown", "kit", TextUtil.strip(k.display), "time", TimeFmt.duration(left));
            return false;
        }
        int dropped = 0;
        for (class_1799 st : items(k)) {
            class_1799 copy = st.method_7972();
            if (!p.method_31548().method_7394(copy) || !copy.method_7960()) {
                p.method_7328(copy, false);
                dropped++;
            }
        }
        for (String c : k.commands) {
            String cmd = c.replace("%player%", p.method_7334().getName()).replace("%uuid%", p.method_5667().toString());
            CobbleUtils.server().method_3734().method_44252(CobbleUtils.server().method_3739(), cmd.startsWith("/") ? cmd.substring(1) : cmd);
        }
        if (k.oneTime) d.kitsClaimed.add(k.name);
        if (k.cooldownSeconds > 0) d.setCooldown(key(k), k.cooldownSeconds * 1000);
        PlayerStore.dirty(p.method_5667());
        PlayerStore.save(p.method_5667());
        Players.saveNow(p);
        Msg.send(p, "kits.claimed", "kit", TextUtil.strip(k.display));
        if (dropped > 0) Msg.send(p, "kits.dropped", "count", dropped);
        return true;
    }

    // ------------------------------------------------------------------ editeur

    public static void editor(class_3222 p) {
        if (!Perms.admin(p, "kits")) {
            Msg.send(p, "general.no_permission");
            return;
        }
        List<Paged.Entry> entries = new ArrayList<>();
        for (KitsConfig.Kit k : Cfg.kits.kits) {
            entries.add(new Paged.Entry(ItemBuilder.of(Reg.stack(k.icon)).name(k.display)
                    .lore(Msg.format("kits.editor_info", "name", k.name, "items", k.items.size(), "commands", k.commands.size(),
                            "cooldown", k.oneTime ? Msg.format("kits.one_time") : TimeFmt.duration(k.cooldownSeconds * 1000),
                            "access", k.defaultAccess ? Msg.format("kits.access_all") : "cobblepulse.kit." + k.name))
                    .lore("", Msg.format("kits.editor_click")).hideExtra().build(), (pl, c) -> edit(pl, k)));
        }
        Paged.open(p, Msg.format("kits.editor_title"), entries, 0, StaffPanel::open, gui -> gui.button(51,
                ItemBuilder.of(class_1802.field_8131).name(Msg.format("kits.editor_new")).build(),
                pl -> ChatInput.ask(pl, "kits.ask_name", name -> {
                    String n = name.trim().toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_\\-]", "_");
                    if (n.isEmpty() || Cfg.kits.find(n) != null) {
                        Msg.send(pl, "kits.bad_name");
                        editor(pl);
                        return;
                    }
                    KitsConfig.Kit k = new KitsConfig.Kit();
                    k.name = n;
                    k.display = "&b" + n;
                    Cfg.kits.kits.add(k);
                    save();
                    edit(pl, k);
                })));
    }

    private static void save() {
        Cfg.kits.normalize();
        Cfg.save("kits.json", Cfg.kits);
    }

    public static void edit(class_3222 p, KitsConfig.Kit k) {
        Gui g = new Gui(4, Msg.format("kits.edit_title", "kit", k.name));
        g.fill(Gui.pane());
        g.set(4, ItemBuilder.of(Reg.stack(k.icon)).name(k.display).lore(k.lore).hideExtra().build());
        g.button(10, ItemBuilder.of(class_1802.field_8106).name(Msg.format("kits.edit_items")).lore(Msg.format("kits.edit_items_lore", "count", k.items.size())).build(),
                pl -> editContents(pl, k));
        g.button(11, ItemBuilder.of(class_1802.field_8143).name(Msg.format("kits.edit_icon")).build(), pl -> {
            if (pl.method_6047().method_7960()) {
                Msg.send(pl, "warps.edit_icon_empty");
                return;
            }
            k.icon = Reg.id(pl.method_6047().method_7909());
            save();
            edit(pl, k);
        });
        g.button(12, ItemBuilder.of(class_1802.field_8448).name(Msg.format("kits.edit_name")).build(), pl -> ChatInput.ask(pl, "kits.ask_display", txt -> {
            k.display = txt;
            save();
            edit(pl, k);
        }, () -> edit(pl, k)));
        g.button(13, ItemBuilder.of(class_1802.field_8674).name(Msg.format("kits.edit_lore")).build(), pl -> ChatInput.ask(pl, "warps.ask_lore", txt -> {
            k.lore = txt.equals("-") ? new ArrayList<>() : new ArrayList<>(List.of(txt.split("\\|")));
            save();
            edit(pl, k);
        }, () -> edit(pl, k)));
        g.button(14, ItemBuilder.of(class_1802.field_8557).name(Msg.format("kits.edit_cooldown", "time", TimeFmt.duration(k.cooldownSeconds * 1000))).build(),
                pl -> ChatInput.ask(pl, "kits.ask_cooldown", txt -> {
                    Long s = ChatInput.parseDurationSeconds(txt);
                    if (s != null) k.cooldownSeconds = s;
                    save();
                    edit(pl, k);
                }, () -> edit(pl, k)));
        g.button(15, ItemBuilder.of(k.oneTime ? class_1802.field_8131 : class_1802.field_8298).name(Msg.format(k.oneTime ? "kits.edit_once_on" : "kits.edit_once_off")).build(), pl -> {
            k.oneTime = !k.oneTime;
            save();
            edit(pl, k);
        });
        g.button(16, ItemBuilder.of(k.defaultAccess ? class_1802.field_8874 : class_1802.field_8076)
                .name(Msg.format(k.defaultAccess ? "kits.edit_access_all" : "kits.edit_access_perm", "name", k.name)).build(), pl -> {
            k.defaultAccess = !k.defaultAccess;
            save();
            edit(pl, k);
        });
        g.button(20, ItemBuilder.of(class_1802.field_8866).name(Msg.format("kits.edit_commands", "count", k.commands.size()))
                .lore(k.commands.stream().map(c -> "&7/" + c).toList()).lore(Msg.format("kits.edit_commands_lore")).build(), (pl, c) -> {
            if (c.right() || c.shift()) {
                k.commands.clear();
                save();
                edit(pl, k);
                return;
            }
            ChatInput.ask(pl, "kits.ask_command", txt -> {
                k.commands.add(txt.startsWith("/") ? txt.substring(1) : txt);
                save();
                edit(pl, k);
            }, () -> edit(pl, k));
        });
        g.button(22, ItemBuilder.of(class_1802.field_8239).name(Msg.format("warps.edit_slot", "slot", k.slot < 0 ? "auto" : String.valueOf(k.slot))).build(),
                pl -> ChatInput.ask(pl, "warps.ask_slot", txt -> {
                    Long v = ChatInput.parseAmount(txt);
                    k.slot = v == null ? -1 : (int) Math.min(44, v);
                    save();
                    edit(pl, k);
                }, () -> edit(pl, k)));
        g.button(24, ItemBuilder.of(class_1802.field_8187).name(Msg.format("kits.edit_delete")).lore(Msg.format("warps.edit_delete_lore")).build(), (pl, c) -> {
            if (!c.shift()) {
                Msg.send(pl, "warps.edit_delete_shift");
                return;
            }
            Cfg.kits.kits.remove(k);
            save();
            Msg.send(pl, "kits.deleted", "kit", k.name);
            editor(pl);
        });
        g.button(27, ItemBuilder.of(class_1802.field_8691).name(Msg.format("general.back")).build(), Kits::editor);
        g.open(p);
    }

    /** Coffre modifiable : le contenu (NBT complet, enchantements compris) devient celui du kit a la fermeture. */
    public static void editContents(class_3222 p, KitsConfig.Kit k) {
        class_1277 c = new class_1277(54);
        List<class_1799> items = items(k);
        for (int i = 0; i < items.size() && i < 54; i++) c.method_5447(i, items.get(i));
        p.method_17355(new class_747((id, inv, pl) -> new class_1707(class_3917.field_17327, id, inv, c, 6) {
            @Override
            public void method_7595(class_1657 player) {
                super.method_7595(player);
                List<String> out = new ArrayList<>();
                for (int i = 0; i < c.method_5439(); i++) {
                    class_1799 s = c.method_5438(i);
                    if (!s.method_7960()) out.add(ItemSerial.toSnbt(s));
                }
                k.items = out;
                save();
                if (player instanceof class_3222 sp) {
                    Msg.send(sp, "kits.contents_saved", "kit", k.name, "count", out.size());
                    fr.cobblepulse.utils.core.Scheduler.next(() -> edit(sp, k));
                }
            }
        }, TextUtil.legacy(Msg.format("kits.contents_title", "kit", k.name))));
    }
}
