package fr.cobblepulse.utils.mixin;

import fr.cobblepulse.utils.essentials.ChatFeatures;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_5250;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** /nick : le surnom remplace le pseudo dans le nom affiche (chat, placeholders %player:displayname%). */
@Mixin(class_1657.class)
public abstract class PlayerDisplayNameMixin {
    @Inject(method = "getDisplayName", at = @At("HEAD"), cancellable = true)
    private void cpu$nick(CallbackInfoReturnable<class_2561> cir) {
        class_1657 self = (class_1657) (Object) this;
        if (self.method_37908().method_8608()) return;
        class_2561 nick = ChatFeatures.nickOf(self.method_5667());
        if (nick != null) {
            class_5250 c = class_268.method_1142(self.method_5781(), nick.method_27661());
            cir.setReturnValue(c);
        }
    }
}
