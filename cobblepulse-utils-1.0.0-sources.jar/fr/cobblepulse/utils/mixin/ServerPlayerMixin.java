package fr.cobblepulse.utils.mixin;

import fr.cobblepulse.utils.essentials.ChatFeatures;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7604;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** /ignore (chat public) et surnom dans la liste des joueurs. */
@Mixin(class_3222.class)
public abstract class ServerPlayerMixin {
    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    private void cpu$ignore(class_7604 message, boolean filtered, class_2556.class_7602 bound, CallbackInfo ci) {
        if (message instanceof class_7604.class_7607 pm
                && ChatFeatures.ignores((class_3222) (Object) this, pm.comp_1082().method_46292())) {
            ci.cancel();
        }
    }

    @Inject(method = "getTabListDisplayName", at = @At("HEAD"), cancellable = true)
    private void cpu$tabNick(CallbackInfoReturnable<class_2561> cir) {
        class_2561 nick = ChatFeatures.nickOf(((class_3222) (Object) this).method_5667());
        if (nick != null) cir.setReturnValue(nick);
    }
}
