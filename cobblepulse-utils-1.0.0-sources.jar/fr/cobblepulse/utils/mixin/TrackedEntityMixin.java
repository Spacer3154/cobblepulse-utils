package fr.cobblepulse.utils.mixin;

import fr.cobblepulse.utils.essentials.Vanish;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_3231;
import net.minecraft.class_5629;

/** /vanish : un joueur invisible n'est pas envoye aux clients qui n'ont pas le droit de le voir. */
@Mixin(targets = "net.minecraft.server.level.ChunkMap$TrackedEntity")
public abstract class TrackedEntityMixin {
    @Shadow
    @Final
    class_1297 entity;
    @Shadow
    @Final
    class_3231 serverEntity;
    @Shadow
    @Final
    private Set<class_5629> seenBy;

    @Inject(method = "updatePlayer", at = @At("HEAD"), cancellable = true)
    private void cpu$vanish(class_3222 viewer, CallbackInfo ci) {
        if (entity instanceof class_3222 target && Vanish.hiddenFrom(target, viewer)) {
            if (seenBy.remove(viewer.field_13987)) serverEntity.method_14302(viewer);
            ci.cancel();
        }
    }
}
