package fr.cobblepulse.utils.playtime;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import fr.cobblepulse.utils.command.Cmd;
import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.config.PlaytimeConfig;
import fr.cobblepulse.utils.config.Reward;
import fr.cobblepulse.utils.core.ItemBuilder;
import fr.cobblepulse.utils.core.Msg;
import fr.cobblepulse.utils.core.Perms;
import fr.cobblepulse.utils.core.Players;
import fr.cobblepulse.utils.core.Reg;
import fr.cobblepulse.utils.core.Rewards;
import fr.cobblepulse.utils.core.TextUtil;
import fr.cobblepulse.utils.core.TimeFmt;
import fr.cobblepulse.utils.data.PlayerData;
import fr.cobblepulse.utils.data.PlayerStore;
import fr.cobblepulse.utils.gui.ChatInput;
import fr.cobblepulse.utils.gui.Gui;
import fr.cobblepulse.utils.gui.Paged;
import fr.cobblepulse.utils.gui.Pickers;
import fr.cobblepulse.utils.gui.RewardEditor;
import fr.cobblepulse.utils.hub.Hub;
import fr.cobblepulse.utils.integration.LuckPermsBridge;
import fr.cobblepulse.utils.staff.StaffPanel;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2168;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * Recompenses de temps de jeu : paliers de temps actif cumule (1 h, 5 h, 10 h...) et bonus repetable toutes les N minutes.
 * Le temps des joueurs AFK (ni deplacement, ni rotation, ni message depuis {@code afk_minutes}) n'est pas compte.
 */
public final class PlaytimeRewards {
    private static final class Activity {
        double x, y, z;
        float yaw, pitch;
        long lastActive = System.currentTimeMillis();
    }

    private static final Map<UUID, Activity> ACTIVITY = new ConcurrentHashMap<>();

    private PlaytimeRewards() {}

    private static PlaytimeConfig cfg() {
        return Cfg.playtime;
    }

    // ------------------------------------------------------------------ suivi

    /** Activite explicite (message, commande). */
    public static void active(class_3222 p) {
        if (p != null) ACTIVITY.computeIfAbsent(p.method_5667(), k -> new Activity()).lastActive = System.currentTimeMillis();
    }

    public static boolean afk(class_3222 p) {
        int m = cfg().afkMinutes;
        if (m <= 0) return false;
        Activity a = ACTIVITY.get(p.method_5667());
        return a != null && System.currentTimeMillis() - a.lastActive > m * 60_000L;
    }

    private static void seed(class_3222 p, PlayerData d) {
        if (d.activeSeeded) return;
        d.activeSeeded = true;
        // le temps deja joue avant l'installation compte (statistique vanilla)
        d.activeSeconds = Math.max(d.activeSeconds, PlayerStore.playtimeTicks(p) / 20);
        PlayerStore.dirty(p.method_5667());
    }

    /** Chaque seconde : temps actif, bonus repetable, paliers atteints. */
    public static void tick() {
        if (!cfg().enabled) return;
        long now = System.currentTimeMillis();
        for (class_3222 p : fr.cobblepulse.utils.CobbleUtils.server().method_3760().method_14571()) {
            if (Players.isTest(p.method_5667())) continue;
            Activity a = ACTIVITY.computeIfAbsent(p.method_5667(), k -> new Activity());
            if (Math.abs(p.method_23317() - a.x) > 0.01 || Math.abs(p.method_23318() - a.y) > 0.01 || Math.abs(p.method_23321() - a.z) > 0.01
                    || Math.abs(p.method_36454() - a.yaw) > 0.5 || Math.abs(p.method_36455() - a.pitch) > 0.5) {
                a.x = p.method_23317();
                a.y = p.method_23318();
                a.z = p.method_23321();
                a.yaw = p.method_36454();
                a.pitch = p.method_36455();
                a.lastActive = now;
            }
            if (afk(p)) continue;
            addActive(p, 1);
        }
    }

    /** Ajoute du temps actif (aussi utilise par /ptr ajouter et les auto-tests). */
    public static void addActive(class_3222 p, long seconds) {
        PlayerData d = PlayerStore.get(p);
        seed(p, d);
        d.activeSeconds += seconds;
        d.repeatSeconds += seconds;
        PlayerStore.dirty(p.method_5667());
        PlaytimeConfig c = cfg();
        if (c.repeat.enabled && !c.repeat.rewards.isEmpty()) {
            long every = c.repeat.everyMinutes * 60;
            while (d.repeatSeconds >= every) {
                d.repeatSeconds -= every;
                giveRepeat(p);
            }
        }
        for (PlaytimeConfig.Tier t : c.tiers) {
            if (d.playtimeClaimed.contains(t.id) || !reached(d, t) || !allowed(p, t)) continue;
            if (c.autoClaim) claim(p, t);
            else if (d.playtimeNotified.add(t.id)) {
                Msg.send(p, "playtime.available", "tier", TextUtil.strip(t.name));
                PlayerStore.dirty(p.method_5667());
            }
        }
    }

    private static void giveRepeat(class_3222 p) {
        List<String> got = new ArrayList<>();
        for (Reward r : cfg().repeat.rewards) {
            String s = Rewards.roll(p, r);
            if (s != null) got.add(s);
        }
        Players.saveNow(p);
        Msg.send(p, "playtime.repeat_given", "time", TimeFmt.duration(cfg().repeat.everyMinutes * 60_000L),
                "rewards", got.isEmpty() ? "-" : String.join("&7, ", got));
    }

    public static long activeSeconds(class_3222 p) {
        PlayerData d = PlayerStore.get(p);
        seed(p, d);
        return d.activeSeconds;
    }

    static boolean reached(PlayerData d, PlaytimeConfig.Tier t) {
        return d.activeSeconds >= t.minutes * 60;
    }

    static boolean allowed(class_3222 p, PlaytimeConfig.Tier t) {
        if (t.permission == null || t.permission.isBlank()) return true;
        Boolean v = LuckPermsBridge.check(p, t.permission);
        return Boolean.TRUE.equals(v);
    }

    /** Paliers atteints et pas encore reclames. */
    public static int available(class_3222 p) {
        PlayerData d = PlayerStore.get(p);
        seed(p, d);
        int n = 0;
        for (PlaytimeConfig.Tier t : cfg().tiers) if (!d.playtimeClaimed.contains(t.id) && reached(d, t) && allowed(p, t)) n++;
        return n;
    }

    public static boolean claim(class_3222 p, PlaytimeConfig.Tier t) {
        PlayerData d = PlayerStore.get(p);
        seed(p, d);
        if (d.playtimeClaimed.contains(t.id)) {
            Msg.send(p, "playtime.already");
            return false;
        }
        if (!allowed(p, t)) {
            Msg.send(p, "general.no_permission");
            return false;
        }
        if (!reached(d, t)) {
            Msg.send(p, "playtime.locked", "time", TimeFmt.duration((t.minutes * 60 - d.activeSeconds) * 1000L));
            return false;
        }
        d.playtimeClaimed.add(t.id);
        PlayerStore.dirty(p.method_5667());
        PlayerStore.save(p.method_5667());
        List<String> got = new ArrayList<>();
        for (Reward r : t.rewards) {
            String s = Rewards.roll(p, r);
            if (s != null) got.add(s);
        }
        Players.saveNow(p);
        Msg.send(p, "playtime.claimed", "tier", TextUtil.strip(t.name), "rewards", got.isEmpty() ? "-" : String.join("&7, ", got));
        return true;
    }

    public static int claimAll(class_3222 p) {
        int n = 0;
        PlayerData d = PlayerStore.get(p);
        for (PlaytimeConfig.Tier t : cfg().tiers) {
            if (!d.playtimeClaimed.contains(t.id) && reached(d, t) && allowed(p, t) && claim(p, t)) n++;
        }
        if (n == 0) Msg.send(p, "playtime.nothing");
        return n;
    }

    // ------------------------------------------------------------------ menu joueur

    static String minutes(long m) {
        return TimeFmt.duration(m * 60_000L);
    }

    private static class_1799 progressIcon(class_3222 p) {
        PlayerData d = PlayerStore.get(p);
        ItemBuilder b = ItemBuilder.of(class_1802.field_8557).name(Msg.format("playtime.progress", "time", TimeFmt.duration(d.activeSeconds * 1000L)));
        b.lore(Msg.format("playtime.progress_total", "time", TimeFmt.duration(PlayerStore.playtimeTicks(p) * 50L)));
        b.lore(Msg.format(afk(p) ? "playtime.status_afk" : "playtime.status_active", "minutes", cfg().afkMinutes));
        if (cfg().repeat.enabled && !cfg().repeat.rewards.isEmpty()) {
            b.lore(Msg.format("playtime.repeat_next", "time", TimeFmt.duration((cfg().repeat.everyMinutes * 60 - d.repeatSeconds) * 1000L)));
        }
        return b.build();
    }

    private static class_1799 tierIcon(class_3222 p, PlaytimeConfig.Tier t) {
        PlayerData d = PlayerStore.get(p);
        boolean claimed = d.playtimeClaimed.contains(t.id);
        boolean ok = reached(d, t);
        boolean perm = allowed(p, t);
        ItemBuilder b = ItemBuilder.of(claimed ? new class_1799(class_1802.field_8581) : Reg.stack(t.icon)).name(t.name).lore(t.lore);
        b.lore(Msg.format("playtime.tier_need", "time", minutes(t.minutes)));
        String status;
        if (claimed) status = Msg.format("dex.status_claimed");
        else if (!perm) status = Msg.format("playtime.status_rank");
        else if (ok) status = Msg.format("dex.status_ready");
        else status = Msg.format("playtime.status_left", "time", TimeFmt.duration((t.minutes * 60 - d.activeSeconds) * 1000L));
        b.lore(status);
        b.lore(Msg.format("dex.tier_rewards"));
        for (Reward r : t.rewards) b.lore("  &8• " + Rewards.describe(r) + (r.chance < 100 ? " &8(" + fmt(r.chance) + " %)" : ""));
        b.glow(ok && perm && !claimed);
        return b.hideExtra().build();
    }

    private static String fmt(double d) {
        return d == Math.rint(d) ? String.valueOf((long) d) : String.format(java.util.Locale.FRANCE, "%.1f", d);
    }

    public static void open(class_3222 p) {
        if (!cfg().enabled) {
            Msg.send(p, "playtime.disabled");
            return;
        }
        PlayerData d = PlayerStore.get(p);
        seed(p, d);
        List<Paged.Entry> entries = new ArrayList<>();
        PlaytimeConfig.Repeat rep = cfg().repeat;
        if (rep.enabled && !rep.rewards.isEmpty()) {
            ItemBuilder b = ItemBuilder.of(Reg.stack(rep.icon)).name(rep.name);
            b.lore(Msg.format("playtime.repeat_every", "time", minutes(rep.everyMinutes)));
            b.lore(Msg.format("playtime.repeat_next", "time", TimeFmt.duration((rep.everyMinutes * 60 - d.repeatSeconds) * 1000L)));
            for (Reward r : rep.rewards) b.lore("  &8• " + Rewards.describe(r) + (r.chance < 100 ? " &8(" + fmt(r.chance) + " %)" : ""));
            entries.add(new Paged.Entry(b.hideExtra().build(), null));
        }
        for (PlaytimeConfig.Tier t : cfg().tiers) {
            entries.add(new Paged.Entry(tierIcon(p, t), (pl, c) -> {
                if (claim(pl, t)) open(pl);
            }));
        }
        Paged.open(p, Msg.format("playtime.title", "time", TimeFmt.duration(d.activeSeconds * 1000L)), entries, 0, Hub::open, gui -> {
            gui.set(49, progressIcon(p));
            gui.button(48, ItemBuilder.of(class_1802.field_8691).name(Msg.format("general.back")).build(), Hub::open);
            gui.button(50, ItemBuilder.of(class_1802.field_8239).name(Msg.format("dex.claim_all")).build(), pl -> {
                claimAll(pl);
                open(pl);
            });
            if (Perms.admin(p, "playtime")) gui.button(53, ItemBuilder.of(class_1802.field_8674).name(Msg.format("playtime.editor_button")).build(), PlaytimeRewards::editor);
            // progression en direct
            gui.every(20, gg -> gg.set(49, progressIcon(p)));
        });
    }

    // ------------------------------------------------------------------ editeur (cobblepulse.admin.playtime)

    private static void save() {
        cfg().normalize();
        Cfg.save("playtimerewards.json", cfg());
    }

    public static void editor(class_3222 p) {
        if (!Perms.admin(p, "playtime")) {
            Msg.send(p, "general.no_permission");
            return;
        }
        List<Paged.Entry> entries = new ArrayList<>();
        PlaytimeConfig.Repeat rep = cfg().repeat;
        entries.add(new Paged.Entry(ItemBuilder.of(Reg.stack(rep.icon)).name(rep.name)
                .lore(Msg.format("playtime.editor_repeat", "time", minutes(rep.everyMinutes), "state", rep.enabled ? "&aactif" : "&cdésactivé",
                        "rewards", rep.rewards.size()))
                .lore("", Msg.format("dex.editor_click")).hideExtra().build(), (pl, c) -> editRepeat(pl)));
        for (PlaytimeConfig.Tier t : cfg().tiers) {
            entries.add(new Paged.Entry(ItemBuilder.of(Reg.stack(t.icon)).name(t.name)
                    .lore(Msg.format("playtime.editor_info", "id", t.id, "time", minutes(t.minutes), "rewards", t.rewards.size()))
                    .lore("", Msg.format("dex.editor_click")).hideExtra().build(), (pl, c) -> edit(pl, t)));
        }
        Paged.open(p, Msg.format("playtime.editor_title"), entries, 0, StaffPanel::open, gui -> {
            gui.button(51, ItemBuilder.of(class_1802.field_8131).name(Msg.format("playtime.editor_new")).build(),
                    pl -> ChatInput.ask(pl, "playtime.ask_time", txt -> {
                        Long sec = ChatInput.parseDurationSeconds(txt);
                        if (sec == null || sec < 60) {
                            Msg.send(pl, "general.bad_number");
                            editor(pl);
                            return;
                        }
                        PlaytimeConfig.Tier t = new PlaytimeConfig.Tier();
                        t.minutes = sec / 60;
                        t.id = "m" + t.minutes;
                        int k = 2;
                        while (find(t.id) != null) t.id = "m" + t.minutes + "_" + k++;
                        t.name = "&e" + minutes(t.minutes) + " de jeu";
                        cfg().tiers.add(t);
                        save();
                        edit(pl, t);
                    }, () -> editor(pl)));
            gui.button(47, ItemBuilder.of(cfg().enabled ? class_1802.field_8131 : class_1802.field_8298)
                    .name(Msg.format(cfg().enabled ? "playtime.editor_on" : "playtime.editor_off")).build(), pl -> {
                cfg().enabled = !cfg().enabled;
                save();
                editor(pl);
            });
            gui.button(46, ItemBuilder.of(class_1802.field_8239).name(Msg.format(cfg().autoClaim ? "playtime.editor_auto_on" : "playtime.editor_auto_off"))
                    .lore(Msg.format("playtime.editor_auto_lore")).build(), pl -> {
                cfg().autoClaim = !cfg().autoClaim;
                save();
                editor(pl);
            });
            gui.button(48, ItemBuilder.of(class_1802.field_8575).name(Msg.format("playtime.editor_reset_player")).lore(Msg.format("playtime.editor_reset_player_lore")).build(),
                    pl -> ChatInput.ask(pl, "playtime.ask_reset_player", txt -> confirmReset(pl, txt.trim()), () -> editor(pl)));
            gui.button(52, ItemBuilder.of(class_1802.field_8626).name(Msg.format("playtime.editor_reset_all")).lore(Msg.format("playtime.editor_reset_all_lore")).build(),
                    pl -> confirmReset(pl, null));
            gui.button(50, ItemBuilder.of(class_1802.field_8694).name(Msg.format("playtime.editor_afk", "minutes", cfg().afkMinutes))
                    .lore(Msg.format("playtime.editor_afk_lore")).build(), pl -> ChatInput.ask(pl, "playtime.ask_afk", txt -> {
                Long v = ChatInput.parseAmount(txt);
                if (v != null) cfg().afkMinutes = (int) Math.max(0, Math.min(1440, v));
                save();
                editor(pl);
            }, () -> editor(pl)));
        });
    }

    static PlaytimeConfig.Tier find(String id) {
        for (PlaytimeConfig.Tier t : cfg().tiers) if (t.id.equalsIgnoreCase(id)) return t;
        return null;
    }

    public static void edit(class_3222 p, PlaytimeConfig.Tier t) {
        RewardEditor.open(p, Msg.format("playtime.edit_title", "tier", TextUtil.strip(t.name)), t.rewards, PlaytimeRewards::save,
                PlaytimeRewards::editor, g -> {
                    g.button(50, ItemBuilder.of(Reg.stack(t.icon)).name(t.name).lore(Msg.format("playtime.edit_icon_lore")).build(), (pl, c) -> {
                        if (c.right()) {
                            ChatInput.ask(pl, "kits.ask_display", txt -> {
                                t.name = txt;
                                save();
                                edit(pl, t);
                            }, () -> edit(pl, t));
                            return;
                        }
                        Pickers.item(pl, "worlds.pick_icon", id -> {
                            t.icon = id;
                            save();
                            edit(pl, t);
                        }, () -> edit(pl, t));
                    });
                    g.button(51, ItemBuilder.of(class_1802.field_8557).name(Msg.format("playtime.edit_time", "time", minutes(t.minutes))).build(),
                            pl -> ChatInput.ask(pl, "playtime.ask_time", txt -> {
                                Long sec = ChatInput.parseDurationSeconds(txt);
                                if (sec != null && sec >= 60) t.minutes = sec / 60;
                                save();
                                edit(pl, t);
                            }, () -> edit(pl, t)));
                    g.button(52, ItemBuilder.of(class_1802.field_8448).name(Msg.format("playtime.edit_permission",
                            "node", t.permission.isBlank() ? "-" : t.permission)).lore(Msg.format("playtime.edit_permission_lore")).build(),
                            pl -> ChatInput.ask(pl, "playtime.ask_permission", txt -> {
                                t.permission = txt.trim().equals("-") ? "" : txt.trim();
                                save();
                                edit(pl, t);
                            }, () -> edit(pl, t)));
                    g.button(53, ItemBuilder.of(class_1802.field_8187).name(Msg.format("dex.edit_delete")).lore(Msg.format("warps.edit_delete_lore")).build(), (pl, c) -> {
                        if (!c.shift()) {
                            Msg.send(pl, "warps.edit_delete_shift");
                            return;
                        }
                        cfg().tiers.remove(t);
                        save();
                        editor(pl);
                    });
                });
    }

    public static void editRepeat(class_3222 p) {
        PlaytimeConfig.Repeat rep = cfg().repeat;
        RewardEditor.open(p, Msg.format("playtime.edit_title", "tier", TextUtil.strip(rep.name)), rep.rewards, PlaytimeRewards::save,
                PlaytimeRewards::editor, g -> {
                    g.button(50, ItemBuilder.of(rep.enabled ? class_1802.field_8131 : class_1802.field_8298)
                            .name(Msg.format(rep.enabled ? "playtime.editor_on" : "playtime.editor_off")).build(), pl -> {
                        rep.enabled = !rep.enabled;
                        save();
                        editRepeat(pl);
                    });
                    g.button(51, ItemBuilder.of(class_1802.field_8557).name(Msg.format("playtime.edit_every", "time", minutes(rep.everyMinutes))).build(),
                            pl -> ChatInput.ask(pl, "playtime.ask_time", txt -> {
                                Long sec = ChatInput.parseDurationSeconds(txt);
                                if (sec != null && sec >= 60) rep.everyMinutes = sec / 60;
                                save();
                                editRepeat(pl);
                            }, () -> editRepeat(pl)));
                    g.button(52, ItemBuilder.of(class_1802.field_8448).name(Msg.format("dex.edit_name")).build(), pl -> ChatInput.ask(pl, "kits.ask_display", txt -> {
                        rep.name = txt;
                        save();
                        editRepeat(pl);
                    }, () -> editRepeat(pl)));
                });
    }

    // ------------------------------------------------------------------ commandes

    private static final com.mojang.brigadier.suggestion.SuggestionProvider<class_2168> ONLINE = (ctx, b) ->
            net.minecraft.class_2172.method_9253(ctx.getSource().method_9211().method_3858(), b);

    public static void register(CommandDispatcher<class_2168> d) {
        Cmd.player(d, "playtimerewards", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, PlaytimeRewards::open))
                .then(method_9247("reclamer").executes(ctx -> Cmd.asPlayer(ctx, PlaytimeRewards::claimAll)))
                .then(method_9247("ajouter").requires(Perms.adminReq("playtime"))
                        .then(method_9244("joueur", StringArgumentType.word()).suggests(ONLINE).then(method_9244("duree", StringArgumentType.word()).executes(ctx -> {
                            class_3222 t = Players.online(StringArgumentType.getString(ctx, "joueur"));
                            if (t == null) {
                                Msg.send(ctx.getSource(), "general.player_not_found", "player", StringArgumentType.getString(ctx, "joueur"));
                                return 0;
                            }
                            Long sec = ChatInput.parseDurationSeconds(StringArgumentType.getString(ctx, "duree"));
                            if (sec == null || sec <= 0) {
                                Msg.send(ctx.getSource(), "general.bad_number");
                                return 0;
                            }
                            addActive(t, sec);
                            Msg.send(ctx.getSource(), "playtime.added", "player", t.method_7334().getName(), "time", TimeFmt.duration(sec * 1000L));
                            return 1;
                        }))))
                .then(method_9247("reinitialiser").requires(Perms.adminReq("playtime"))
                        .then(method_9244("joueur", StringArgumentType.word()).suggests(ONLINE_ALL)
                                .executes(ctx -> resetCommand(ctx.getSource(), StringArgumentType.getString(ctx, "joueur"), false))
                                .then(method_9247("paliers").executes(ctx -> resetCommand(ctx.getSource(), StringArgumentType.getString(ctx, "joueur"), false)))
                                .then(method_9247("tout").executes(ctx -> resetCommand(ctx.getSource(), StringArgumentType.getString(ctx, "joueur"), true))))));
    }

    private static final com.mojang.brigadier.suggestion.SuggestionProvider<class_2168> ONLINE_ALL = (ctx, b) -> {
        List<String> out = new ArrayList<>(List.of(ctx.getSource().method_9211().method_3858()));
        out.add("tous");
        return net.minecraft.class_2172.method_9265(out, b);
    };

    /** Remise a zero : paliers reclames (+ temps de jeu actif si {@code time}). */
    static void resetData(PlayerData d, boolean time) {
        d.playtimeClaimed.clear();
        d.playtimeNotified.clear();
        d.repeatSeconds = 0;
        if (time) {
            d.activeSeconds = 0;
            // ne pas reprendre le temps de la statistique du jeu apres une remise a zero
            d.activeSeeded = true;
        }
    }

    private static int resetCommand(class_2168 src, String who, boolean time) {
        if (who.equalsIgnoreCase("tous") || who.equalsIgnoreCase("all") || who.equals("*")) {
            resetAll(time, n -> Msg.send(src, "playtime.reset_all", "count", n, "what", Msg.format(time ? "playtime.reset_what_all" : "playtime.reset_what_tiers")));
            return 1;
        }
        return resetPlayer(src, who, time) ? 1 : 0;
    }

    /** Un joueur, en ligne ou non (par son nom). */
    public static boolean resetPlayer(class_2168 src, String name, boolean time) {
        class_3222 online = Players.online(name);
        UUID u = online != null ? online.method_5667() : PlayerStore.findByName(name);
        if (u == null) {
            Msg.send(src, "general.player_not_found", "player", name);
            return false;
        }
        PlayerStore.update(u, d -> resetData(d, time));
        Msg.send(src, "playtime.reset", "player", online != null ? online.method_7334().getName() : name,
                "what", Msg.format(time ? "playtime.reset_what_all" : "playtime.reset_what_tiers"));
        return true;
    }

    /** Tous les joueurs connus du serveur (en ligne et hors ligne). */
    public static void resetAll(boolean time, java.util.function.IntConsumer done) {
        PlayerStore.updateAll(d -> resetData(d, time)).whenComplete((n, t) -> fr.cobblepulse.utils.core.Scheduler.next(() -> {
            if (t != null) fr.cobblepulse.utils.CobbleUtils.LOG.error("[CobblePulse-Utils] Remise a zero du temps de jeu : {}", t.toString());
            done.accept(n == null ? 0 : n);
        }));
    }

    /** Ecran de confirmation (paliers seuls / paliers + temps de jeu). */
    static void confirmReset(class_3222 p, String who) {
        boolean all = who == null;
        Gui g = new Gui(3, Msg.format("playtime.reset_title", "who", all ? Msg.format("playtime.reset_everyone") : who));
        g.fill(Gui.pane());
        g.button(11, ItemBuilder.of(class_1802.field_8239).name(Msg.format("playtime.reset_tiers")).lore(Msg.format("playtime.reset_tiers_lore")).build(), pl -> {
            if (all) resetAll(false, n -> {
                Msg.send(pl, "playtime.reset_all", "count", n, "what", Msg.format("playtime.reset_what_tiers"));
                editor(pl);
            });
            else {
                resetPlayer(pl.method_5671(), who, false);
                editor(pl);
            }
        });
        g.button(15, ItemBuilder.of(class_1802.field_8187).name(Msg.format("playtime.reset_full")).lore(Msg.format("playtime.reset_full_lore")).build(), pl -> {
            if (all) resetAll(true, n -> {
                Msg.send(pl, "playtime.reset_all", "count", n, "what", Msg.format("playtime.reset_what_all"));
                editor(pl);
            });
            else {
                resetPlayer(pl.method_5671(), who, true);
                editor(pl);
            }
        });
        g.button(22, ItemBuilder.of(class_1802.field_8691).name(Msg.format("general.cancel")).build(), PlaytimeRewards::editor);
        g.open(p);
    }

    /** Texte d'appoint pour /playtime : prochain palier. */
    public static String nextTierText(class_3222 p) {
        PlayerData d = PlayerStore.get(p);
        seed(p, d);
        for (PlaytimeConfig.Tier t : cfg().tiers) {
            if (d.playtimeClaimed.contains(t.id) || !allowed(p, t)) continue;
            if (reached(d, t)) return Msg.format("playtime.next_ready", "tier", TextUtil.strip(t.name));
            return Msg.format("playtime.next_in", "tier", TextUtil.strip(t.name), "time", TimeFmt.duration((t.minutes * 60 - d.activeSeconds) * 1000L));
        }
        return "";
    }

    public static void forget(UUID uuid) {
        ACTIVITY.remove(uuid);
    }
}
