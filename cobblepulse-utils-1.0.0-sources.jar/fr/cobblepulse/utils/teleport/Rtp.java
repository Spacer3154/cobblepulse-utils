package fr.cobblepulse.utils.teleport;

import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.core.Loc;
import fr.cobblepulse.utils.core.Msg;
import fr.cobblepulse.utils.core.Scheduler;
import java.util.function.Consumer;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_5819;

/** /rtp : position aleatoire et sure (sol solide, pas de liquide, deux blocs d'air), un essai par tick. */
public final class Rtp {
    private Rtp() {}

    public static void start(class_3222 p, class_3218 level) {
        Msg.send(p, "teleport.rtp_searching");
        attempt(p, level, Cfg.general.teleport.rtpAttempts, loc -> {
            if (loc == null) {
                Msg.send(p, "teleport.rtp_failed");
                return;
            }
            Teleports.teleport(p, loc, Msg.format("teleport.rtp_label", "x", (int) loc.x, "z", (int) loc.z), null);
        });
    }

    private static void attempt(class_3222 p, class_3218 level, int left, Consumer<Loc> done) {
        if (p.method_14239()) return;
        if (left <= 0) {
            done.accept(null);
            return;
        }
        Loc found = tryOnce(level, level.method_8409());
        if (found != null) {
            done.accept(found);
            return;
        }
        Scheduler.next(() -> attempt(p, level, left - 1, done));
    }

    public static Loc tryOnce(class_3218 level, class_5819 rnd) {
        var w = Worlds.get(level);
        int min = w.rtpMinRadius;
        int max = Math.max(min + 1, w.rtpMaxRadius);
        class_2338 sp = level.method_43126();
        class_2338 center = new class_2338(w.rtpCenterX != null ? w.rtpCenterX : sp.method_10263(), sp.method_10264(), w.rtpCenterZ != null ? w.rtpCenterZ : sp.method_10260());
        double angle = rnd.method_43058() * Math.PI * 2;
        double dist = min + rnd.method_43058() * (max - min);
        int x = center.method_10263() + (int) (Math.cos(angle) * dist);
        int z = center.method_10260() + (int) (Math.sin(angle) * dist);
        if (!level.method_8621().method_11952(new class_2338(x, 64, z))) return null;
        level.method_8497(x >> 4, z >> 4);
        class_2338 pos = safeColumn(level, x, z);
        return pos == null ? null : new Loc(level.method_27983().method_29177().toString(), pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5, rnd.method_43057() * 360f - 180f, 0);
    }

    /** Premier emplacement sur dans la colonne (surface, ou sous un plafond pour le Nether). */
    public static class_2338 safeColumn(class_3218 level, int x, int z) {
        if (level.method_8597().comp_643()) {
            int top = Math.min(level.method_31600() - 2, level.method_31607() + level.method_32819() - 2);
            for (int y = top; y > level.method_31607() + 2; y--) {
                class_2338 feet = new class_2338(x, y, z);
                if (safe(level, feet)) return feet;
            }
            return null;
        }
        int y = level.method_8624(class_2902.class_2903.field_13203, x, z);
        class_2338 feet = new class_2338(x, y, z);
        return safe(level, feet) ? feet : null;
    }

    public static boolean safe(class_3218 level, class_2338 feet) {
        class_2680 below = level.method_8320(feet.method_10074());
        class_2680 at = level.method_8320(feet);
        class_2680 head = level.method_8320(feet.method_10084());
        if (!below.method_26216(level, feet.method_10074()) && !below.method_26164(class_3481.field_15503)) return false;
        if (below.method_27852(class_2246.field_10092) || below.method_27852(class_2246.field_10029) || below.method_27852(class_2246.field_17350) || below.method_27852(class_2246.field_23860)
                || below.method_27852(class_2246.field_27879) || below.method_27852(class_2246.field_9987) && level.method_8597().comp_643() && feet.method_10264() > 120) return false;
        if (!at.method_26220(level, feet).method_1110() || !head.method_26220(level, feet.method_10084()).method_1110()) return false;
        if (!level.method_8316(feet).method_15769() || !level.method_8316(feet.method_10084()).method_15769()) return false;
        if (level.method_8316(feet.method_10074()).method_15767(class_3486.field_15518) || level.method_8316(feet.method_10074()).method_15767(class_3486.field_15517)) return false;
        return !at.method_27852(class_2246.field_10036) && !at.method_27852(class_2246.field_22089) && !at.method_27852(class_2246.field_16999);
    }
}
