package fr.cobblepulse.utils.teleport;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import fr.cobblepulse.utils.command.Cmd;
import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.config.WarpsConfig;
import fr.cobblepulse.utils.core.Loc;
import fr.cobblepulse.utils.core.Msg;
import fr.cobblepulse.utils.core.Perms;
import fr.cobblepulse.utils.data.PlayerData;
import fr.cobblepulse.utils.data.PlayerStore;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2181;
import net.minecraft.class_2186;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

import static net.minecraft.class_2170.method_9244;

/** Commandes de teleportation (§4.2) et de staff associees (/setspawn, /setwarp, /delwarp, /tphere, /tpall). */
public final class TeleportCommands {
    private TeleportCommands() {}

    private static final SuggestionProvider<class_2168> WARPS = (ctx, b) -> {
        List<String> names = new ArrayList<>();
        class_3222 p = ctx.getSource().method_44023();
        for (WarpsConfig.Warp w : Cfg.warps.warps) if (p == null || WarpMenus.canUse(p, w)) names.add(w.name);
        return class_2172.method_9265(names, b);
    };
    private static final SuggestionProvider<class_2168> ALL_WARPS = (ctx, b) ->
            class_2172.method_9265(Cfg.warps.warps.stream().map(w -> w.name).toList(), b);
    private static final SuggestionProvider<class_2168> HOMES = (ctx, b) -> {
        class_3222 p = ctx.getSource().method_44023();
        return class_2172.method_9265(p == null ? List.of() : PlayerStore.get(p).homes.keySet(), b);
    };
    private static final SuggestionProvider<class_2168> TPA_PENDING = (ctx, b) -> {
        class_3222 p = ctx.getSource().method_44023();
        return class_2172.method_9265(p == null ? List.of() : Tpa.pendingNames(p), b);
    };

    public static void register(CommandDispatcher<class_2168> d) {
        Cmd.player(d, "spawn", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, p ->
                        Teleports.teleport(p, Worlds.spawnFor(p), Msg.format("teleport.spawn_label"), null)))
                .then(method_9244("monde", class_2181.method_9288()).executes(ctx -> Cmd.asPlayer(ctx, p -> {
                    Worlds.go(p, Worlds.id(class_2181.method_9289(ctx, "monde")));
                    return 1;
                }))));
        // spawn du monde courant (et spawn global dans le monde principal)
        Cmd.admin(d, "setspawn", "setspawn", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, Worlds::setSpawn)));

        // Warps
        Cmd.player(d, "warp", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, WarpMenus::open))
                .then(method_9244("nom", StringArgumentType.word()).suggests(WARPS).executes(ctx -> Cmd.run(ctx, p -> {
                    WarpsConfig.Warp w = Cfg.warps.find(StringArgumentType.getString(ctx, "nom"));
                    if (w == null || !WarpMenus.canUse(p, w)) {
                        Msg.send(p, "warps.unknown", "warp", StringArgumentType.getString(ctx, "nom"));
                        return;
                    }
                    WarpMenus.go(p, w);
                }))));
        Cmd.admin(d, "setwarp", "warps", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, WarpMenus::editor))
                .then(method_9244("nom", StringArgumentType.word()).suggests(ALL_WARPS).executes(ctx -> Cmd.run(ctx, p -> {
                    WarpsConfig.Warp w = WarpMenus.createAt(p, StringArgumentType.getString(ctx, "nom"));
                    if (w != null) WarpMenus.edit(p, w);
                }))));
        Cmd.admin(d, "delwarp", "warps", l -> Cmd.lit(l)
                .then(method_9244("nom", StringArgumentType.word()).suggests(ALL_WARPS).executes(ctx -> {
                    String n = StringArgumentType.getString(ctx, "nom");
                    WarpsConfig.Warp w = Cfg.warps.find(n);
                    if (w == null) {
                        Msg.send(ctx.getSource(), "warps.unknown", "warp", n);
                        return 0;
                    }
                    Cfg.warps.warps.remove(w);
                    Cfg.save("warps.json", Cfg.warps);
                    Msg.send(ctx.getSource(), "warps.deleted", "warp", w.name);
                    return 1;
                })));

        // Homes
        Cmd.player(d, "home", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, WarpMenus::homes))
                .then(method_9244("nom", StringArgumentType.word()).suggests(HOMES).executes(ctx -> Cmd.run(ctx, p -> {
                    String n = StringArgumentType.getString(ctx, "nom").toLowerCase(java.util.Locale.ROOT);
                    Loc loc = PlayerStore.get(p).homes.get(n);
                    if (loc == null) {
                        Msg.send(p, "homes.unknown", "home", n);
                        return;
                    }
                    Teleports.teleport(p, loc, Msg.format("homes.label", "home", n), null);
                }))));
        Cmd.player(d, "sethome", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, p -> HomeLimits.setHome(p, "home")))
                .then(method_9244("nom", StringArgumentType.word()).executes(ctx -> Cmd.run(ctx, p ->
                        HomeLimits.setHome(p, StringArgumentType.getString(ctx, "nom"))))));
        Cmd.player(d, "delhome", l -> Cmd.lit(l)
                .then(method_9244("nom", StringArgumentType.word()).suggests(HOMES).executes(ctx -> Cmd.run(ctx, p -> {
                    String n = StringArgumentType.getString(ctx, "nom").toLowerCase(java.util.Locale.ROOT);
                    PlayerData data = PlayerStore.get(p);
                    if (data.homes.remove(n) == null) {
                        Msg.send(p, "homes.unknown", "home", n);
                        return;
                    }
                    PlayerStore.dirty(p.method_5667());
                    Msg.send(p, "homes.deleted", "home", n);
                }))));

        // TPA
        Cmd.player(d, "tpa", l -> Cmd.lit(l).then(method_9244("joueur", class_2186.method_9305()).executes(ctx -> Cmd.asPlayer(ctx, p ->
                Tpa.request(p, class_2186.method_9315(ctx, "joueur"), false)))));
        Cmd.player(d, "tpahere", l -> Cmd.lit(l).then(method_9244("joueur", class_2186.method_9305()).executes(ctx -> Cmd.asPlayer(ctx, p ->
                Tpa.request(p, class_2186.method_9315(ctx, "joueur"), true)))));
        Cmd.player(d, "tpaccept", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> Tpa.accept(p, null)))
                .then(method_9244("joueur", StringArgumentType.word()).suggests(TPA_PENDING).executes(ctx -> Cmd.asPlayer(ctx, p ->
                        Tpa.accept(p, StringArgumentType.getString(ctx, "joueur"))))));
        Cmd.player(d, "tpdeny", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> Tpa.deny(p, null)))
                .then(method_9244("joueur", StringArgumentType.word()).suggests(TPA_PENDING).executes(ctx -> Cmd.asPlayer(ctx, p ->
                        Tpa.deny(p, StringArgumentType.getString(ctx, "joueur"))))));
        Cmd.player(d, "tptoggle", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, p -> {
            PlayerData data = PlayerStore.get(p);
            data.tpToggle = !data.tpToggle;
            PlayerStore.dirty(p.method_5667());
            Msg.send(p, data.tpToggle ? "tpa.toggle_off" : "tpa.toggle_on");
        })));

        // Back / RTP / Top / Jump
        Cmd.player(d, "back", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, TeleportCommands::back)));
        Cmd.player(d, "rtp", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, p -> rtp(p, null)))
                .then(method_9244("monde", class_2181.method_9288()).executes(ctx -> Cmd.asPlayer(ctx, p -> {
                    rtp(p, class_2181.method_9289(ctx, "monde"));
                    return 1;
                }))));
        Cmd.player(d, "top", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, p -> {
            class_3218 level = p.method_51469();
            int y = level.method_8624(class_2902.class_2903.field_13197, p.method_31477(), p.method_31479());
            Teleports.perform(p, new Loc(level.method_27983().method_29177().toString(), p.method_31477() + 0.5, y, p.method_31479() + 0.5, p.method_36454(), p.method_36455()),
                    Msg.format("teleport.top_label"), null);
        })));
        Cmd.player(d, "jump", l -> Cmd.lit(l).executes(ctx -> Cmd.run(ctx, TeleportCommands::jump)));

        // Staff
        Cmd.admin(d, "tphere", "tphere", l -> Cmd.lit(l).then(method_9244("joueur", class_2186.method_9308()).executes(ctx -> Cmd.asPlayer(ctx, p -> {
            int n = 0;
            for (class_3222 t : class_2186.method_9312(ctx, "joueur")) {
                if (t == p) continue;
                Teleports.perform(t, Loc.of(p), p.method_7334().getName(), null);
                n++;
            }
            Msg.send(p, "teleport.tphere_done", "count", n);
            return n;
        }))));
        Cmd.admin(d, "tpall", "tpall", l -> Cmd.lit(l).executes(ctx -> Cmd.asPlayer(ctx, p -> {
            int n = 0;
            for (class_3222 t : new ArrayList<>(p.method_5682().method_3760().method_14571())) {
                if (t == p) continue;
                Teleports.perform(t, Loc.of(p), p.method_7334().getName(), null);
                n++;
            }
            Msg.send(p, "teleport.tpall_done", "count", n);
            return n;
        })));
        // /tp et /teleport vanilla : accessibles aussi avec cobblepulse.admin.tp
        Cmd.allowAlso(d, "tp", Perms.adminReq("tp").and(class_2168::method_43737));
        Cmd.allowAlso(d, "teleport", Perms.adminReq("tp").and(class_2168::method_43737));
    }

    static void back(class_3222 p) {
        PlayerData d = PlayerStore.get(p);
        if (d.back == null || d.back.level() == null) {
            Msg.send(p, "teleport.no_back");
            return;
        }
        if (d.backIsDeath && !backOnDeathAllowed(p)) {
            Msg.send(p, "teleport.no_back_death");
            return;
        }
        if (!Teleports.checkCooldown(p, "back", Cfg.general.teleport.backCooldownSeconds)) return;
        Teleports.teleport(p, d.back.copy(), Msg.format("teleport.back_label"), null);
    }

    public static boolean backOnDeathAllowed(class_3222 p) {
        Boolean v = fr.cobblepulse.utils.integration.LuckPermsBridge.check(p, Perms.BACK_ON_DEATH);
        return v != null ? v : Cfg.general.teleport.backOnDeathDefault || p.method_5687(Cfg.general.opLevel);
    }

    static void rtp(class_3222 p, class_3218 requested) {
        class_3218 level = requested;
        if (level == null) {
            // monde courant s'il autorise le /rtp, sinon monde principal, sinon le premier monde qui l'autorise
            level = p.method_51469();
            if (!Worlds.get(level).rtp) level = Worlds.mainLevel();
            if (!Worlds.get(level).rtp) {
                for (class_3218 l : p.method_5682().method_3738()) {
                    if (Worlds.get(l).rtp) {
                        level = l;
                        break;
                    }
                }
            }
        }
        String id = Worlds.id(level);
        if (!Worlds.get(level).rtp || !Worlds.canAccess(p, id)) {
            Msg.send(p, "teleport.rtp_world_denied", "world", Worlds.plainName(id));
            return;
        }
        if (Teleports.inBattle(p)) {
            Msg.send(p, "teleport.in_battle");
            return;
        }
        if (!Teleports.checkCooldown(p, "rtp", Cfg.general.teleport.rtpCooldownSeconds)) return;
        Rtp.start(p, level);
    }

    static void jump(class_3222 p) {
        int max = Cfg.general.teleport.jumpMaxDistance;
        class_243 eye = p.method_33571();
        class_243 end = eye.method_1019(p.method_5828(1f).method_1021(max));
        class_3965 hit = p.method_37908().method_17742(new class_3959(eye, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, p));
        if (hit.method_17783() != class_239.class_240.field_1332) {
            Msg.send(p, "teleport.jump_nothing");
            return;
        }
        class_3218 level = p.method_51469();
        class_2338 base = hit.method_17777();
        for (int dy = 1; dy <= 6; dy++) {
            class_2338 feet = base.method_10086(dy);
            if (Rtp.safe(level, feet)) {
                Teleports.perform(p, new Loc(level.method_27983().method_29177().toString(), feet.method_10263() + 0.5, feet.method_10264(), feet.method_10260() + 0.5,
                        p.method_36454(), p.method_36455()), Msg.format("teleport.jump_label"), null);
                return;
            }
        }
        Msg.send(p, "teleport.jump_unsafe");
    }
}
