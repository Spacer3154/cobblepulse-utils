package fr.cobblepulse.utils.boss;

import com.cobblemon.mod.common.api.Priority;
import com.cobblemon.mod.common.api.battles.model.PokemonBattle;
import com.cobblemon.mod.common.api.battles.model.actor.AIBattleActor;
import com.cobblemon.mod.common.api.battles.model.actor.BattleActor;
import com.cobblemon.mod.common.api.events.CobblemonEvents;
import com.cobblemon.mod.common.api.pokemon.PokemonProperties;
import com.cobblemon.mod.common.api.pokemon.stats.Stat;
import com.cobblemon.mod.common.battles.actor.PlayerBattleActor;
import com.cobblemon.mod.common.battles.actor.PokemonBattleActor;
import com.cobblemon.mod.common.battles.ai.StrongBattleAI;
import com.cobblemon.mod.common.entity.pokemon.PokemonEntity;
import com.cobblemon.mod.common.pokemon.FormData;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.cobblemon.mod.common.pokemon.Species;
import com.cobblemon.mod.common.pokemon.properties.UncatchableProperty;
import fr.cobblepulse.utils.CobbleUtils;
import fr.cobblepulse.utils.config.BossConfig;
import fr.cobblepulse.utils.config.Cfg;
import fr.cobblepulse.utils.config.Reward;
import fr.cobblepulse.utils.core.Msg;
import fr.cobblepulse.utils.core.Perms;
import fr.cobblepulse.utils.core.Players;
import fr.cobblepulse.utils.core.Reg;
import fr.cobblepulse.utils.core.Rewards;
import fr.cobblepulse.utils.core.Scheduler;
import fr.cobblepulse.utils.core.TextUtil;
import fr.cobblepulse.utils.core.TimeFmt;
import fr.cobblepulse.utils.data.PlayerData;
import fr.cobblepulse.utils.data.PlayerStore;
import fr.cobblepulse.utils.pokemon.PokemonFactory;
import fr.cobblepulse.utils.pokemon.PokemonText;
import fr.cobblepulse.utils.pokemon.SpeciesLookup;
import fr.cobblepulse.utils.storage.Db;
import kotlin.Unit;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import net.minecraft.class_8111;
import java.lang.reflect.Field;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Boss PVE : promotion aleatoire des Pokemon sauvages naturels en Boss de 6 raretes (jusqu'au niveau 140),
 * invulnerables aux degats physiques, incapturables, IA de combat forte, butin editable,
 * objet de forme (Mega-Gemme / Orbe / Globe) garanti a la 1re victoire du joueur puis 10 %.
 */
public final class Bosses {
    public static final String TAG = "cpu_boss";
    private static final Random RND = new Random();
    /** Boss actifs : UUID d'entite -> monde. */
    private static final Map<UUID, class_3218> ACTIVE = new ConcurrentHashMap<>();
    private static Field levelField;
    private static Field aiField;

    /** Combat contre un Boss, memorise au debut : a la victoire, l'entite du Boss K.O. n'est souvent plus accessible. */
    private record Fight(String tier, String key, String species, UUID entity, class_3218 level, long started) {}

    private static final Map<UUID, Fight> FIGHTS = new java.util.concurrent.ConcurrentHashMap<>();
    /** Boss portant le nom court de combat, a re-decorer une fois le combat fini (fuite, defaite du joueur). */
    private static final java.util.Set<UUID> BATTLE_NAMED = java.util.concurrent.ConcurrentHashMap.newKeySet();
    /** Auto-test : victoires contre un Boss traitees. */
    public static volatile int victoriesHandled;
    /** Auto-test : une Gemme Sesame a ete donnee depuis la derniere remise a false. */
    public static volatile boolean lastKeystone;

    private Bosses() {}

    static Db.Source db() {
        return Db.of("boss_first_victories");
    }

    public static void init() {
        CobblemonEvents.POKEMON_ENTITY_SPAWN.subscribe(Priority.HIGH, e -> {
            try {
                if (!e.isCanceled()) maybePromote(e.getEntity());
            } catch (Throwable t) {
                CobbleUtils.LOG.warn("[CobblePulse-Utils] Promotion de Boss : {}", t.toString());
            }
            return Unit.INSTANCE;
        });
        CobblemonEvents.THROWN_POKEBALL_HIT.subscribe(Priority.HIGHEST, e -> {
            if (isBoss(e.getPokemon())) {
                e.cancel();
                if (e.getPokeBall().method_24921() instanceof class_3222 p) Msg.send(p, "boss.uncatchable");
            }
            return Unit.INSTANCE;
        });
        CobblemonEvents.BATTLE_STARTED_PRE.subscribe(Priority.HIGH, e -> {
            try {
                onBattleStart(e.getBattle(), e);
            } catch (Throwable t) {
                CobbleUtils.LOG.warn("[CobblePulse-Utils] Debut de combat de Boss : {}", t.toString());
            }
            return Unit.INSTANCE;
        });
        CobblemonEvents.BATTLE_VICTORY.subscribe(Priority.NORMAL, e -> {
            try {
                onVictory(e.getBattle(), e.getWinners(), e.getLosers());
            } catch (Throwable t) {
                CobbleUtils.LOG.error("[CobblePulse-Utils] Victoire contre un Boss : {}", t.toString());
            }
            return Unit.INSTANCE;
        });
    }

    // ------------------------------------------------------------------ identification

    public static boolean isBoss(class_1297 e) {
        return e instanceof PokemonEntity pe && pe.getPokemon() != null && pe.getPokemon().getPersistentData().method_10545(TAG);
    }

    public static String tierOf(PokemonEntity e) {
        return e.getPokemon().getPersistentData().method_10562(TAG).method_10558("tier");
    }

    public static int activeCount() {
        ACTIVE.entrySet().removeIf(en -> {
            class_1297 x = en.getValue().method_14190(en.getKey());
            return x == null || x.method_31481();
        });
        return ACTIVE.size();
    }

    /** Invulnerabilite aux degats physiques (epees, arcs, explosions, chutes...). /kill reste possible. */
    public static boolean allowDamage(class_1309 entity, class_1282 source) {
        if (!isBoss(entity)) return true;
        return source.method_49708(class_8111.field_44869) || source.method_49708(class_8111.field_42347);
    }

    // ------------------------------------------------------------------ promotion

    private static void maybePromote(PokemonEntity entity) {
        BossConfig c = Cfg.boss;
        if (!c.naturalSpawn || c.promotionChance <= 0 || entity == null) return;
        if (entity.method_37908() instanceof class_3218 sl && !fr.cobblepulse.utils.teleport.Worlds.bosses(sl)) return;
        Pokemon pk = entity.getPokemon();
        if (pk == null || !pk.isWild()) return;
        if (RND.nextDouble() * 100 >= c.promotionChance) return;
        if (!eligible(pk)) return;
        if (activeCount() >= c.maxActive) return;
        // Mega-Boss : seulement pour une espece qui a une Mega-Evolution ou une Primo-Resurgence
        boolean mega = hasMegaTiers() && megaForm(pk.getSpecies()) != null && RND.nextDouble() * 100 < c.specialFormChance;
        promote(entity, pickTier(mega));
    }

    static boolean eligible(Pokemon pk) {
        if (PokemonText.listed(Cfg.boss.blacklistSpecies, pk)) return false;
        Set<String> l = pk.getSpecies().getLabels();
        return Cfg.boss.promoteLegendaries || !(l.contains("legendary") || l.contains("mythical") || l.contains("ultra_beast") || l.contains("paradox"));
    }

    public static boolean hasMegaTiers() {
        for (BossConfig.Tier t : Cfg.boss.tiers.values()) if (t.mega && t.weight > 0) return true;
        return false;
    }

    public static boolean isMegaTier(String tierId) {
        BossConfig.Tier t = Cfg.boss.tiers.get(tierId);
        return t != null && t.mega;
    }

    /** Palier ordinaire au hasard (selon les poids). */
    public static String pickTier() {
        return pickTier(false);
    }

    /** Tirage parmi les paliers ordinaires, ou parmi les paliers de Mega-Boss. */
    public static String pickTier(boolean mega) {
        double total = 0;
        for (BossConfig.Tier t : Cfg.boss.tiers.values()) if (t.mega == mega) total += Math.max(0, t.weight);
        double r = RND.nextDouble() * total;
        for (Map.Entry<String, BossConfig.Tier> e : Cfg.boss.tiers.entrySet()) {
            if (e.getValue().mega != mega) continue;
            r -= Math.max(0, e.getValue().weight);
            if (r <= 0 && e.getValue().weight > 0) return e.getKey();
        }
        for (Map.Entry<String, BossConfig.Tier> e : Cfg.boss.tiers.entrySet()) if (e.getValue().mega == mega) return e.getKey();
        return BossConfig.TIER_ORDER.get(0);
    }

    /** Palier de Mega-Boss associe a un palier ordinaire (epique → mega_epique), sinon le premier ; null s'il n'y en a pas. */
    public static String megaTierFor(String tierId) {
        if (isMegaTier(tierId)) return tierId;
        if (isMegaTier("mega_" + tierId)) return "mega_" + tierId;
        for (Map.Entry<String, BossConfig.Tier> e : Cfg.boss.tiers.entrySet()) if (e.getValue().mega) return e.getKey();
        return null;
    }

    /**
     * Transforme un Pokemon sauvage en Boss du palier donne. Un palier de Mega-Boss impose la Mega-Evolution ou la
     * Primo-Resurgence ; un palier ordinaire peut prendre la forme Originelle.
     * @return false si le palier est inconnu ou si l'espece n'a pas la forme exigee
     */
    public static boolean promote(PokemonEntity entity, String tierId) {
        BossConfig.Tier t = Cfg.boss.tiers.get(tierId);
        if (t == null) return false;
        Pokemon pk = entity.getPokemon();
        String form = "base";
        FormData special = null;
        if (t.mega) {
            special = megaForm(pk.getSpecies());
            if (special == null) return false;
        } else if (RND.nextDouble() * 100 < Cfg.boss.specialFormChance) {
            special = formOf(pk.getSpecies(), Set.of("origin"));
        }
        if (special != null) {
            List<String> errors = new ArrayList<>();
            PokemonFactory.applyForm(pk, pk.getSpecies(), special.getName(), errors);
            if (errors.isEmpty() && pk.getForm() == special) form = formKey(special.getName());
            else if (t.mega) return false;
        }
        int level = t.levelMin + RND.nextInt(t.levelMax - t.levelMin + 1);
        List<Stat> stats = new ArrayList<>(List.of(PokemonText.STATS));
        Collections.shuffle(stats, RND);
        for (int i = 0; i < t.perfectIvs && i < stats.size(); i++) pk.setIV(stats.get(i), 31);
        class_2487 tag = new class_2487();
        tag.method_10582("tier", tierId);
        tag.method_10569("level", level);
        tag.method_10582("key", key(pk, form));
        tag.method_10544("born", System.currentTimeMillis());
        pk.getPersistentData().method_10566(TAG, tag);
        UncatchableProperty.INSTANCE.uncatchable().apply(pk);
        applyLevel(pk, level);
        pk.setScaleModifier(t.scale);
        pk.heal();
        decorate(entity, tierId);
        ACTIVE.put(entity.method_5667(), (class_3218) entity.method_37908());
        if (t.announce) {
            Msg.broadcast(Msg.withComponent("boss.announce", "pokemon", fr.cobblepulse.utils.pokemon.SpeciesNames.of(pk.getSpecies()),
                    "tier", t.color + t.name, "level", pk.getLevel(), "biome", "", "x", (int) entity.method_23317(), "z", (int) entity.method_23321()));
        }
        return true;
    }

    /** Re-applique le niveau et l'apparence apres un rechargement de chunk. */
    public static void onLoad(class_1297 e) {
        if (!(e instanceof PokemonEntity pe) || !isBoss(pe)) return;
        class_2487 tag = pe.getPokemon().getPersistentData().method_10562(TAG);
        applyLevel(pe.getPokemon(), tag.method_10550("level"));
        decorate(pe, tag.method_10558("tier"));
        ACTIVE.put(pe.method_5667(), (class_3218) pe.method_37908());
    }

    private static void decorate(PokemonEntity entity, String tierId) {
        BossConfig.Tier t = Cfg.boss.tiers.get(tierId);
        if (t == null) return;
        Pokemon pk = entity.getPokemon();
        // racine non vide (« %s%s ») : Cobblemon ignore un surnom dont la racine est vide. Surnom pose directement :
        // PokemonEntity.setCustomName l'aplatirait en texte anglais sans couleurs. L'espece reste traduite par chaque client.
        pk.setNickname(class_2561.method_43469("%s%s", TextUtil.legacy(Msg.format("boss.nameplate", "tier", t.color + t.name, "level", pk.getLevel())),
                fr.cobblepulse.utils.pokemon.SpeciesNames.of(pk.getSpecies()).method_27661().method_27696(TextUtil.styleOf(t.color))));
        BATTLE_NAMED.remove(entity.method_5667());
        entity.method_5880(true);
        entity.method_5834(t.glow);
    }

    /** Niveau le plus haut accepte a l'enregistrement d'un Pokemon (voir PokemonLevelCodecMixin) : plafond des paliers. */
    public static final int CODEC_MAX_LEVEL = 250;
    private static volatile Boolean highLevels;

    /**
     * Vrai si un Pokemon au-dela du niveau maximal de Cobblemon peut etre enregistre (sauvegarde du monde, copie).
     * Verifie une fois, par un vrai enregistrement ; sinon les Boss sont plafonnes au niveau maximal, car un Boss
     * non enregistrable ferait echouer la sauvegarde du monde.
     */
    public static boolean highLevelsSupported() {
        Boolean known = highLevels;
        if (known != null) return known;
        boolean ok;
        try {
            PokemonProperties pp = PokemonProperties.Companion.parse("level=5");
            pp.setSpecies("cobblemon:magikarp");
            Pokemon pk = pp.create();
            int target = maxNormalLevel() + 1;
            writeLevel(pk, target);
            class_2487 saved = pk.saveToNBT(CobbleUtils.server().method_30611(), new class_2487());
            pk.clone(true, CobbleUtils.server().method_30611());
            ok = saved != null && pk.getLevel() == target;
        } catch (Throwable t) {
            ok = false;
            CobbleUtils.LOG.warn("[CobblePulse-Utils] Cette version de Cobblemon refuse d'enregistrer un Pokemon au-dela du niveau {} ({}) : "
                    + "les Boss seront plafonnes a ce niveau.", maxNormalLevel(), t.getMessage());
        }
        highLevels = ok;
        if (ok) CobbleUtils.LOG.info("[CobblePulse-Utils] Boss au-dela du niveau {} : enregistrement verifie.", maxNormalLevel());
        return ok;
    }

    public static int maxNormalLevel() {
        try {
            return com.cobblemon.mod.common.Cobblemon.INSTANCE.getConfig().getMaxPokemonLevel();
        } catch (Throwable t) {
            return 100;
        }
    }

    private static void writeLevel(Pokemon pk, int level) throws ReflectiveOperationException {
        pk.setLevel(level);
        if (pk.getLevel() != level) {
            if (levelField == null) {
                levelField = Pokemon.class.getDeclaredField("level");
                levelField.setAccessible(true);
            }
            levelField.setInt(pk, level);
        }
    }

    /** Niveau au-dela du maximum de Cobblemon (100) : ecriture directe du champ, le setter etant plafonne. */
    public static void applyLevel(Pokemon pk, int level) {
        try {
            int max = maxNormalLevel();
            if (level > max && !highLevelsSupported()) level = max;
            writeLevel(pk, Math.min(level, CODEC_MAX_LEVEL));
        } catch (Throwable t) {
            CobbleUtils.LOG.warn("[CobblePulse-Utils] Niveau {} du Boss impossible : {}", level, t.toString());
        }
    }

    // ------------------------------------------------------------------ formes speciales et objets

    private static final java.util.regex.Pattern SPECIAL = java.util.regex.Pattern.compile("(?i)^(mega([ _-]?[xyz])?|primal|origin)$");

    /** Forme speciale imposee par un test (mega, primal, origin). */
    private static String forcedKind;

    /** Forme speciale de l'espece parmi ces types (mega, primal, origin), au hasard ; un test peut imposer le type. */
    static FormData formOf(Species s, Set<String> kinds) {
        List<FormData> found = new ArrayList<>();
        for (FormData f : s.getForms()) {
            if (f.getName() == null) continue;
            String kind = specialKind(f.getName());
            if (kind.isEmpty() || !kinds.contains(kind)) continue;
            if (forcedKind != null && !kind.equals(forcedKind)) continue;
            found.add(f);
        }
        return found.isEmpty() ? null : found.get(RND.nextInt(found.size()));
    }

    /** Mega-Evolution ou Primo-Resurgence de l'espece (au hasard s'il y en a plusieurs), ou null. */
    public static FormData megaForm(Species s) {
        return formOf(s, Set.of("mega", "primal"));
    }

    /** Type de forme speciale : mega, primal, origin, ou "" (forme ordinaire). */
    public static String specialKind(String formName) {
        if (formName == null) return "";
        String n = formName.trim();
        if (!SPECIAL.matcher(n).matches()) return "";
        String l = n.toLowerCase(Locale.ROOT);
        return l.startsWith("mega") ? "mega" : l;
    }

    /** Nom de forme en francais pour le chat : Mega-X → Méga-X, Primal → Primo, Origin → Originelle. */
    public static String formLabel(String form) {
        if (form == null) return "";
        String f = form.replace('_', '-');
        String low = f.toLowerCase(java.util.Locale.ROOT);
        if (low.startsWith("mega")) return "Méga" + f.substring(4);
        if (low.equals("primal")) return "Primo";
        if (low.equals("origin")) return "Originelle";
        return f;
    }

    /** Objet de forme d'une espece et d'un nom de forme (Mega-Gemme, Orbe, Globe...), ou null. */
    public static String formItemFor(Species s, String formName) {
        return formItem(s.getResourceIdentifier().method_12832() + ":" + formKey(formName));
    }

    public static String formKey(String formName) {
        return formName.trim().toLowerCase(Locale.ROOT).replaceAll("[ -]", "_");
    }

    static String key(Pokemon pk, String form) {
        return pk.getSpecies().getResourceIdentifier().method_12832() + ":" + form;
    }

    private static final net.minecraft.class_6862<net.minecraft.class_1792> MEGA_STONE_TAG = net.minecraft.class_6862.method_40092(
            net.minecraft.class_7924.field_41197, class_2960.method_60655("mega_showdown", "mega_stone"));

    /**
     * Objet de forme : config (espece:forme), sinon Mega-Gemme declaree dans le registre de Mega Showdown (tous les mods),
     * sinon deduite du nom des objets.
     */
    public static String formItem(String bossKey) {
        String v = Cfg.boss.formItems.get(bossKey);
        if (v != null) return Reg.itemExists(v) ? v : null;
        String[] parts = bossKey.split(":");
        if (parts.length < 2 || !parts[1].startsWith("mega")) return null;
        // registre de Mega Showdown : gemmes de tous les mods et datapacks
        String declared = MegaStones.find(parts[0], parts[1]);
        if (declared != null) return declared;
        String species = parts[0].replaceAll("[^a-z]", "");
        String suffix = parts[1].length() > 4 ? parts[1].substring(parts[1].length() - 1) : "";
        String best = null;
        int bestLen = 0;
        for (class_2960 id : class_7923.field_41178.method_10235()) {
            // repli par le nom : objets de Mega Showdown et objets marques Mega-Gemme (#mega_showdown:mega_stone)
            if (!"mega_showdown".equals(id.method_12836()) && !class_7923.field_41178.method_10223(id).method_40131().method_40220(MEGA_STONE_TAG)) continue;
            String path = id.method_12832();
            String sfx = "";
            if (path.matches(".*ite_[xyz]$")) {
                sfx = path.substring(path.length() - 1);
                path = path.substring(0, path.length() - 2);
            }
            if (!path.endsWith("ite") || !sfx.equals(suffix)) continue;
            for (String stem : new String[]{path.replaceAll("inite$", ""), path.replaceAll("nite$", ""), path.replaceAll("ite$", "")}) {
                if (stem.length() < 4) continue;
                if (species.startsWith(stem) || stem.startsWith(species)) {
                    int len = Math.min(stem.length(), species.length());
                    if (len > bestLen) {
                        bestLen = len;
                        best = id.toString();
                    }
                }
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ combats

    /**
     * Entite du Boss d'un combat. Pour un Pokemon sauvage, Cobblemon ne renseigne pas l'etat « actif » :
     * PokemonBattleActor.getEntity() vaut toujours null. On passe donc par les donnees du Pokemon puis par l'entite suivie.
     */
    private static PokemonEntity bossOf(PokemonBattle battle) {
        for (BattleActor a : battle.getActors()) {
            if (!(a instanceof PokemonBattleActor pa)) continue;
            if (pa.getEntity() != null && isBoss(pa.getEntity())) return pa.getEntity();
            Pokemon pk = bossPokemon(a);
            if (pk != null) {
                PokemonEntity e = entityOf(pk);
                if (e != null) return e;
            }
        }
        return null;
    }

    private static PokemonBattleActor bossActor(PokemonBattle battle) {
        for (BattleActor a : battle.getActors()) if (bossPokemon(a) != null) return (PokemonBattleActor) a;
        return null;
    }

    /** Entite portant ce Pokemon (Boss suivis, puis tous les mondes). */
    private static PokemonEntity entityOf(Pokemon pk) {
        if (pk.getEntity() != null) return pk.getEntity();
        for (Map.Entry<UUID, class_3218> en : ACTIVE.entrySet()) {
            if (en.getValue().method_14190(en.getKey()) instanceof PokemonEntity pe && pe.getPokemon() == pk) return pe;
        }
        for (Map.Entry<UUID, class_3218> en : ACTIVE.entrySet()) {
            if (en.getValue().method_14190(en.getKey()) instanceof PokemonEntity pe && pe.getPokemon().getUuid().equals(pk.getUuid())) return pe;
        }
        return null;
    }

    /** Pokemon Boss d'un acteur sauvage (par ses donnees, l'entite pouvant deja avoir disparu). */
    private static Pokemon bossPokemon(BattleActor a) {
        if (!(a instanceof PokemonBattleActor pa) || pa.getPokemon() == null) return null;
        for (Pokemon pk : new Pokemon[]{pa.getPokemon().getOriginalPokemon(), pa.getPokemon().getEffectedPokemon()}) {
            if (pk != null && pk.getPersistentData().method_10545(TAG)) return pk;
        }
        return null;
    }

    private static void onBattleStart(PokemonBattle battle, com.cobblemon.mod.common.api.events.battles.BattleStartedEvent.Pre event) {
        PokemonEntity boss = bossOf(battle);
        if (boss == null) return;
        String tierId = tierOf(boss);
        BossConfig.Tier t = Cfg.boss.tiers.get(tierId);
        if (t == null) return;
        long cd = t.engageCooldownSeconds * 1000;
        List<class_3222> players = new ArrayList<>();
        for (BattleActor a : battle.getActors()) {
            if (a instanceof PlayerBattleActor) for (UUID u : a.getPlayerUUIDs()) {
                class_3222 p = Players.online(u);
                if (p != null) players.add(p);
            }
        }
        if (cd > 0) {
            for (class_3222 p : players) {
                if (Perms.perk(p, Perms.BOSS_BYPASS)) continue;
                long left = PlayerStore.get(p).cooldownLeft("boss:" + tierId);
                if (left > 0) {
                    event.cancel();
                    event.setReason(Msg.get("boss.cooldown", "time", TimeFmt.duration(left), "tier", t.color + t.name));
                    Msg.send(p, "boss.cooldown", "time", TimeFmt.duration(left), "tier", t.color + t.name);
                    return;
                }
            }
            for (class_3222 p : players) {
                PlayerData d = PlayerStore.get(p);
                d.setCooldown("boss:" + tierId, cd);
                PlayerStore.dirty(p.method_5667());
            }
        }
        FIGHTS.put(battle.getBattleId(), new Fight(tierId, boss.getPokemon().getPersistentData().method_10562(TAG).method_10558("key"),
                fr.cobblepulse.utils.pokemon.SpeciesNames.text(boss.getPokemon().getSpecies()), boss.method_5667(), (class_3218) boss.method_37908(), System.currentTimeMillis()));
        // pendant le combat, le nom d'espece seul, a la couleur du palier : la fenetre de combat de Cobblemon affiche deja
        // le niveau, n'a pas la place pour le palier et sa police n'a pas les symboles. Plaque complete retablie apres.
        boss.getPokemon().setNickname(class_2561.method_43469("%s", fr.cobblepulse.utils.pokemon.SpeciesNames.of(boss.getPokemon().getSpecies()).method_27661().method_27696(TextUtil.styleOf(t.color))));
        BATTLE_NAMED.add(boss.method_5667());
        // IA de combat forte pour le Boss
        PokemonBattleActor actor = bossActor(battle);
        if (actor != null) setAi(actor, t.aiSkill);
        CobbleUtils.LOG.info("[CobblePulse-Utils] Combat contre le Boss {} ({}) : {}", boss.getPokemon().getSpecies().getName(), tierId,
                players.stream().map(x -> x.method_7334().getName()).toList());
        for (class_3222 p : players) Msg.send(p, Msg.withComponent("boss.engaged", "pokemon", fr.cobblepulse.utils.pokemon.SpeciesNames.of(boss.getPokemon().getSpecies()), "tier", t.color + t.name));
    }

    private static void setAi(AIBattleActor actor, int skill) {
        try {
            if (aiField == null) {
                aiField = AIBattleActor.class.getDeclaredField("battleAI");
                aiField.setAccessible(true);
            }
            aiField.set(actor, new StrongBattleAI(Math.max(0, Math.min(5, skill))));
        } catch (Throwable t) {
            CobbleUtils.LOG.debug("[CobblePulse-Utils] IA du Boss non appliquee : {}", t.toString());
        }
    }

    private static void onVictory(PokemonBattle battle, List<BattleActor> winners, List<BattleActor> losers) {
        Fight fight = FIGHTS.remove(battle.getBattleId());
        // le Boss a-t-il perdu ? (identifie par les donnees du Pokemon : son entite K.O. n'est plus forcement liee)
        Pokemon lost = null;
        PokemonEntity entity = null;
        for (BattleActor a : losers) {
            Pokemon pk = bossPokemon(a);
            if (pk != null) {
                lost = pk;
                entity = ((PokemonBattleActor) a).getEntity();
                if (entity == null) entity = entityOf(pk);
            }
        }
        if (lost == null) return;
        class_2487 tag = lost.getPersistentData().method_10562(TAG);
        String tierId = fight != null ? fight.tier() : tag.method_10558("tier");
        String bossKey = fight != null && !fight.key().isEmpty() ? fight.key() : tag.method_10558("key");
        String species = fr.cobblepulse.utils.pokemon.SpeciesNames.text(lost.getSpecies());
        net.minecraft.class_2561 speciesName = fr.cobblepulse.utils.pokemon.SpeciesNames.of(lost.getSpecies());
        BossConfig.Tier t = Cfg.boss.tiers.get(tierId);
        List<class_3222> players = new ArrayList<>();
        for (BattleActor a : winners) {
            if (a instanceof PlayerBattleActor) for (UUID u : a.getPlayerUUIDs()) {
                class_3222 p = Players.online(u);
                if (p != null && !players.contains(p)) players.add(p);
            }
        }
        if (entity == null && fight != null && fight.level() != null && fight.level().method_14190(fight.entity()) instanceof PokemonEntity pe) entity = pe;
        PokemonEntity finalBoss = entity;
        if (finalBoss != null) Scheduler.later(20, () -> despawn(finalBoss, true));
        if (fight != null) ACTIVE.remove(fight.entity());
        victoriesHandled++;
        if (t == null) {
            CobbleUtils.LOG.warn("[CobblePulse-Utils] Boss vaincu mais palier inconnu : {}", tierId);
            return;
        }
        CobbleUtils.LOG.info("[CobblePulse-Utils] Boss {} ({}) vaincu par {}", species, tierId, players.stream().map(x -> x.method_7334().getName()).toList());
        for (class_3222 p : players) reward(p, t, tierId, bossKey, speciesName);
        if (t.announce && !players.isEmpty()) {
            Msg.broadcast(Msg.withComponent("boss.defeated_broadcast", "pokemon", speciesName, "player", players.get(0).method_7334().getName(),
                    "tier", t.color + t.name));
        }
    }

    /** Butin du palier + objet de forme (1re victoire 100 %, ensuite 10 %). */
    public static void reward(class_3222 p, BossConfig.Tier t, String tierId, String bossKey, String species) {
        reward(p, t, tierId, bossKey, net.minecraft.class_2561.method_43470(species));
    }

    /** Le nom de l'espece est un composant : traduit par le client du joueur (Magicarpe et non Magikarp). */
    public static void reward(class_3222 p, BossConfig.Tier t, String tierId, String bossKey, net.minecraft.class_2561 species) {
        List<String> got = new ArrayList<>();
        // objets proposes dans la fenetre de butin (recuperer, lacher ou jeter) ; argent, BP et commandes : remis tout de suite
        boolean window = Cfg.boss.lootWindow;
        List<net.minecraft.class_1799> items = new ArrayList<>();
        for (Reward r : t.loot) {
            if (r.chance < 100 && Math.random() * 100 >= r.chance) continue;
            if (window && Rewards.isItem(r)) {
                net.minecraft.class_1799 st = fr.cobblepulse.utils.core.ItemSerial.fromSnbt(r.item);
                if (st.method_7960()) continue;
                items.add(st);
                got.add(Rewards.describe(r));
            } else if (Rewards.give(p, r)) got.add(Rewards.describe(r));
        }
        String item = formItem(bossKey);
        UUID u = p.method_5667();
        db().txAsync(c -> {
            // atomique meme entre plusieurs serveurs : l'insertion echoue sans erreur si la ligne existe deja
            boolean first = Db.update(c, db().insertIgnore() + db().table("boss_victories") + " (uuid, boss_key, first_at, wins) VALUES (?,?,?,1)",
                    u.toString(), bossKey, System.currentTimeMillis()) == 1;
            if (!first) {
                Db.update(c, "UPDATE " + db().table("boss_victories") + " SET wins=wins+1 WHERE uuid=? AND boss_key=?", u.toString(), bossKey);
            }
            return first;
        }).whenComplete((first, err) -> Scheduler.next(() -> {
            if (err != null) CobbleUtils.LOG.error("[CobblePulse-Utils] Suivi des victoires de Boss : {}", err.toString());
            boolean isFirst = Boolean.TRUE.equals(first);
            if (item != null && err == null) {
                double chance = isFirst ? Cfg.boss.formItemFirstChance : Cfg.boss.formItemRepeatChance;
                if (RND.nextDouble() * 100 < chance) {
                    Reward r = Reward.item(item, 100);
                    String label = "&d" + Rewards.describe(r) + (isFirst ? " " + Msg.format("boss.first_win") : "");
                    net.minecraft.class_1799 st = fr.cobblepulse.utils.core.ItemSerial.fromSnbt(r.item);
                    if (window && !st.method_7960()) {
                        items.add(0, st);
                        got.add(label);
                    } else if (Rewards.give(p, r)) got.add(label);
                }
            }
            // Gemme Sesame : Mega-Boss seulement
            if (t.mega && err == null && Cfg.boss.keystoneItem != null && !Cfg.boss.keystoneItem.isBlank()) {
                double chance = isFirst ? Cfg.boss.keystoneFirstChance : Cfg.boss.keystoneRepeatChance;
                if (RND.nextDouble() * 100 < chance) {
                    Reward r = Reward.item(Cfg.boss.keystoneItem, 100);
                    net.minecraft.class_1799 st = fr.cobblepulse.utils.core.ItemSerial.fromSnbt(r.item);
                    if (!st.method_7960()) {
                        String label = "&b" + Rewards.describe(r) + (isFirst ? " " + Msg.format("boss.first_win") : "");
                        lastKeystone = true;
                        if (window) {
                            items.add(0, st);
                            got.add(label);
                        } else if (Rewards.give(p, r)) got.add(label);
                    }
                }
            }
            Msg.send(p, Msg.withComponent("boss.victory", "pokemon", species, "tier", t.color + t.name, "rewards", got.isEmpty() ? "-" : String.join("&7, ", got)));
            if (!items.isEmpty()) BossLoot.offer(p, Msg.withComponent("boss.loot_title", "pokemon", species, "tier", t.color + t.name), items);
            Players.saveNow(p);
        }));
    }

    public static void despawn(PokemonEntity e, boolean fx) {
        if (e == null || e.method_31481()) return;
        if (fx && e.method_37908() instanceof class_3218 sl) {
            class_243 pos = e.method_19538();
            sl.method_14199(class_2398.field_11221, pos.field_1352, pos.field_1351 + 1, pos.field_1350, 1, 0, 0, 0, 0);
            sl.method_14199(class_2398.field_11220, pos.field_1352, pos.field_1351 + 1, pos.field_1350, 60, 0.6, 1, 0.6, 0.3);
        }
        ACTIVE.remove(e.method_5667());
        e.method_31472();
    }

    /** Toutes les 20 s : retrait des Boss expires (hors combat). */
    public static void tick() {
        FIGHTS.values().removeIf(f -> System.currentTimeMillis() - f.started() > 3_600_000L);
        long life = Cfg.boss.lifetimeMinutes * 60_000L;
        for (Map.Entry<UUID, class_3218> en : new ArrayList<>(ACTIVE.entrySet())) {
            class_1297 x = en.getValue().method_14190(en.getKey());
            if (!(x instanceof PokemonEntity pe) || x.method_31481()) {
                ACTIVE.remove(en.getKey());
                continue;
            }
            if (!pe.isBattling() && BATTLE_NAMED.contains(pe.method_5667())) decorate(pe, tierOf(pe));
            long born = pe.getPokemon().getPersistentData().method_10562(TAG).method_10537("born");
            if (!pe.isBattling() && born > 0 && System.currentTimeMillis() - born > life) despawn(pe, false);
        }
    }

    public static int clearAll() {
        int n = 0;
        for (class_3218 level : CobbleUtils.server().method_3738()) {
            List<PokemonEntity> list = new ArrayList<>();
            for (class_1297 e : level.method_27909()) if (e instanceof PokemonEntity pe && isBoss(pe)) list.add(pe);
            for (PokemonEntity pe : list) {
                despawn(pe, false);
                n++;
            }
        }
        ACTIVE.clear();
        return n;
    }

    /** /cp boss spawn <palier> [espece] : fait apparaitre un Boss a la position du staff. */
    public static PokemonEntity spawnAt(class_3222 p, String tierId, String speciesName) {
        return spawnAt(p, tierId, speciesName, "auto", 3);
    }

    /**
     * Boss de test devant le staff.
     * <p>Un palier de Mega-Boss donne toujours une Mega-Evolution ou une Primo-Resurgence. Demander « mega » ou
     * « primal » sur un palier ordinaire fait apparaitre le Mega-Boss du palier correspondant.</p>
     * @param form auto (tirage normal), base, mega, primal ou origin
     * @return null si le palier est inconnu ou si l'espece n'a pas la forme exigee
     */
    public static PokemonEntity spawnAt(class_3222 p, String tierId, String speciesName, String form, double distance) {
        String f = form == null ? "auto" : form.toLowerCase(Locale.ROOT);
        boolean wantsMega = f.equals("mega") || f.equals("primal");
        if (wantsMega && !isMegaTier(tierId)) {
            String m = megaTierFor(tierId);
            if (m == null) return null;
            tierId = m;
        }
        BossConfig.Tier t = Cfg.boss.tiers.get(tierId);
        if (t == null) return null;
        // types de forme acceptes : Mega-Boss = mega et/ou primal ; palier ordinaire = origin seulement
        Set<String> kinds = t.mega ? (wantsMega ? Set.of(f) : Set.of("mega", "primal")) : (f.equals("origin") ? Set.of("origin") : Set.of());
        Species s = speciesName == null || speciesName.isBlank() || speciesName.equals("*") ? null : SpeciesLookup.resolve(speciesName);
        if (s == null) {
            List<Species> pool = new ArrayList<>(com.cobblemon.mod.common.api.pokemon.PokemonSpecies.getImplemented());
            if (kinds.isEmpty()) pool.removeIf(x -> x.getLabels().contains("legendary") || x.getLabels().contains("mythical"));
            // forme exigee : especes qui la possedent (Mega, Primo, Originelle)
            else pool.removeIf(x -> x.getForms().stream().noneMatch(fd -> kinds.contains(specialKind(fd.getName()))));
            if (pool.isEmpty()) return null;
            s = pool.get(RND.nextInt(pool.size()));
        }
        PokemonProperties pp = PokemonProperties.Companion.parse("level=50");
        pp.setSpecies(s.getResourceIdentifier().toString());
        Pokemon pk = pp.create();
        class_243 look = p.method_5720();
        class_243 pos = p.method_19538().method_1019(new class_243(look.field_1352, 0, look.field_1350).method_1029().method_1021(distance));
        PokemonEntity e = new PokemonEntity(p.method_51469(), pk, com.cobblemon.mod.common.CobblemonEntities.POKEMON);
        e.method_5808(pos.field_1352, p.method_23318(), pos.field_1350, p.method_36454() + 180, 0);
        double old = Cfg.boss.specialFormChance;
        // palier ordinaire : forme Originelle seulement si elle est demandee (auto = tirage normal)
        if (!t.mega && !f.equals("auto")) Cfg.boss.specialFormChance = f.equals("origin") ? 100 : 0;
        boolean ok;
        try {
            if (wantsMega || f.equals("origin") && !t.mega) forcedKind = f;
            ok = promote(e, tierId);
        } finally {
            Cfg.boss.specialFormChance = old;
            forcedKind = null;
        }
        if (!ok) return null;
        p.method_51469().method_8649(e);
        return e;
    }

    /** Combat de test : le staff affronte immediatement le Boss avec son equipe. */
    public static String startBattle(class_3222 p, PokemonEntity boss) {
        var party = fr.cobblepulse.utils.pokemon.PokemonText.party(p);
        Pokemon lead = null;
        for (Pokemon pk : party) if (pk != null && !pk.isFainted()) {
            lead = pk;
            break;
        }
        if (lead == null) return "boss.test_no_pokemon";
        try {
            var res = com.cobblemon.mod.common.battles.BattleBuilder.INSTANCE.pve(p, boss, lead.getUuid(),
                    com.cobblemon.mod.common.battles.BattleFormat.Companion.getGEN_9_SINGLES(), false, false);
            return res instanceof com.cobblemon.mod.common.battles.SuccessfulBattleStart ? null : "boss.test_battle_failed";
        } catch (Throwable t) {
            CobbleUtils.LOG.warn("[CobblePulse-Utils] Combat de test : {}", t.toString());
            return "boss.test_battle_failed";
        }
    }

    public static boolean megaShowdown() {
        return FabricLoader.getInstance().isModLoaded("mega_showdown");
    }
}
